export  const states = [
  { id: 'alabama', name: 'Alabama' },
  { id: 'alaska', name: 'Alaska' },
  { id: 'arizona', name: 'Arizona' },
  { id: 'arkansas', name: 'Arkansas' },
  { id: 'california', name: 'California' },
  { id: 'colorado', name: 'Colorado' },
  { id: 'connecticut', name: 'Connecticut' },
  { id: 'delaware', name: 'Delaware' },
  { id: 'florida', name: 'Florida' },
  { id: 'georgia', name: 'Georgia' },
  { id: 'hawaii', name: 'Hawaii' },
  { id: 'idaho', name: 'Idaho' },
  { id: 'illinois', name: 'Illinois' },
  { id: 'indiana', name: 'Indiana' },
  { id: 'iowa', name: 'Iowa' },
  { id: 'kansas', name: 'Kansas' },
  { id: 'kentucky', name: 'Kentucky' },
  { id: 'louisiana', name: 'Louisiana' },
  { id: 'maine', name: 'Maine' },
  { id: 'maryland', name: 'Maryland' },
  { id: 'massachusetts', name: 'Massachusetts' },
  { id: 'michigan', name: 'Michigan' },
  { id: 'minnesota', name: 'Minnesota' },
  { id: 'mississippi', name: 'Mississippi' },
  { id: 'missouri', name: 'Missouri' },
  { id: 'montana', name: 'Montana' },
  { id: 'nebraska', name: 'Nebraska' },
  { id: 'nevada', name: 'Nevada' },
  { id: 'new-hampshire', name: 'New Hampshire' },
  { id: 'new-jersey', name: 'New Jersey' },
  { id: 'new-mexico', name: 'New Mexico' },
  { id: 'new-york', name: 'New York' },
  { id: 'north-carolina', name: 'North Carolina' },
  { id: 'north-dakota', name: 'North Dakota' },
  { id: 'ohio', name: 'Ohio' },
  { id: 'oklahoma', name: 'Oklahoma' },
  { id: 'oregon', name: 'Oregon' },
  { id: 'pennsylvania', name: 'Pennsylvania' },
  { id: 'rhode-island', name: 'Rhode Island' },
  { id: 'south-carolina', name: 'South Carolina' },
  { id: 'south-dakota', name: 'South Dakota' },
  { id: 'tennessee', name: 'Tennessee' },
  { id: 'texas', name: 'Texas' },
  { id: 'utah', name: 'Utah' },
  { id: 'vermont', name: 'Vermont' },
  { id: 'virginia', name: 'Virginia' },
  { id: 'washington', name: 'Washington' },
  { id: 'west-virginia', name: 'West Virginia' },
  { id: 'wisconsin', name: 'Wisconsin' },
  { id: 'wyoming', name: 'Wyoming' },
  { id: 'district-of-columbia', name: 'District of Columbia' }
];

interface KeyIncentive {
  name: string;
  description: string;
  type: 'rebate' | 'tax' | 'program';
}

interface Incentive {
  name: string;
  description: string;
  details?: string[];
  eligibility?: string;
  expiryDate?: string;
  link?: string;
}

interface FAQ {
  question: string;
  answer: string;
}

interface UtilityCompany {
  name: string;
  program: string;
}

interface Resource {
  name: string;
  description: string;
  url: string;
}

interface StateData {
  name: string;
  overview: string;
  solarPotential: string;
  averageSavings: string;
  keyIncentives: KeyIncentive[];
  incentives: Incentive[];
  faqs: FAQ[];
  utilityCompanies: UtilityCompany[];
  resources: Resource[];
}

const californiaData: StateData = {
  name: 'California',
  overview: 'California leads the nation in solar adoption with robust state incentives, excellent solar potential, and supportive policies. The state offers various rebates, performance-based incentives, and property tax exclusions that complement federal incentives.',
  solarPotential: 'Excellent, with 5-6 average daily peak sun hours in most regions',
  averageSavings: '$50,000 to $75,000 over 25 years depending on system size and location',
  keyIncentives: [
    {
      name: 'Self-Generation Incentive Program (SGIP)',
      description: 'Rebates for energy storage systems paired with solar',
      type: 'rebate'
    },
    {
      name: 'Property Tax Exclusion',
      description: 'Solar systems are excluded from property tax assessments until 2025',
      type: 'tax'
    },
    {
      name: 'Net Energy Metering (NEM)',
      description: 'Credit for excess electricity sent back to the grid',
      type: 'program'
    }
  ],
  incentives: [
    {
      name: 'Self-Generation Incentive Program (SGIP)',
      description: 'The SGIP provides rebates for qualifying distributed energy systems, with higher incentives for energy storage systems paired with solar PV.',
      details: [
        'Rebates range from $150 to $1,000 per kWh of battery storage',
        'Equity resiliency projects receive highest incentive levels',
        'Step-based system with decreasing incentives as capacity goals are reached',
        'Administered by utility companies'
      ],
      eligibility: 'California electric utility customers who pay the public goods charge on their electric bill. Higher incentives for low-income households and those in high fire-threat districts.',
      expiryDate: 'Ongoing until funds are depleted',
      link: 'https://www.cpuc.ca.gov/sgip/'
    },
    {
      name: 'Property Tax Exclusion for Solar Energy Systems',
      description: 'Solar energy systems installed between January 1, 1999, and December 31, 2024, are excluded from property tax assessments.',
      details: [
        'Covers 100% of system value',
        'Active solar energy systems include storage devices, power conditioning equipment, transfer equipment, and parts',
        'No maximum limit',
        'Does not apply to solar pool heating or hot tub systems'
      ],
      eligibility: 'All solar energy systems installed on residential and commercial properties.',
      expiryDate: 'December 31, 2024',
      link: 'https://www.boe.ca.gov/proptaxes/solar-energy-new-construction.htm'
    },
    {
      name: 'Net Energy Metering (NEM)',
      description: 'California\'s net metering program allows customers to receive credit for excess electricity their system generates and feeds back to the grid.',
      details: [
        'Current program is NEM 3.0',
        'Export compensation rates vary by time and utility',
        'Customers on NEM are required to switch to time-of-use (TOU) rate plans',
        'Virtual net metering available for multi-tenant properties'
      ],
      eligibility: 'Customers of PG&E, SCE, and SDG&E with renewable energy systems under 1 MW.',
      link: 'https://www.cpuc.ca.gov/industries-and-topics/electrical-energy/demand-side-management/net-energy-metering'
    },
    {
      name: 'Single-Family Affordable Solar Homes (SASH) Program',
      description: 'The SASH program provides qualifying low-income homeowners with fixed, up-front incentives to offset the upfront cost of installing solar power systems.',
      details: [
        'Incentive rate of $3 per watt',
        'Program managed by GRID Alternatives',
        'Option for no-cost system installation for very low-income households',
        'Includes energy efficiency services'
      ],
      eligibility: 'Single-family homeowners who occupy their homes and have household incomes at or below 80% of the area median income.',
      link: 'https://gridalternatives.org/what-we-do/program-administration/sash'
    }
  ],
  faqs: [
    {
      question: 'How much can I save with solar in California?',
      answer: 'The average California homeowner can save between $50,000 and $75,000 over 25 years by going solar. Your specific savings depend on your electricity usage, the size of your solar system, your location within California, and which utility company serves your area. Areas with higher electricity rates (like San Diego or San Francisco) typically see greater savings.'
    },
    {
      question: 'What happened to the California Solar Initiative rebates?',
      answer: 'The California Solar Initiative (CSI) general market program ended in 2016 after successfully meeting its goals. However, some CSI components remain active, including the SASH and MASH programs for affordable housing. The state has shifted to other incentives like the Self-Generation Incentive Program (SGIP) which now focuses primarily on energy storage.'
    },
    {
      question: 'How does the NEM 3.0 program work in California?',
      answer: 'Under NEM 3.0, solar customers receive reduced compensation for excess energy exported to the grid compared to previous NEM versions. Export rates are based on the "Avoided Cost Calculator," which typically provides lower credits than retail rates. The program requires customers to switch to time-of-use rate plans and includes an interconnection fee. While less generous than earlier programs, solar remains economically viable in most cases.'
    },
    {
      question: 'Are there special solar incentives for low-income California residents?',
      answer: 'Yes, California offers several programs specifically for low-income residents. The Single-Family Affordable Solar Homes (SASH) program provides qualifying low-income homeowners with incentives of $3 per watt. The DAC-SASH program serves disadvantaged communities. The SGIP Equity Resilience Budget offers higher incentives for energy storage to low-income households, especially those in high fire-threat areas.'
    }
  ],
  utilityCompanies: [
    {
      name: 'Pacific Gas & Electric (PG&E)',
      program: 'Net Energy Metering with time-of-use rates'
    },
    {
      name: 'Southern California Edison (SCE)',
      program: 'Net Energy Metering with time-of-use rates'
    },
    {
      name: 'San Diego Gas & Electric (SDG&E)',
      program: 'Net Energy Metering with time-of-use rates'
    },
    {
      name: 'Los Angeles Department of Water and Power (LADWP)',
      program: 'Solar Incentive Program and net metering'
    }
  ],
  resources: [
    {
      name: 'California Solar & Storage Association',
      description: 'Industry association with resources for consumers',
      url: 'https://calssa.org/'
    },
    {
      name: 'California Public Utilities Commission - Solar',
      description: 'Official information about solar programs and policies',
      url: 'https://www.cpuc.ca.gov/industries-and-topics/electrical-energy/demand-side-management/customer-generation'
    },
    {
      name: 'GRID Alternatives',
      description: 'Nonprofit managing low-income solar programs',
      url: 'https://gridalternatives.org/'
    }
  ]
};

const texasData: StateData = {
  name: 'Texas',
  overview: 'Texas combines abundant sunshine with a variety of local utility rebates and property tax incentives, making it an excellent state for solar adoption. While Texas doesn\'t offer statewide solar rebate programs, many utilities provide generous incentives and the state offers valuable property tax exemptions.',
  solarPotential: 'Excellent, with 5-6 average daily peak sun hours in most regions',
  averageSavings: '$25,000 to $40,000 over 25 years depending on utility and location',
  keyIncentives: [
    {
      name: 'Property Tax Exemption',
      description: '100% exemption for the added home value from solar installations',
      type: 'tax'
    },
    {
      name: 'Local Utility Rebates',
      description: 'Varies by utility, ranging from $250-$2,500 per installation',
      type: 'rebate'
    },
    {
      name: 'Net Metering',
      description: 'Available through some utilities and retail electricity providers',
      type: 'program'
    }
  ],
  incentives: [
    {
      name: 'Renewable Energy Property Tax Exemption',
      description: 'Texas law provides a 100% property tax exemption for the added value solar panels bring to a property.',
      details: [
        'Covers both photovoltaic and solar thermal systems',
        'No maximum limit on exemption value',
        'Does not expire',
        'Applies to both residential and commercial systems'
      ],
      eligibility: 'All Texas property owners who install solar energy systems on their property.',
      link: 'https://comptroller.texas.gov/taxes/property-tax/exemptions/index.php'
    },
    {
      name: 'Austin Energy Solar Rebate Program',
      description: 'Austin Energy offers a solar rebate program for residential and commercial customers who install solar panels.',
      details: [
        '$2,500 residential rebate for systems 3kW and larger',
        'Performance-based incentives available for commercial systems',
        'Additional incentives for using local installers',
        'Requires energy efficiency audit'
      ],
      eligibility: 'Austin Energy customers with properties suitable for solar installation. Must use an approved solar installer.',
      link: 'https://austinenergy.com/ae/green-power/solar-solutions/for-your-home/solar-photovoltaic-rebates'
    },
    {
      name: 'CPS Energy Solar Rebate Program (San Antonio)',
      description: 'CPS Energy offers rebates to residential and commercial customers who install solar panels.',
      details: [
        'Residential rebates of $2,500 for non-local installers, $3,000 for local installers',
        'Additional incentives for using locally manufactured components',
        'Commercial rebates also available',
        'Requires energy efficiency requirements'
      ],
      eligibility: 'CPS Energy customers with properties suitable for solar installation.',
      link: 'https://www.cpsenergy.com/en/my-home/ways-to-save/rebates-rebate/solar-rebates.html'
    },
    {
      name: 'Net Metering Through Retail Electricity Providers',
      description: 'Several retail electricity providers in Texas offer net metering or solar buyback programs.',
      details: [
        'Rates and terms vary by provider',
        'Some offer 1-to-1 credit for excess generation',
        'Others use different rates for purchased vs. sold electricity',
        'Available in deregulated electricity markets'
      ],
      eligibility: 'Customers in deregulated electricity markets who can choose their retail electricity provider.',
      link: 'https://www.powertochoose.org/'
    }
  ],
  faqs: [
    {
      question: 'Does Texas have a state tax credit for solar panels?',
      answer: 'No, Texas does not offer a state tax credit specifically for solar panel installations. However, the state does provide a 100% property tax exemption for the added home value from installing solar panels, which can result in significant long-term savings. Additionally, Texans can still take advantage of the 30% federal solar investment tax credit.'
    },
    {
      question: 'Why are there different solar incentives in different parts of Texas?',
      answer: 'Texas has a unique energy market structure with some areas being regulated and others deregulated. In regulated areas, local municipal utilities and electric cooperatives set their own incentive programs, resulting in varying rebates and incentives across the state. This is why Austin, San Antonio, and other cities have different solar rebate programs. In deregulated areas, retail electricity providers compete by offering different solar buyback rates and plans.'
    },
    {
      question: 'How does net metering work in Texas?',
      answer: 'Unlike many states, Texas does not have a statewide net metering policy. Instead, net metering availability and terms depend on your electricity provider. In areas served by municipal utilities like Austin Energy and CPS Energy, formal net metering programs exist. In deregulated areas, some retail electricity providers offer solar buyback programs or net metering with varying credit rates for excess generation. Shop around to find the best solar-friendly electricity plan in your area.'
    },
    {
      question: 'Is solar worth it in Texas?',
      answer: 'Yes, solar is typically a good investment in Texas due to the state\'s abundant sunshine, property tax exemption, local utility rebates, and the federal tax credit. The economics are particularly favorable in areas with higher electricity rates or good solar buyback programs. Most Texas solar owners see payback periods of 7-12 years depending on their location, electricity rates, and available incentives, with total savings of $25,000-$40,000 over the system\'s lifetime.'
    }
  ],
  utilityCompanies: [
    {
      name: 'Austin Energy',
      program: 'Solar rebates and Value of Solar tariff'
    },
    {
      name: 'CPS Energy (San Antonio)',
      program: 'Solar rebates and net metering'
    },
    {
      name: 'Oncor Electric Delivery',
      program: 'Solar incentive program for their service area'
    },
    {
      name: 'Green Mountain Energy',
      program: 'Renewable Rewards buyback program'
    }
  ],
  resources: [
    {
      name: 'State Energy Conservation Office',
      description: 'Information on renewable energy in Texas',
      url: 'https://comptroller.texas.gov/programs/seco/'
    },
    {
      name: 'Solar Energy Industries Association - Texas',
      description: 'Texas-specific solar industry information',
      url: 'https://www.seia.org/state-solar-policy/texas-solar'
    },
    {
      name: 'Power to Choose',
      description: 'Compare retail electricity providers and plans',
      url: 'https://www.powertochoose.org/'
    }
  ]
};

const newYorkData: StateData = {
  name: 'New York',
  overview: 'New York offers some of the most generous solar incentives in the country through the NY-Sun program and additional state tax credits. Combined with strong net metering policies and growing community solar options, these incentives make solar highly attractive throughout the state.',
  solarPotential: 'Good, with 4-4.5 average daily peak sun hours in most regions',
  averageSavings: '$30,000 to $45,000 over 25 years depending on location and utility',
  keyIncentives: [
    {
      name: 'NY-Sun Megawatt Block Incentive',
      description: 'Direct rebates for residential and commercial solar installations',
      type: 'rebate'
    },
    {
      name: 'State Tax Credit',
      description: '25% of solar costs up to $5,000 for residential installations',
      type: 'tax'
    },
    {
      name: 'Property Tax Abatement',
      description: '15-year property tax exemption for added value from solar',
      type: 'tax'
    }
  ],
  incentives: [
    {
      name: 'NY-Sun Megawatt Block Incentive',
      description: 'The NY-Sun program provides direct cash incentives for residential and commercial solar installations.',
      details: [
        'Incentive rates vary by region and system size',
        'Declining block structure - rates decrease as capacity targets are met',
        'Current residential incentives range from $0.15 to $0.60 per watt',
        'Additional incentives available for low-to-moderate income households'
      ],
      eligibility: 'Available to customers of investor-owned utilities in NY. System must be installed by a NYSERDA-approved contractor.',
      link: 'https://www.nyserda.ny.gov/All-Programs/Programs/NY-Sun'
    },
    {
      name: 'Solar Energy System Equipment Credit',
      description: 'New York State offers a personal income tax credit for solar energy systems.',
      details: [
        '25% of qualified solar energy system expenses',
        'Maximum credit of $5,000',
        'Can be carried forward for up to 5 years if the credit exceeds tax liability',
        'Applies to systems installed at primary residences'
      ],
      eligibility: 'New York taxpayers who install qualified solar energy equipment at their primary residence.',
      link: 'https://www.tax.ny.gov/pit/credits/solar_energy_system_equipment_credit.htm'
    },
    {
      name: 'Real Property Tax Exemption',
      description: 'New York offers a 15-year real property tax exemption for the added assessment value from installing a solar energy system.',
      details: [
        '100% exemption from real property taxes for 15 years',
        'Local governments can opt out of providing the exemption',
        'Applies to systems installed before January 1, 2025',
        'Covers both residential and commercial properties'
      ],
      eligibility: 'Property owners in New York who install solar energy systems, unless their local government has opted out of the exemption.',
      expiryDate: 'January 1, 2025 (for system installation)',
      link: 'https://www.tax.ny.gov/research/property/assess/manuals/vol4/pt1/sec4_01/sec487.htm'
    },
    {
      name: 'Net Energy Metering',
      description: 'New York\'s net metering program allows customers to receive credit for excess electricity their solar systems generate.',
      details: [
        'Credits roll over month to month at retail rate',
        'Annual reconciliation for excess credits',
        'Being transitioned to Value of Distributed Energy Resources (VDER) compensation',
        'Community solar subscriptions available'
      ],
      eligibility: 'Customers of investor-owned utilities in New York with renewable energy systems.',
      link: 'https://www3.dps.ny.gov/W/PSCWeb.nsf/All/DCF68EFCA391AD6085257687006F396B'
    }
  ],
  faqs: [
    {
      question: 'How does the NY-Sun incentive program work?',
      answer: 'The NY-Sun Megawatt Block program provides upfront rebates for solar installations based on a declining block structure. Each region of New York (ConEd, Upstate, and Long Island) has its own block structure. As more solar is installed, blocks fill up and incentive rates decrease. Current incentives range from $0.15 to $0.60 per watt depending on your region and which block is active. These incentives are typically applied directly by your installer to reduce your upfront cost.'
    },
    {
      question: 'Can I combine the New York State solar tax credit with the federal tax credit?',
      answer: 'Yes, you can claim both the 25% New York State solar tax credit (up to $5,000) and the 30% federal solar investment tax credit. These credits are applied differently: the federal credit applies to your federal tax liability, while the NY credit applies to your state taxes. Together, they can reduce the cost of your solar system by more than 50% when combined with the NY-Sun rebate.'
    },
    {
      question: 'What is the Value of Distributed Energy Resources (VDER) and how does it affect me?',
      answer: 'VDER is gradually replacing traditional net metering in New York. Under VDER (also called the "Value Stack"), solar energy is valued based on when and where it\'s produced, providing different compensation rates for electricity based on factors like location, time of day, and grid needs. For most residential customers, the transition has been gradual, and existing net metering customers were grandfathered. New solar customers will increasingly be placed under VDER tariffs, which may provide better compensation for adding battery storage to solar systems.'
    },
    {
      question: 'What is NY-Sun Affordable Solar?',
      answer: 'NY-Sun Affordable Solar provides additional incentives for low-to-moderate income households (LMI) installing solar. Households with incomes below 80% of the area median income may qualify for double the standard NY-Sun incentive rate. The program also supports community solar projects that serve LMI customers. These enhanced incentives can make solar accessible to a broader range of New Yorkers and significantly improve the financial returns of going solar for eligible households.'
    }
  ],
  utilityCompanies: [
    {
      name: 'Con Edison',
      program: 'Net metering and VDER tariffs'
    },
    {
      name: 'National Grid',
      program: 'Net metering and VDER tariffs'
    },
    {
      name: 'PSEG Long Island',
      program: 'Net metering and rebate programs'
    },
    {
      name: 'New York State Electric & Gas (NYSEG)',
      program: 'Net metering and VDER tariffs'
    }
  ],
  resources: [
    {
      name: 'NYSERDA Solar Energy',
      description: 'Official information on NY solar programs',
      url: 'https://www.nyserda.ny.gov/All-Programs/Programs/NY-Sun'
    },
    {
      name: 'NY State Department of Taxation and Finance',
      description: 'Information on solar tax credits and exemptions',
      url: 'https://www.tax.ny.gov/pit/credits/solar_energy_system_equipment_credit.htm'
    },
    {
      name: 'New York State Public Service Commission',
      description: 'Regulatory information on net metering and VDER',
      url: 'https://www3.dps.ny.gov/'
    }
  ]
};

export const getStateData = (stateId: string): StateData | undefined => {
  switch (stateId) {
    case 'california':
      return californiaData;
    case 'texas':
      return texasData;
    case 'new-york':
      return newYorkData;
    default:
      if (states.some(state => state.id === stateId)) {
        // For other states, return California data with name changed as a placeholder
        const stateName = states.find(state => state.id === stateId)?.name || '';
        return {
          ...californiaData,
          name: stateName
        };
      }
      return undefined;
  }
};
 