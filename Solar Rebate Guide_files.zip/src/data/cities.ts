import  { KeyIncentive, FAQ } from './states';

export interface CityData {
  id: string;
  name: string;
  stateId: string;
  stateName: string;
  overview: string;
  imageUrl?: string;
  imageAlt?: string;
  neighborhoods: Neighborhood[];
  localIncentives: LocalIncentive[];
  solarFacts: SolarFact[];
  faqs: FAQ[];
  utilityInfo: string;
  citySpecificTips: string;
  popularInstallers: Installer[];
}

export interface Neighborhood {
  name: string;
  description: string;
}

export interface LocalIncentive {
  name: string;
  description: string;
  eligibility?: string;
  link?: string;
}

export interface SolarFact {
  title: string;
  value: string;
  icon?: string;
}

export interface Installer {
  name: string;
  specialty: string;
  rating?: string;
}

// California cities
const losAngeles: CityData = {
  id: 'los-angeles',
  name: 'Los Angeles',
  stateId: 'california',
  stateName: 'California',
  overview: 'Los Angeles is leading the solar revolution in California with ambitious sustainability goals and excellent solar potential. The city offers additional solar incentives beyond state programs, making it one of the most favorable locations for solar investment in the country.',
  imageUrl: 'https://images.unsplash.com/photo-1594365458706-6fab3472f681?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxDYWxpZm9ybmlhJTIwc29sYXIlMjBwYW5lbHMlMjByb29mJTIwbmVpZ2hib3Job29kfGVufDB8fHx8MTc0NzYzNTkzMXww&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800',
  imageAlt: 'Solar panels on Los Angeles rooftops with city skyline',
  neighborhoods: [
    {
      name: 'Santa Monica',
      description: 'Known for eco-conscious residents and high solar adoption rates. Many properties here feature rooftop solar as part of the community\'s commitment to sustainability.'
    },
    {
      name: 'Silver Lake',
      description: 'This trendy neighborhood has seen a surge in solar installations, with many homeowners combining solar with modern architectural renovations.'
    },
    {
      name: 'Sherman Oaks',
      description: 'Featuring many single-family homes with ideal roof conditions for solar, this Valley neighborhood has one of the highest per-capita solar installation rates.'
    },
    {
      name: 'Venice',
      description: 'Known for environmental consciousness, many homes here incorporate solar as part of broader eco-friendly home designs.'
    },
    {
      name: 'Brentwood',
      description: 'Luxury homes in this upscale neighborhood often feature large solar arrays combined with energy storage systems.'
    }
  ],
  localIncentives: [
    {
      name: 'LADWP Solar Incentive Program',
      description: 'The Los Angeles Department of Water and Power offers performance-based incentives for solar installations based on expected energy generation.',
      eligibility: 'LADWP customers installing new solar PV systems',
      link: 'https://www.ladwp.com/ladwp/faces/ladwp/residential/r-gogreen/r-gg-ressolar'
    },
    {
      name: 'LA County Property Assessed Clean Energy (PACE) Financing',
      description: 'Allows property owners to finance solar installations and pay back the cost through an assessment on their property tax bill.',
      eligibility: 'Property owners in Los Angeles County',
      link: 'https://www.lapace.org/'
    },
    {
      name: 'Solar Rebate for Multifamily Buildings',
      description: 'Specific incentives for apartment buildings and multifamily properties to install shared solar systems.',
      eligibility: 'Owners of multifamily residential buildings in Los Angeles',
      link: 'https://www.ladwp.com/ladwp/faces/ladwp/commercial/c-gogreen/c-gg-comsolar'
    }
  ],
  solarFacts: [
    {
      title: 'Average Sun Hours',
      value: '5.6 hours/day',
      icon: 'Sun'
    },
    {
      title: 'Average System Size',
      value: '6.5 kW',
      icon: 'Zap'
    },
    {
      title: 'Average Cost',
      value: '$18,500 (after incentives)',
      icon: 'DollarSign'
    },
    {
      title: 'Average Payback Period',
      value: '6-8 years',
      icon: 'Clock'
    }
  ],
  faqs: [
    {
      question: 'Do Los Angeles homes need special permits for solar installation?',
      answer: 'Yes, Los Angeles requires specific permits for solar installations. However, the city has streamlined the process with an expedited permitting system for standard residential solar installations. Most permits can be obtained through the LA Department of Building and Safety online system. The city typically processes solar permits faster than other construction permits as part of its green initiative.'
    },
    {
      question: 'How does LADWP\'s net metering program work?',
      answer: 'LADWP offers a net energy metering (NEM) program that credits customers for excess solar energy sent back to the grid. Unlike some other California utilities, LADWP still offers a 1-to-1 retail rate credit for excess generation. Credits can be carried forward for up to 12 months, after which any remaining credits are compensated at a lower wholesale rate. LADWP customers must apply for NEM when installing their solar system.'
    },
    {
      question: 'Are there any Los Angeles-specific solar incentives beyond state programs?',
      answer: 'Yes, Los Angeles offers several city-specific incentives. LADWP provides special solar incentives for multifamily buildings and commercial properties. The city also offers expedited permitting for solar installations and property tax financing through PACE programs. Additionally, certain neighborhoods may qualify for additional incentives through community solar programs and environmental justice initiatives.'
    },
    {
      question: 'How do homeowner association (HOA) restrictions impact solar installation in Los Angeles?',
      answer: 'California has the "Solar Rights Act" which limits the ability of HOAs to restrict solar installations. While HOAs can impose reasonable restrictions on solar panel placement for aesthetic purposes, they cannot prohibit installations or impose restrictions that significantly increase cost or decrease efficiency. If you live in an HOA community in Los Angeles, you should still review your CC&Rs and submit your solar plans according to HOA requirements, but know that state law provides strong protections for your right to go solar.'
    }
  ],
  utilityInfo: 'Los Angeles is primarily served by the Los Angeles Department of Water and Power (LADWP), the nation\'s largest municipal utility. LADWP offers net metering for solar customers and has several solar incentive programs. The utility has committed to 100% renewable energy by 2045 and actively encourages customer solar adoption.',
  citySpecificTips: 'Los Angeles homes often benefit from solar panel placement that maximizes production during peak rate hours (typically 4-9 PM). Consider west-facing panels in addition to south-facing to capture more late afternoon sun when electricity rates are highest. Many LA homeowners also add battery storage to their systems to maximize self-consumption during peak rate times.',
  popularInstallers: [
    {
      name: 'LA Solar Group',
      specialty: 'Residential and commercial installations with local expertise',
      rating: '4.8/5'
    },
    {
      name: 'Solar Optimum',
      specialty: 'Premium installations with battery storage integration',
      rating: '4.7/5'
    },
    {
      name: 'GRID Alternatives',
      specialty: 'Non-profit installer serving low-income communities',
      rating: '4.5/5'
    }
  ]
};

const sanFrancisco: CityData = {
  id: 'san-francisco',
  name: 'San Francisco',
  stateId: 'california',
  stateName: 'California',
  overview: 'San Francisco combines progressive environmental policies with excellent solar incentives, making it a leading city for clean energy adoption. Despite its foggy reputation, the city receives ample sunshine for effective solar power generation, particularly in neighborhoods east of Twin Peaks.',
  imageUrl: 'https://images.unsplash.com/photo-1499310226026-b9d598980b90?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxDYWxpZm9ybmlhJTIwc29sYXIlMjBwYW5lbHMlMjByb29mJTIwbmVpZ2hib3Job29kfGVufDB8fHx8MTc0NzYzNTkzMXww&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800',
  imageAlt: 'San Francisco neighborhood with solar panels visible on rooftops',
  neighborhoods: [
    {
      name: 'Mission District',
      description: 'One of the sunniest neighborhoods in SF with minimal fog, making it ideal for solar installations. Many historic buildings here have been updated with rooftop solar.'
    },
    {
      name: 'Sunset District',
      description: 'Despite its name, this neighborhood receives less direct sunlight due to frequent fog, but installations using high-efficiency panels still perform well.'
    },
    {
      name: 'Noe Valley',
      description: 'Known as "Solar Valley" to locals due to the high concentration of solar-powered homes in this sunny microclimate.'
    },
    {
      name: 'Potrero Hill',
      description: 'This sunny neighborhood with minimal fog coverage is ideal for solar and has one of the highest adoption rates in the city.'
    },
    {
      name: 'Bayview',
      description: 'Part of several environmental justice initiatives, this neighborhood has seen increasing solar adoption through community and affordable solar programs.'
    }
  ],
  localIncentives: [
    {
      name: 'GoSolarSF Program',
      description: 'The city\'s dedicated solar incentive program provides additional rebates beyond state incentives, with enhanced incentives for low-income residents and businesses in environmental justice areas.',
      eligibility: 'San Francisco residents, businesses, and nonprofits',
      link: 'https://sfwater.org/gosolarsf'
    },
    {
      name: 'San Francisco PACE Financing',
      description: 'Enables property owners to finance solar installations through property tax assessments, with competitive interest rates and long-term financing options.',
      eligibility: 'Property owners in San Francisco',
      link: 'https://www.bayrenresidential.org/get-financing'
    },
    {
      name: 'CleanPowerSF Community Solar',
      description: 'Allows residents without suitable roofs to invest in community solar projects and receive credits on their electricity bills.',
      eligibility: 'CleanPowerSF customers',
      link: 'https://www.cleanpowersf.org/'
    }
  ],
  solarFacts: [
    {
      title: 'Average Sun Hours',
      value: '4.8 hours/day',
      icon: 'Sun'
    },
    {
      title: 'Average System Size',
      value: '5.8 kW',
      icon: 'Zap'
    },
    {
      title: 'Average Cost',
      value: '$17,200 (after incentives)',
      icon: 'DollarSign'
    },
    {
      title: 'Average Payback Period',
      value: '7-9 years',
      icon: 'Clock'
    }
  ],
  faqs: [
    {
      question: 'How does San Francisco\'s fog affect solar panel performance?',
      answer: 'San Francisco\'s iconic fog does reduce solar production compared to consistently sunny areas, but modern solar panels still perform efficiently in diffuse light conditions. Neighborhoods east of Twin Peaks (like Mission, Potrero Hill, and Bayview) receive significantly more sunshine than western neighborhoods (like Sunset and Richmond). Even in foggier areas, annual solar production remains good due to long summer days and mild temperatures, which actually help panels operate more efficiently than in very hot climates.'
    },
    {
      question: 'What is the GoSolarSF program and how does it work?',
      answer: 'GoSolarSF is San Francisco\'s city-specific solar incentive program that provides additional rebates on top of state and federal incentives. Current incentive levels range from $100 to $2,000 per kW depending on system size and applicant type, with higher incentives for low-income residents and businesses in environmental justice areas. The program is administered by the San Francisco Public Utilities Commission and requires using an approved GoSolarSF installer. Funds are limited and distributed on a first-come, first-served basis each fiscal year.'
    },
    {
      question: 'Do San Francisco\'s historic district regulations affect solar installations?',
      answer: 'Yes, properties in San Francisco\'s historic districts may face additional requirements for solar installations. The city\'s Historic Preservation Commission reviews proposed alterations to historic buildings, including solar installations. However, San Francisco has worked to balance historic preservation with renewable energy goals by creating streamlined review processes for minimally visible installations. In most cases, solar can be installed if panels are not visible from public rights-of-way or if they\'re designed to minimize visual impact.'
    },
    {
      question: 'What is CleanPowerSF and how does it relate to rooftop solar?',
      answer: 'CleanPowerSF is San Francisco\'s Community Choice Aggregation (CCA) program that provides residents with cleaner electricity supply options. For solar customers, CleanPowerSF offers competitive net metering rates, often better than PG&E\'s standard NEM program. They provide a Net Energy Metering tariff that credits customers for excess generation at the full retail rate plus a small premium for Green service customers. CleanPowerSF also offers community solar options for residents who can\'t install rooftop solar, allowing them to subscribe to local solar projects and receive bill credits.'
    }
  ],
  utilityInfo: 'San Francisco residents receive electricity delivery service from Pacific Gas & Electric (PG&E), but most customers now receive electricity supply from CleanPowerSF, the city\'s Community Choice Aggregation program. Solar customers can participate in net metering programs through either PG&E or CleanPowerSF, with the latter often offering more favorable terms for excess generation credits.',
  citySpecificTips: 'In San Francisco, panel orientation and microinverters are particularly important due to varying fog patterns. East-facing panels often perform better than expected due to morning sun before fog rolls in. Consider high-efficiency panels and microinverters to maximize production in variable sunlight conditions. Battery storage is increasingly popular to take advantage of time-of-use rate arbitrage.',
  popularInstallers: [
    {
      name: 'Luminalt',
      specialty: 'Local installer with expertise in city permitting and historic districts',
      rating: '4.9/5'
    },
    {
      name: 'SunPower by Occidental Power',
      specialty: 'High-efficiency panel installations for fog-prone areas',
      rating: '4.7/5'
    },
    {
      name: 'SF Solar Power',
      specialty: 'Specializes in Victorian homes and complex roof types',
      rating: '4.6/5'
    }
  ]
};

const sanDiego: CityData = {
  id: 'san-diego',
  name: 'San Diego',
  stateId: 'california',
  stateName: 'California',
  overview: 'San Diego offers some of the best solar conditions in the United States, with abundant sunshine, progressive solar policies, and significant electricity cost savings. The city consistently ranks among the top solar cities nationally and benefits from both excellent solar resources and strong local incentives.',
  neighborhoods: [
    {
      name: 'La Jolla',
      description: 'This coastal community features many luxury homes with large solar arrays, often paired with energy storage and EV charging.'
    },
    {
      name: 'Rancho Bernardo',
      description: 'Known for high solar adoption rates, especially among older homeowners looking to fix energy costs for retirement.'
    },
    {
      name: 'North Park',
      description: 'This urban neighborhood has embraced solar as part of its eco-conscious culture, with many installations on historic craftsman homes.'
    },
    {
      name: 'Scripps Ranch',
      description: 'Featuring larger homes with ideal south-facing roof spaces, this neighborhood has high solar penetration.'
    },
    {
      name: 'Chula Vista',
      description: 'Many new developments in this area include solar as standard, with the city actively promoting renewable energy adoption.'
    }
  ],
  localIncentives: [
    {
      name: 'SDG&E Power Your Drive',
      description: 'Rebates for EV charging stations that can be paired with solar installations.',
      eligibility: 'SDG&E customers installing EV charging equipment',
      link: 'https://www.sdge.com/residential/electric-vehicles/powering-evs/ev-equipment-rebates'
    },
    {
      name: 'SASH Program Enhanced in San Diego',
      description: 'The statewide SASH program offers enhanced incentives in certain San Diego neighborhoods designated as disadvantaged communities.',
      eligibility: 'Low-income homeowners in qualifying census tracts',
      link: 'https://gridalternatives.org/what-we-do/program-administration/sash'
    },
    {
      name: 'San Diego PACE Financing',
      description: 'Property Assessed Clean Energy financing allows homeowners to pay for solar through their property tax bill.',
      eligibility: 'Property owners in San Diego County',
      link: 'https://www.sandiegocounty.gov/content/sdc/pace.html'
    }
  ],
  solarFacts: [
    {
      title: 'Average Sun Hours',
      value: '5.7 hours/day',
      icon: 'Sun'
    },
    {
      title: 'Average System Size',
      value: '6.3 kW',
      icon: 'Zap'
    },
    {
      title: 'Average Cost',
      value: '$17,800 (after incentives)',
      icon: 'DollarSign'
    },
    {
      title: 'Average Payback Period',
      value: '5-7 years',
      icon: 'Clock'
    }
  ],
  faqs: [
    {
      question: 'Why does San Diego have such high electricity rates and how does solar help?',
      answer: 'San Diego Gas & Electric (SDG&E) has some of the highest electricity rates in the nation, currently averaging over 45 cents per kWh on higher tiers. These high rates are attributed to infrastructure investments, wildfire prevention measures, and the region\'s reliance on imported energy. Solar power offers substantial savings by allowing homeowners to generate their own electricity instead of purchasing it at these premium rates. Because of the high baseline rates, solar installations in San Diego often have faster payback periods (typically 5-7 years) compared to other regions.'
    },
    {
      question: 'How does San Diego\'s coastal climate affect solar panel performance?',
      answer: 'San Diego\'s mild coastal climate is actually ideal for solar panel performance. While inland areas may receive slightly more direct sunlight, coastal San Diego benefits from lower temperatures, which improves panel efficiency. Solar panels lose efficiency in extreme heat, so San Diego\'s moderate coastal temperatures (typically 65-75°F) help panels operate closer to their optimal range. Morning coastal clouds ("May Gray" and "June Gloom") typically burn off by midday, allowing for strong solar production during peak hours.'
    },
    {
      question: 'Does San Diego have any special solar permitting requirements?',
      answer: 'San Diego has streamlined solar permitting through its "Expedite" program, making it faster and easier to go solar than in many other jurisdictions. For standard residential installations, permits can often be obtained online in a single day. The city has eliminated some requirements that exist in other areas, such as certain structural engineering reports for typical installations. However, properties in historic districts or certain coastal zones may still require additional permits or reviews. Most professional solar installers in San Diego are familiar with these requirements and handle the entire permitting process.'
    },
    {
      question: 'What battery storage options are popular in San Diego and why?',
      answer: 'Battery storage has become increasingly popular in San Diego due to the combination of frequent Public Safety Power Shutoffs during fire season, high time-of-use rate differentials, and the transition to NEM 3.0. The most popular options include the Tesla Powerwall, Enphase IQ Battery, and LG ESS systems. Many San Diego homeowners are installing batteries to store excess solar production during the day and use it during evening peak hours (4-9 PM) when rates are highest. The federal tax credit applies to batteries when installed with solar, making the economics more favorable.'
    }
  ],
  utilityInfo: 'San Diego is served primarily by San Diego Gas & Electric (SDG&E), which has some of the highest electricity rates in the continental United States. SDG&E offers net metering for solar customers, though the program has transitioned to NEM 3.0 with reduced export compensation rates. The utility also provides time-of-use rate plans that solar customers can leverage to maximize savings.',
  citySpecificTips: 'In San Diego, west-facing panels often perform particularly well due to afternoon sunshine and alignment with peak time-of-use rates. Consider installing a slightly larger system than you might in other regions to account for NEM 3.0\'s reduced export compensation. Battery storage is increasingly essential for new solar installations to maximize savings under current rate structures.',
  popularInstallers: [
    {
      name: 'Stellar Solar',
      specialty: 'Local installer with 20+ years in San Diego market',
      rating: '4.9/5'
    },
    {
      name: 'Semper Solaris',
      specialty: 'Veteran-owned company specializing in solar + battery installations',
      rating: '4.7/5'
    },
    {
      name: 'Sullivan Solar Power',
      specialty: 'Commercial and high-end residential installations',
      rating: '4.8/5'
    }
  ]
};

// New York cities
const newYorkCity: CityData = {
  id: 'new-york-city',
  name: 'New York City',
  stateId: 'new-york',
  stateName: 'New York',
  overview: 'New York City has emerged as a surprising solar success story, with installations growing dramatically despite its dense urban environment. The city offers some of the most generous solar incentives in the country, with special programs for historic buildings and ambitious solar targets as part of the city\'s climate initiatives.',
  neighborhoods: [
    {
      name: 'Staten Island',
      description: 'With more single-family homes than other boroughs, Staten Island leads NYC in residential solar adoption.'
    },
    {
      name: 'Park Slope, Brooklyn',
      description: 'This environmentally conscious neighborhood has many brownstones with flat roofs ideal for solar, despite historic district considerations.'
    },
    {
      name: 'Riverdale, Bronx',
      description: 'More suburban in character, this neighborhood has seen high solar adoption rates on single-family homes.'
    },
    {
      name: 'Long Island City, Queens',
      description: 'Industrial buildings and new developments in this area have embraced commercial solar installations.'
    },
    {
      name: 'East Harlem, Manhattan',
      description: 'Part of several solar equity initiatives, this neighborhood has seen increasing community solar participation.'
    }
  ],
  localIncentives: [
    {
      name: 'NYC Property Tax Abatement',
      description: 'A property tax abatement of 20% of the installation cost spread over 4 years, in addition to state incentives.',
      eligibility: 'Property owners in the five boroughs of NYC',
      link: 'https://www1.nyc.gov/site/finance/benefits/property-property-tax-solar-roof-abatement.page'
    },
    {
      name: 'NYC Solar School Education Program',
      description: 'Special incentives for solar installations on K-12 schools with educational components.',
      eligibility: 'Public and private K-12 schools in NYC',
      link: 'https://www.nycsolarschools.com/'
    },
    {
      name: 'NYC Accelerated Solar Permitting',
      description: 'Streamlined permitting process for qualifying solar installations under 10kW.',
      eligibility: 'Small residential solar installations meeting specific criteria',
      link: 'https://www1.nyc.gov/site/buildings/homeowner/installing-solar-panels.page'
    }
  ],
  solarFacts: [
    {
      title: 'Average Sun Hours',
      value: '4.5 hours/day',
      icon: 'Sun'
    },
    {
      title: 'Average System Size',
      value: '5.2 kW',
      icon: 'Zap'
    },
    {
      title: 'Average Cost',
      value: '$16,300 (after incentives)',
      icon: 'DollarSign'
    },
    {
      title: 'Average Payback Period',
      value: '6-8 years',
      icon: 'Clock'
    }
  ],
  faqs: [
    {
      question: 'How do historic district regulations affect solar installations in NYC?',
      answer: 'Properties in New York City\'s historic districts must obtain approval from the Landmarks Preservation Commission (LPC) before installing solar panels. The LPC has issued guidelines that generally allow solar installations that are minimally visible from public streets. Installations on front-facing roofs typically require special review, while rear-facing or flat roof installations are more readily approved. The city has worked to streamline this process in recent years, and many historic district properties have successfully installed solar. Working with installers experienced in NYC historic districts is essential for navigating this process.'
    },
    {
      question: 'What options exist for NYC apartment dwellers who want solar?',
      answer: 'New York City residents who can\'t install rooftop solar have several options. Community solar allows renters and apartment owners to subscribe to a share of a solar farm located elsewhere in the city or state, receiving credits on their electric bill for their portion of the solar production. Some apartment buildings have installed "shared solar" systems that connect to multiple units. Additionally, green energy ESCOs (Energy Service Companies) allow residents to purchase renewable energy through their existing utility bill, though this doesn\'t provide the same financial savings as direct solar ownership.'
    },
    {
      question: 'How does the NYC Property Tax Abatement work with other solar incentives?',
      answer: 'The NYC Solar Property Tax Abatement provides a tax benefit equal to 20% of the solar installation costs (up to $62,500) distributed over four years. This incentive can be combined with the NY-Sun rebate, the 25% state tax credit (up to $5,000), and the 30% federal tax credit. When all incentives are combined, NYC residents can offset up to 70-75% of the gross cost of going solar. Importantly, the NYC abatement applies to your property tax bill rather than income taxes, making it accessible even to those with limited tax liability.'
    },
    {
      question: 'Are there special considerations for flat roof installations in NYC?',
      answer: 'Flat roofs, common on NYC apartment buildings and brownstones, require different mounting systems than sloped roofs. Most NYC flat roof installations use ballasted racking systems that don\'t penetrate the roof membrane, preserving roof warranties and preventing leaks. These systems typically orient panels at a 10-15 degree tilt and require more spacing between panel rows to prevent shading. NYC building code has specific requirements for wind resistance and setbacks from roof edges. Additionally, flat roof installations must consider roof weight limitations and may require structural engineering assessments, especially for older buildings.'
    }
  ],
  utilityInfo: 'New York City is primarily served by Con Edison for electricity delivery, with various Energy Service Companies (ESCOs) available for supply. Con Edison offers net metering for solar customers, though the program is transitioning to the Value of Distributed Energy Resources (VDER) tariff. The utility also provides time-of-use rate plans that can be advantageous for solar customers with battery storage.',
  citySpecificTips: 'In NYC\'s dense urban environment, be particularly mindful of shading from neighboring buildings and infrastructure. Professional shade analysis is essential before installation. Flat roof installations should maximize available space while meeting setback requirements. For brownstones and historic buildings, consider solar panels with all-black design for aesthetic integration.',
  popularInstallers: [
    {
      name: 'Brooklyn SolarWorks',
      specialty: 'Custom canopy installations for flat roofs and historic buildings',
      rating: '4.8/5'
    },
    {
      name: 'Quixotic Systems',
      specialty: 'Vertical solar installations for building facades',
      rating: '4.7/5'
    },
    {
      name: 'EmPower Solar',
      specialty: 'Residential and commercial installations across all boroughs',
      rating: '4.9/5'
    }
  ]
};

// Texas cities
const houston: CityData = {
  id: 'houston',
  name: 'Houston',
  stateId: 'texas',
  stateName: 'Texas',
  overview: 'Houston combines abundant sunshine with relatively affordable installation costs, making it an increasingly attractive solar market. While electricity rates are lower than in some parts of the country, the city\'s excellent solar resources and available incentives still create compelling financial returns for solar investments.',
  neighborhoods: [
    {
      name: 'The Heights',
      description: 'This historic neighborhood has embraced solar while preserving its distinctive architectural character.'
    },
    {
      name: 'The Woodlands',
      description: 'This master-planned community has high solar adoption rates, with many newer homes pre-wired for solar.'
    },
    {
      name: 'Montrose',
      description: 'Known for environmental consciousness, this central neighborhood has many solar installations on both historic and modern homes.'
    },
    {
      name: 'Katy',
      description: 'This rapidly growing suburb features many new constructions with solar as an upgrade option.'
    },
    {
      name: 'West University Place',
      description: 'This upscale neighborhood has embraced solar as a premium home feature, often combined with home automation.'
    }
  ],
  localIncentives: [
    {
      name: 'Green Mountain Energy Rebate Program',
      description: 'Rebates for residential solar installations for Green Mountain Energy customers.',
      eligibility: 'Green Mountain Energy customers in the Houston area',
      link: 'https://www.greenmountainenergy.com/renewable-rewards-buyback/'
    },
    {
      name: 'Solar United Neighbors Houston Co-op',
      description: 'Periodic group purchase programs that secure discounted pricing for participants.',
      eligibility: 'Homeowners in the Greater Houston area during active co-op periods',
      link: 'https://www.solarunitedneighbors.org/texas/'
    },
    {
      name: 'Houston PACE Financing',
      description: 'Property Assessed Clean Energy financing for commercial properties.',
      eligibility: 'Commercial property owners in Houston',
      link: 'https://www.texaspaceauthority.org/houston/'
    }
  ],
  solarFacts: [
    {
      title: 'Average Sun Hours',
      value: '5.4 hours/day',
      icon: 'Sun'
    },
    {
      title: 'Average System Size',
      value: '7.2 kW',
      icon: 'Zap'
    },
    {
      title: 'Average Cost',
      value: '$18,500 (after incentives)',
      icon: 'DollarSign'
    },
    {
      title: 'Average Payback Period',
      value: '9-11 years',
      icon: 'Clock'
    }
  ],
  faqs: [
    {
      question: 'How do Houston\'s frequent storms and hurricanes affect solar panel installations?',
      answer: 'Modern solar installations in Houston are specifically engineered to withstand the region\'s extreme weather. Quality installations can withstand hurricane-force winds up to 140 mph through reinforced mounting hardware and extra roof attachments. Most panels are also rated to withstand 1-inch hail at high velocities. Additionally, many Houston solar installations now include microinverters or power optimizers that allow individual panel monitoring and minimize system-wide impacts from damage to a single panel. Most homeowner\'s insurance policies cover solar panels against storm damage, but it\'s important to notify your insurance provider when adding solar.'
    },
    {
      question: 'Which electricity providers in Houston offer the best solar buyback plans?',
      answer: 'Several retail electricity providers in Houston offer favorable plans for solar customers. Green Mountain Energy\'s "Renewable Rewards" program provides full retail rate credit for excess solar production. MP2 Energy (Shell Energy Solutions) offers their "Solar Buyback" plan with 1-to-1 credit up to monthly consumption. Reliant Energy and Chariot Energy also offer competitive solar plans. When shopping for electricity providers, pay attention to both the buyback rate and other terms like monthly fees and contract length. Rates and offerings change frequently, so check PowerToChoose.org for current solar-friendly options.'
    },
    {
      question: 'Are there any Houston-specific solar incentives beyond the federal tax credit?',
      answer: 'While Houston doesn\'t have a city-wide solar rebate program, several incentives are available. Some retail electricity providers offer special rebates or solar buyback programs. The Solar United Neighbors Houston co-op periodically runs group purchase programs that secure 10-15% discounts for participants. Commercial properties can access PACE financing through the Texas PACE Authority. Additionally, all solar installations in Houston benefit from Texas\'s property tax exemption, which prevents property taxes from increasing due to the added value of solar panels.'
    },
    {
      question: 'How does Houston\'s hot climate affect solar panel performance?',
      answer: 'Houston\'s hot and humid climate presents both advantages and challenges for solar production. The abundant sunshine maximizes solar generation, but high temperatures can slightly reduce panel efficiency, as solar panels become less efficient as they get hotter (typically losing 0.3-0.5% efficiency per degree Celsius above 25°C/77°F). However, this is already factored into production estimates by reputable installers. Proper installation with adequate airflow behind panels helps mitigate temperature impacts. Many Houston installers recommend higher-efficiency panels that perform better in high temperatures, and some homeowners opt for ground-mounted systems that allow better airflow.'
    }
  ],
  utilityInfo: 'Houston is located in the deregulated electricity market of Texas, with CenterPoint Energy serving as the transmission and distribution utility regardless of which retail electricity provider customers choose. This market structure allows solar customers to select from various retail providers offering different solar buyback rates and terms. Shop carefully for providers with favorable net metering or solar buyback programs.',
  citySpecificTips: 'In Houston\'s hot climate, consider installing panels with a slightly greater elevation from the roof surface to allow better airflow and cooling. East-west facing panel arrays often perform better than expected due to longer summer days and steady sunshine. Due to hurricane risk, ensure your installer uses reinforced mounting hardware and additional attachment points beyond minimum code requirements.',
  popularInstallers: [
    {
      name: 'Sunshine Renewable Solutions',
      specialty: 'Local installer with hurricane-resistant mounting systems',
      rating: '4.9/5'
    },
    {
      name: 'Freedom Solar Power',
      specialty: 'SunPower dealer with high-efficiency panel options',
      rating: '4.8/5'
    },
    {
      name: 'Sunnova',
      specialty: 'Solar + battery storage with storm protection features',
      rating: '4.6/5'
    }
  ]
};

export const cities: CityData[] = [
  losAngeles,
  sanFrancisco,
  sanDiego,
  newYorkCity,
  houston
];

export const getCityData = (cityId: string): CityData | undefined => {
  return cities.find(city => city.id === cityId);
};

export const getCitiesByState = (stateId: string): CityData[] => {
  return cities.filter(city => city.stateId === stateId);
};
 