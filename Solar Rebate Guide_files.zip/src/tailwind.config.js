/**  @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Plus Jakarta Sans', 'system-ui', 'sans-serif'],
        display: ['Outfit', 'system-ui', 'sans-serif']
      },
      colors: {
        primary: {
          50: '#eefbf2',
          100: '#d6f5e1',
          200: '#b0eac8',
          300: '#7dd8a8',
          400: '#4ac486',
          500: '#26a669',
          600: '#158352',
          700: '#116843',
          800: '#105137',
          900: '#0c432f',
          950: '#06251b',
        },
        secondary: {
          50: '#fff9ec',
          100: '#fff1d3',
          200: '#ffe0a5',
          300: '#ffc86d',
          400: '#ffa733',
          500: '#ff8b0d',
          600: '#ff6b00',
          700: '#cc4d02',
          800: '#a13a0a',
          900: '#82310d',
          950: '#461604',
        }
      },
      boxShadow: {
        glass: '0 4px 30px rgba(0, 0, 0, 0.1)'
      }
    },
  },
  plugins: [],
};
 