import  { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import StatePage from './pages/StatePage';
import CityPage from './pages/CityPage';
import NationalPrograms from './pages/NationalPrograms';
import BuyingGuides from './pages/BuyingGuides';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsOfService from './pages/TermsOfService';
import ReportInaccuracy from './pages/ReportInaccuracy';
import Contact from './pages/Contact';
import NotFound from './pages/NotFound';
import AdminLogin from './pages/admin/AdminLogin';
import AdminDashboard from './pages/admin/AdminDashboard';
import SolarConsultation from './pages/SolarConsultation';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="state/:stateId" element={<StatePage />} />
          <Route path="city/:cityId" element={<CityPage />} />
          <Route path="national-programs" element={<NationalPrograms />} />
          <Route path="buying-guides" element={<BuyingGuides />} />
          <Route path="privacy-policy" element={<PrivacyPolicy />} />
          <Route path="terms-of-service" element={<TermsOfService />} />
          <Route path="report-inaccuracy" element={<ReportInaccuracy />} />
          <Route path="contact" element={<Contact />} />
          <Route path="consultation" element={<SolarConsultation />} />
          <Route path="*" element={<NotFound />} />
        </Route>
        <Route path="/admin" element={<AdminLogin />} />
        <Route path="/admin/dashboard/*" element={<AdminDashboard />} />
      </Routes>
    </Router>
  );
}

export default App;
 