import  { Link, useOutletContext } from 'react-router-dom';
import { Sun, Search, Star, Users, ChevronDown, ChevronRight, Map, Check, Zap, ArrowRight } from 'lucide-react';
import { useState } from 'react';
import { states } from '../data/states';
import SolarCalculator from '../components/SolarCalculator';

interface ContextType {
  openLeadPopup: () => void;
}

const HomePage = () => {
  const { openLeadPopup } = useOutletContext<ContextType>();
  const [searchValue, setSearchValue] = useState('');
  const [showAllStates, setShowAllStates] = useState(false);
  
  const filteredStates = states.filter(state => 
    state.name.toLowerCase().includes(searchValue.toLowerCase())
  );
  
  const displayedStates = showAllStates ? filteredStates : filteredStates.slice(0, 12);

  return (
    <div>
      {/* Hero section */}
      <section className="bg-gradient-to-br from-primary-600 via-primary-700 to-primary-800 text-white">
        <div className="container-custom py-20 md:py-28">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Find Solar Rebates & Incentives In Your Area
            </h1>
            <p className="text-lg md:text-xl text-white/90 mb-8">
              Discover state and federal solar incentives, calculate your potential savings, and get matched with top-rated solar installers.
            </p>
            
            <div className="bg-white/10 backdrop-blur-sm p-3 rounded-2xl shadow-lg mb-8">
              <div className="flex flex-col md:flex-row">
                <div className="relative flex-grow">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search by state..."
                    className="block w-full pl-12 pr-3 py-3 border-0 rounded-xl bg-white text-gray-800 focus:ring-2 focus:ring-primary-500 focus:outline-none"
                    value={searchValue}
                    onChange={(e) => setSearchValue(e.target.value)}
                  />
                </div>
                <button 
                  onClick={openLeadPopup}
                  className="btn btn-secondary mt-3 md:mt-0 md:ml-3"
                >
                  Find Solar Incentives
                </button>
              </div>
            </div>
            
            <div className="flex items-center text-white/80 text-sm">
              <Check className="h-4 w-4 mr-2" />
              <span>Updated for 2025 federal and state incentives</span>
            </div>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute right-0 top-28 -z-10 opacity-20">
          <svg width="400" height="400" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
            <path fill="#FFFFFF" d="M41.2,-59.8C53.3,-52.9,63.4,-42.2,69.8,-29.1C76.2,-16,78.9,-0.5,74.9,12.8C71,26.1,60.5,37.3,48.7,47.7C36.9,58.1,23.7,67.6,8.2,72.1C-7.3,76.6,-25.2,76.2,-39.7,68.6C-54.2,61,-65.3,46.3,-70.4,30C-75.5,13.7,-74.6,-4.1,-69.9,-20.6C-65.2,-37,-56.5,-52.2,-43.7,-58.9C-30.9,-65.6,-15.5,-63.9,-0.3,-63.3C14.9,-62.8,29.1,-66.7,41.2,-59.8Z" transform="translate(100 100)" />
          </svg>
        </div>
        
        <div className="absolute left-20 bottom-0 -z-10 opacity-10">
          <svg width="300" height="300" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
            <path fill="#FFFFFF" d="M32.5,-54.3C43.9,-48.7,56,-42.8,61.6,-32.8C67.3,-22.8,66.5,-8.7,63.8,4.3C61.1,17.3,56.4,29.4,48.4,39.2C40.4,49,29,56.7,16.2,62.1C3.3,67.5,-11,70.7,-22.9,66.7C-34.9,62.8,-44.6,51.6,-53.1,39.7C-61.7,27.8,-69.1,14.2,-70.9,-0.8C-72.7,-15.7,-68.9,-32,-59.6,-43C-50.4,-54,-35.6,-59.8,-22.2,-64.4C-8.8,-69,4.3,-72.5,15.3,-67.5C26.4,-62.6,21.1,-59.9,32.5,-54.3Z" transform="translate(100 100)" />
          </svg>
        </div>
      </section>
      
      {/* Popular states section */}
      <section className="py-16 md:py-20">
        <div className="container-custom">
          <div className="flex justify-between items-baseline mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Find Solar Rebates By State</h2>
            <Link to="/national-programs" className="text-primary-600 font-medium text-sm flex items-center group">
              View federal programs
              <ChevronRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {displayedStates.map((state) => (
              <Link
                key={state.id}
                to={`/state/${state.id}`}
                className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 hover:shadow-md transition-all hover:border-gray-200 group"
              >
                <div className="flex items-center">
                  <div className="h-8 w-8 rounded-lg bg-primary-100 text-primary-600 flex items-center justify-center mr-3 group-hover:bg-primary-200 transition-colors">
                    <Map className="h-4 w-4" />
                  </div>
                  <span className="font-medium text-gray-900 group-hover:text-primary-600 transition-colors">{state.name}</span>
                </div>
              </Link>
            ))}
          </div>
          
          {filteredStates.length > 12 && !showAllStates && (
            <div className="mt-8 text-center">
              <button
                onClick={() => setShowAllStates(true)}
                className="inline-flex items-center text-primary-600 font-medium bg-primary-50 px-4 py-2 rounded-full hover:bg-primary-100 transition-colors"
              >
                Show all states
                <ChevronDown className="ml-1 h-4 w-4" />
              </button>
            </div>
          )}
        </div>
      </section>
      
      {/* How it works section */}
      <section className="py-16 md:py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-gray-600">
              Our platform makes it easy to understand and access solar incentives in your area,
              helping you maximize your savings when going solar.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 text-center hover:shadow-md transition-all hover:translate-y-[-4px]">
              <div className="bg-primary-100 text-primary-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Search className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Find Incentives</h3>
              <p className="text-gray-600">
                Browse our comprehensive database of solar rebates, tax credits, and incentives available in your state.
              </p>
            </div>
            
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 text-center hover:shadow-md transition-all hover:translate-y-[-4px]">
              <div className="bg-primary-100 text-primary-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Zap className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Calculate Savings</h3>
              <p className="text-gray-600">
                Use our solar calculator to estimate your potential savings with all applicable incentives factored in.
              </p>
            </div>
            
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 text-center hover:shadow-md transition-all hover:translate-y-[-4px]">
              <div className="bg-primary-100 text-primary-600 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Users className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Get Connected</h3>
              <p className="text-gray-600">
                Compare quotes from top-rated solar installers in your area who can help you access all available incentives.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Featured cities */}
      <section className="py-16 md:py-20">
        <div className="container-custom">
          <div className="flex justify-between items-baseline mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Featured Cities</h2>
            <Link to="/state/california" className="text-primary-600 font-medium text-sm flex items-center group">
              View all cities
              <ChevronRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Link to="/city/los-angeles" className="group block rounded-2xl overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1594365458706-6fab3472f681?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxDYWxpZm9ybmlhJTIwc29sYXIlMjBwYW5lbHMlMjByb29mJTIwbmVpZ2hib3Job29kfGVufDB8fHx8MTc0NzYzNTkzMXww&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800" 
                  alt="Los Angeles solar panels" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 via-gray-900/40 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-6 text-white">
                  <div className="bg-primary-600/20 backdrop-blur-sm px-3 py-1 rounded-full text-xs inline-block mb-2">California</div>
                  <h3 className="text-2xl font-bold">Los Angeles</h3>
                  <p className="text-white/80 mt-1 group-hover:text-white transition-colors">View local solar incentives</p>
                </div>
              </div>
            </Link>
            
            <Link to="/city/new-york-city" className="group block rounded-2xl overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1568515387631-8b650bbcdb90?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600&q=80" 
                  alt="New York City skyline" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 via-gray-900/40 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-6 text-white">
                  <div className="bg-primary-600/20 backdrop-blur-sm px-3 py-1 rounded-full text-xs inline-block mb-2">New York</div>
                  <h3 className="text-2xl font-bold">New York City</h3>
                  <p className="text-white/80 mt-1 group-hover:text-white transition-colors">View local solar incentives</p>
                </div>
              </div>
            </Link>
            
            <Link to="/city/houston" className="group block rounded-2xl overflow-hidden shadow-sm">
              <div className="h-64 bg-gray-200 relative overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1605004670071-0d8df1f61157?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600&q=80" 
                  alt="Houston skyline" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 via-gray-900/40 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-6 text-white">
                  <div className="bg-primary-600/20 backdrop-blur-sm px-3 py-1 rounded-full text-xs inline-block mb-2">Texas</div>
                  <h3 className="text-2xl font-bold">Houston</h3>
                  <p className="text-white/80 mt-1 group-hover:text-white transition-colors">View local solar incentives</p>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Calculator section */}
      <section className="py-16 md:py-20 bg-gradient-to-br from-primary-50 to-white">
        <div className="container-custom">
          <div className="bg-white rounded-2xl shadow-md border border-gray-200 p-8 md:p-10">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-8 text-center">Calculate Your Solar Savings</h2>
              <SolarCalculator openLeadPopup={openLeadPopup} />
            </div>
          </div>
        </div>
      </section>
      
      {/* Testimonials */}
      <section className="py-16 md:py-20">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">What Our Users Say</h2>
            <p className="text-gray-600">
              Thousands of homeowners have used our platform to find solar incentives and connect with installers.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 hover:shadow-md transition-all">
              <div className="flex text-amber-400 mb-4">
                <Star className="h-5 w-5 fill-current" />
                <Star className="h-5 w-5 fill-current" />
                <Star className="h-5 w-5 fill-current" />
                <Star className="h-5 w-5 fill-current" />
                <Star className="h-5 w-5 fill-current" />
              </div>
              <p className="text-gray-600 mb-6">
                "Thanks to Solar Rebate Guide, I discovered a local rebate program I didn't know existed. Combined with the federal tax credit, I saved over $10,000 on my installation!"
              </p>
              <div className="flex items-center">
                <div className="h-10 w-10 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center font-bold text-lg">
                  M
                </div>
                <div className="ml-3">
                  <div className="font-medium text-gray-900">Michael T.</div>
                  <div className="text-gray-500 text-sm">San Diego, CA</div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 hover:shadow-md transition-all">
              <div className="flex text-amber-400 mb-4">
                <Star className="h-5 w-5 fill-current" />
                <Star className="h-5 w-5 fill-current" />
                <Star className="h-5 w-5 fill-current" />
                <Star className="h-5 w-5 fill-current" />
                <Star className="h-5 w-5 fill-current" />
              </div>
              <p className="text-gray-600 mb-6">
                "The calculator tool was incredibly helpful in understanding my potential savings. The installer I connected with through the site helped me navigate all the paperwork for incentives."
              </p>
              <div className="flex items-center">
                <div className="h-10 w-10 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center font-bold text-lg">
                  S
                </div>
                <div className="ml-3">
                  <div className="font-medium text-gray-900">Sarah J.</div>
                  <div className="text-gray-500 text-sm">Austin, TX</div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 hover:shadow-md transition-all">
              <div className="flex text-amber-400 mb-4">
                <Star className="h-5 w-5 fill-current" />
                <Star className="h-5 w-5 fill-current" />
                <Star className="h-5 w-5 fill-current" />
                <Star className="h-5 w-5 fill-current" />
                <Star className="h-5 w-5 fill-current" />
              </div>
              <p className="text-gray-600 mb-6">
                "As someone who knew nothing about solar, this site made the whole process so much easier. The state-specific information was accurate and up-to-date, which was crucial for my decision."
              </p>
              <div className="flex items-center">
                <div className="h-10 w-10 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center font-bold text-lg">
                  D
                </div>
                <div className="ml-3">
                  <div className="font-medium text-gray-900">David L.</div>
                  <div className="text-gray-500 text-sm">Denver, CO</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA section */}
      <section className="py-16 md:py-20 bg-gradient-to-br from-primary-600 via-primary-700 to-primary-800 text-white rounded-t-3xl mx-4">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">Ready to Start Saving with Solar?</h2>
            <p className="text-lg opacity-90 mb-8">
              Get personalized information about solar incentives in your area and connect with top-rated installers.
            </p>
            <button 
              onClick={openLeadPopup}
              className="btn bg-white text-primary-700 hover:bg-gray-100 shadow-lg hover:shadow-xl text-lg px-10 py-4 rounded-full flex items-center mx-auto"
            >
              Schedule Your Free Consultation
              <ArrowRight className="ml-3 h-5 w-5" />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
 