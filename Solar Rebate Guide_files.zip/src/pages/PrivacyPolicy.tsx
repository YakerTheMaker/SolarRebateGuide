import  { Sun } from 'lucide-react';

const PrivacyPolicy = () => {
  return (
    <div className="container-custom py-16">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 mb-8">
        <div className="flex items-center mb-8">
          <Sun className="h-8 w-8 text-primary-600 mr-3" />
          <h1 className="text-3xl font-bold">Privacy Policy</h1>
        </div>
        
        <div className="prose max-w-none">
          <p className="text-lg text-gray-600 mb-8">
            Last Updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">1. Introduction</h2>
          <p>
            Welcome to Solar Rebate Guide ("we," "our," or "us"). We are committed to protecting your privacy and personal information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website solarrebateguide.com, including any other media form, media channel, mobile website, or mobile application related or connected thereto (collectively, the "Site").
          </p>
          <p>
            Please read this privacy policy carefully. If you do not agree with the terms of this privacy policy, please do not access the site.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">2. Information We Collect</h2>
          
          <h3 className="text-xl font-bold mt-6 mb-3">Personal Information</h3>
          <p>
            We may collect personal information that you voluntarily provide to us when you fill out forms on our Site, including when you:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Submit a request for a solar quote</li>
            <li>Sign up for our newsletter</li>
            <li>Contact us through our contact form</li>
            <li>Create an account (for administrators)</li>
          </ul>
          <p>
            The personal information we may collect includes:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>First and last name</li>
            <li>Email address</li>
            <li>Phone number</li>
            <li>Mailing/physical address</li>
            <li>Utility provider information</li>
            <li>Energy usage information</li>
          </ul>
          
          <h3 className="text-xl font-bold mt-6 mb-3">Automatically Collected Information</h3>
          <p>
            When you access our Site, we may automatically collect certain information about your device and usage, including:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>IP address</li>
            <li>Browser type</li>
            <li>Operating system</li>
            <li>Access times</li>
            <li>Pages viewed</li>
            <li>Referring website addresses</li>
            <li>Other browsing information</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">3. How We Use Your Information</h2>
          <p>
            We may use the information we collect for various purposes, including to:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Provide, operate, and maintain our Site</li>
            <li>Connect you with solar installers or other service providers</li>
            <li>Send you information about solar incentives in your area</li>
            <li>Respond to your comments, questions, and requests</li>
            <li>Improve our Site and user experience</li>
            <li>Develop new products, services, and features</li>
            <li>Monitor and analyze trends, usage, and activities</li>
            <li>Detect, prevent, and address technical issues</li>
            <li>Comply with legal obligations</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">4. Disclosure of Your Information</h2>
          <p>
            We may share your information in the following situations:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li><strong>Solar Installers and Service Providers:</strong> <span className="font-medium">When you request a solar quote or schedule a consultation, we will share your information with pre-screened solar installers and service providers who will contact you.</span> This is a primary function of our service, and by submitting your information through our forms, you explicitly consent to this sharing.</li>
            <li><strong>Third-Party Service Providers:</strong> We may share your information with third-party vendors, service providers, and other business partners who perform services on our behalf, such as email delivery, hosting services, and analytics.</li>
            <li><strong>Business Transfers:</strong> If we are involved in a merger, acquisition, or sale of all or a portion of our assets, your information may be transferred as part of that transaction.</li>
            <li><strong>Legal Requirements:</strong> We may disclose your information where required by law or if we believe that such action is necessary to comply with legal processes or protect our rights.</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">5. Your Choices</h2>
          <p>
            You can choose not to provide certain information, but this may limit your ability to use certain features of our Site. You can also:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Opt-out of receiving marketing emails by following the unsubscribe instructions</li>
            <li>Request that we delete your personal information by contacting us</li>
            <li>Disable cookies through your browser settings</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">6. Cookies and Tracking Technologies</h2>
          <p>
            We use cookies and similar tracking technologies to track activity on our Site and hold certain information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">7. Data Security</h2>
          <p>
            We have implemented measures to secure your personal information from accidental loss and unauthorized access, use, alteration, and disclosure. However, please be aware that no method of transmission over the internet or electronic storage is 100% secure.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">8. Children's Privacy</h2>
          <p>
            Our Site is not intended for children under 16 years of age. We do not knowingly collect personal information from children under 16.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">9. Changes to Our Privacy Policy</h2>
          <p>
            We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">10. Contact Information</h2>
          <p>
            If you have any questions about this Privacy Policy, please contact us at:
          </p>
          <p className="mb-4">
            <strong>Email:</strong> info@solarrebateguide.com<br />
            <strong>Postal Address:</strong><br />
            YCH LLC<br />
            934 N University Dr PMB 154<br />
            Coral Springs, FL 33071<br />
            United States
          </p>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
 