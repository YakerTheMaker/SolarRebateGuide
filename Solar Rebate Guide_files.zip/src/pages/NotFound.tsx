import  { Link } from 'react-router-dom';
import { Sun, ChevronRight } from 'lucide-react';

const NotFound = () => {
  return (
    <div className="min-h-[70vh] flex items-center justify-center">
      <div className="text-center px-4">
        <div className="flex justify-center mb-6">
          <Sun className="h-16 w-16 text-primary-600" />
        </div>
        <h1 className="text-4xl font-bold mb-4">Page Not Found</h1>
        <p className="text-gray-600 max-w-md mx-auto mb-8">
          We couldn't find the page you were looking for. It might have been moved or no longer exists.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/" className="btn btn-primary">
            Return to Home
          </Link>
          <Link to="/state/california" className="btn btn-white flex items-center justify-center">
            Explore State Incentives <ChevronRight className="ml-1 h-4 w-4" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
 