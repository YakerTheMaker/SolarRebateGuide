import  { useState } from 'react';
import { Edit, Search, ChevronDown, ChevronUp, Trash, Save } from 'lucide-react';
import { states } from '../../data/states';

const AdminStates = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedState, setExpandedState] = useState<string | null>(null);
  const [editMode, setEditMode] = useState<string | null>(null);
  
  const filteredStates = states.filter(state => 
    state.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const toggleState = (stateId: string) => {
    setExpandedState(expandedState === stateId ? null : stateId);
    setEditMode(null);
  };

  const handleEdit = (stateId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditMode(stateId);
    if (expandedState !== stateId) {
      setExpandedState(stateId);
    }
  };

  const handleSave = (stateId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    // In a real app, this would save the edited data to your backend
    setEditMode(null);
  };

  return (
    <div>
      <div className="md:flex md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">State Pages</h1>
          <p className="mt-1 text-sm text-gray-500">
            Manage content for all state-specific solar incentive pages
          </p>
        </div>
      </div>
      
      <div className="bg-white shadow-sm rounded-lg border border-gray-100 overflow-hidden mb-8">
        <div className="p-4 border-b border-gray-100">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search states..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
            />
          </div>
        </div>
        
        <div className="overflow-hidden">
          <ul className="divide-y divide-gray-200">
            {filteredStates.map((state) => (
              <li key={state.id}>
                <button
                  onClick={() => toggleState(state.id)}
                  className="w-full flex justify-between items-center px-6 py-4 hover:bg-gray-50 text-left"
                >
                  <span className="font-medium text-gray-900">{state.name}</span>
                  <div className="flex items-center">
                    <button
                      onClick={(e) => handleEdit(state.id, e)}
                      className="text-gray-400 hover:text-primary-600 mr-2"
                    >
                      <Edit className="h-5 w-5" />
                    </button>
                    {expandedState === state.id ? (
                      <ChevronUp className="h-5 w-5 text-gray-400" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-gray-400" />
                    )}
                  </div>
                </button>
                
                {expandedState === state.id && (
                  <div className="px-6 py-4 bg-gray-50 border-t border-gray-100">
                    {editMode === state.id ? (
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Overview
                          </label>
                          <textarea
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                            rows={3}
                            defaultValue="Solar incentives in this state include rebates, tax credits, and performance-based incentives."
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Solar Potential
                          </label>
                          <input
                            type="text"
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                            defaultValue="Good to excellent solar potential with 5-6 peak sun hours per day"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Average Savings
                          </label>
                          <input
                            type="text"
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                            defaultValue="$15,000 - $25,000 over 20 years"
                          />
                        </div>
                        
                        <div className="border-t border-gray-200 pt-4">
                          <h3 className="text-lg font-medium text-gray-900 mb-2">Incentives</h3>
                          
                          <div className="space-y-4">
                            <div className="border border-gray-200 rounded-lg p-4">
                              <div className="flex justify-between mb-2">
                                <h4 className="font-medium">State Tax Credit</h4>
                                <button className="text-red-600 hover:text-red-800">
                                  <Trash className="h-4 w-4" />
                                </button>
                              </div>
                              
                              <div className="space-y-2">
                                <div>
                                  <label className="block text-xs font-medium text-gray-700">
                                    Description
                                  </label>
                                  <input
                                    type="text"
                                    className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-primary-500 focus:border-primary-500"
                                    defaultValue="State income tax credit of 25% of system costs up to $1,000"
                                  />
                                </div>
                                
                                <div>
                                  <label className="block text-xs font-medium text-gray-700">
                                    Eligibility
                                  </label>
                                  <input
                                    type="text"
                                    className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-primary-500 focus:border-primary-500"
                                    defaultValue="All homeowners with state tax liability"
                                  />
                                </div>
                              </div>
                            </div>
                            
                            <button className="w-full border border-dashed border-gray-300 rounded-lg p-2 text-sm text-gray-600 hover:text-primary-600 hover:border-primary-300">
                              + Add Another Incentive
                            </button>
                          </div>
                        </div>
                        
                        <div className="flex justify-end space-x-3">
                          <button 
                            onClick={() => setEditMode(null)} 
                            className="btn btn-white"
                          >
                            Cancel
                          </button>
                          <button 
                            onClick={(e) => handleSave(state.id, e)} 
                            className="btn btn-primary inline-flex items-center"
                          >
                            <Save className="h-4 w-4 mr-1" />
                            Save Changes
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div>
                          <h3 className="text-lg font-medium text-gray-900 mb-2">Overview</h3>
                          <p className="text-gray-600">
                            Solar incentives in this state include rebates, tax credits, and performance-based incentives.
                          </p>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <h3 className="font-medium text-gray-900 mb-1">Solar Potential</h3>
                            <p className="text-gray-600">
                              Good to excellent solar potential with 5-6 peak sun hours per day
                            </p>
                          </div>
                          
                          <div>
                            <h3 className="font-medium text-gray-900 mb-1">Average Savings</h3>
                            <p className="text-gray-600">
                              $15,000 - $25,000 over 20 years
                            </p>
                          </div>
                        </div>
                        
                        <div>
                          <h3 className="text-lg font-medium text-gray-900 mb-2">Key Incentives</h3>
                          <ul className="space-y-2">
                            <li className="flex items-start">
                              <span className="text-primary-600 mr-2">•</span>
                              <div>
                                <p className="font-medium">State Tax Credit</p>
                                <p className="text-sm text-gray-600">
                                  State income tax credit of 25% of system costs up to $1,000
                                </p>
                              </div>
                            </li>
                            <li className="flex items-start">
                              <span className="text-primary-600 mr-2">•</span>
                              <div>
                                <p className="font-medium">Utility Rebate Program</p>
                                <p className="text-sm text-gray-600">
                                  $0.25 per watt rebate from major utilities
                                </p>
                              </div>
                            </li>
                            <li className="flex items-start">
                              <span className="text-primary-600 mr-2">•</span>
                              <div>
                                <p className="font-medium">Net Metering</p>
                                <p className="text-sm text-gray-600">
                                  1:1 credit for excess energy sent back to the grid
                                </p>
                              </div>
                            </li>
                          </ul>
                        </div>
                        
                        <div className="flex justify-end space-x-3">
                          <a 
                            href={`/state/${state.id}`} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="btn btn-white"
                          >
                            View Live Page
                          </a>
                          <button 
                            onClick={(e) => handleEdit(state.id, e)} 
                            className="btn btn-primary inline-flex items-center"
                          >
                            <Edit className="h-4 w-4 mr-1" />
                            Edit Page
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default AdminStates;
 