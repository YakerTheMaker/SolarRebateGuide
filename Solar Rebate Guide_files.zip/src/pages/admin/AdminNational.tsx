import  { useState } from 'react';
import { Edit, Save, Trash, Plus } from 'lucide-react';

const AdminNational = () => {
  const [editMode, setEditMode] = useState(false);

  const handleSave = () => {
    // In a real app, this would save the edited data to your backend
    setEditMode(false);
  };

  return (
    <div>
      <div className="md:flex md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">National Programs</h1>
          <p className="mt-1 text-sm text-gray-500">
            Manage content for federal solar incentives and nationwide programs
          </p>
        </div>
        <div className="mt-4 md:mt-0">
          {editMode ? (
            <div className="flex space-x-3">
              <button 
                onClick={() => setEditMode(false)} 
                className="btn btn-white"
              >
                Cancel
              </button>
              <button 
                onClick={handleSave} 
                className="btn btn-primary inline-flex items-center"
              >
                <Save className="h-4 w-4 mr-1" />
                Save Changes
              </button>
            </div>
          ) : (
            <button 
              onClick={() => setEditMode(true)} 
              className="btn btn-primary inline-flex items-center"
            >
              <Edit className="h-4 w-4 mr-1" />
              Edit Page
            </button>
          )}
        </div>
      </div>
      
      {editMode ? (
        <div className="bg-white shadow-sm rounded-lg border border-gray-100 overflow-hidden">
          <div className="p-6 space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Page Title
              </label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                defaultValue="National Solar Incentives and Programs"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Page Description
              </label>
              <textarea
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                rows={3}
                defaultValue="Discover federal tax credits, grants, and other nationwide incentives that can help you save thousands on your solar installation."
              />
            </div>
            
            <div className="border-t border-gray-200 pt-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Federal Programs</h3>
                <button className="btn btn-white text-sm inline-flex items-center">
                  <Plus className="h-4 w-4 mr-1" />
                  Add Program
                </button>
              </div>
              
              <div className="space-y-6">
                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex justify-between mb-4">
                    <h4 className="font-medium text-lg">Federal Solar Investment Tax Credit (ITC)</h4>
                    <button className="text-red-600 hover:text-red-800">
                      <Trash className="h-4 w-4" />
                    </button>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Description
                      </label>
                      <textarea
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                        rows={3}
                        defaultValue="The federal solar investment tax credit (ITC) is a tax credit you can claim on your federal income taxes for a percentage of the cost of your solar energy system."
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Details (one per line)
                      </label>
                      <textarea
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                        rows={6}
                        defaultValue="30% tax credit for systems installed between 2022-2032
26% tax credit for systems installed in 2033
22% tax credit for systems installed in 2034
No maximum limit on the credit amount
Applies to both residential and commercial systems
Can be claimed against federal income tax liability"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Eligibility
                      </label>
                      <textarea
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                        rows={3}
                        defaultValue="You must own the solar system (not lease) and have it installed on your primary or secondary residence in the United States. The system must be new or being used for the first time, and it must be installed by December 31, 2034."
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Expiry Date
                        </label>
                        <input
                          type="text"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                          defaultValue="December 31, 2034"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Official Link
                        </label>
                        <input
                          type="url"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                          defaultValue="https://www.energy.gov/eere/solar/homeowners-guide-federal-tax-credit-solar-photovoltaics"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex justify-between mb-4">
                    <h4 className="font-medium text-lg">Energy Efficient Home Improvement Credit</h4>
                    <button className="text-red-600 hover:text-red-800">
                      <Trash className="h-4 w-4" />
                    </button>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Description
                      </label>
                      <textarea
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                        rows={3}
                        defaultValue="Formerly known as the Nonbusiness Energy Property Credit, this tax credit covers energy efficiency improvements to your home."
                      />
                    </div>
                    
                    {/* Additional fields similar to above would be here */}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="border-t border-gray-200 pt-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Frequently Asked Questions</h3>
                <button className="btn btn-white text-sm inline-flex items-center">
                  <Plus className="h-4 w-4 mr-1" />
                  Add FAQ
                </button>
              </div>
              
              <div className="space-y-4">
                <div className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between mb-2">
                    <h4 className="font-medium">How do I claim the Federal Solar Investment Tax Credit?</h4>
                    <button className="text-red-600 hover:text-red-800">
                      <Trash className="h-4 w-4" />
                    </button>
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700">
                      Answer
                    </label>
                    <textarea
                      className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-primary-500 focus:border-primary-500"
                      rows={4}
                      defaultValue="To claim the federal solar ITC, you'll need to complete IRS Form 5695 as part of your federal tax return. This form calculates the credit amount based on your qualified solar expenses. The resulting credit amount is then entered on your 1040 form. If you cannot use the full amount of the credit in one year, you can carry the remainder forward to future tax years. Consult with a tax professional for guidance specific to your situation."
                    />
                  </div>
                </div>
                
                <div className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between mb-2">
                    <h4 className="font-medium">Can I combine federal and state incentives?</h4>
                    <button className="text-red-600 hover:text-red-800">
                      <Trash className="h-4 w-4" />
                    </button>
                  </div>
                  
                  <div>
                    <label className="block text-xs font-medium text-gray-700">
                      Answer
                    </label>
                    <textarea
                      className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-primary-500 focus:border-primary-500"
                      rows={4}
                      defaultValue="Yes, in most cases you can combine federal incentives with state, local, and utility incentives. For example, you can claim the federal ITC and also take advantage of state tax credits, rebates, and performance-based incentives. However, some state incentives may affect the cost basis used to calculate your federal tax credit. Consult with a tax professional to ensure you're maximizing your benefits while remaining compliant with all requirements."
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white shadow-sm rounded-lg border border-gray-100 overflow-hidden">
          <div className="p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Page Overview</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <h3 className="font-medium text-gray-900 mb-2">Page Title</h3>
                <p className="text-gray-600">National Solar Incentives and Programs</p>
              </div>
              
              <div>
                <h3 className="font-medium text-gray-900 mb-2">Last Updated</h3>
                <p className="text-gray-600">June 10, 2023</p>
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="font-medium text-gray-900 mb-2">Page Description</h3>
              <p className="text-gray-600">
                Discover federal tax credits, grants, and other nationwide incentives that can help you save thousands on your solar installation.
              </p>
            </div>
            
            <div className="mb-6">
              <h3 className="font-medium text-gray-900 mb-2">Included Federal Programs</h3>
              <ul className="list-disc list-inside text-gray-600 space-y-1">
                <li>Federal Solar Investment Tax Credit (ITC)</li>
                <li>Energy Efficient Home Improvement Credit</li>
                <li>Energy Efficient Commercial Buildings Deduction (Section 179D)</li>
                <li>Modified Accelerated Cost Recovery System (MACRS)</li>
                <li>Rural Energy for America Program (REAP)</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-gray-900 mb-2">FAQs</h3>
              <p className="text-gray-600">5 frequently asked questions included</p>
            </div>
            
            <div className="border-t border-gray-200 mt-6 pt-6 flex justify-end">
              <a 
                href="/national-programs" 
                target="_blank" 
                rel="noopener noreferrer"
                className="btn btn-white mr-3"
              >
                View Live Page
              </a>
              <button 
                onClick={() => setEditMode(true)} 
                className="btn btn-primary inline-flex items-center"
              >
                <Edit className="h-4 w-4 mr-1" />
                Edit Page
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminNational;
 