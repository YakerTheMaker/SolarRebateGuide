import  { useState } from 'react';
import { BarChart, LineChart, PieChart, ArrowUp, ArrowDown, Filter, Calendar, Download, Users, Globe, FileText } from 'lucide-react';

// Mock data
const websiteStats = {
  totalVisitors: 12847,
  visitorChange: 12.4,
  uniqueVisitors: 8921,
  uniqueVisitorChange: 8.7,
  pageViews: 35428,
  pageViewChange: 15.2,
  avgTimeOnSite: '2m 34s',
  timeOnSiteChange: -3.1,
  bounceRate: '42.8%',
  bounceRateChange: -5.2,
};

const pageVisits = [
  { page: 'Homepage', visits: 3845, change: 12.4 },
  { page: 'California State Page', visits: 2104, change: 18.7 },
  { page: 'Texas State Page', visits: 1876, change: 9.5 },
  { page: 'Federal Programs', visits: 1654, change: 22.1 },
  { page: 'Buying Guides', visits: 1245, change: 4.8 },
];

const AdminDashboardHome = () => {
  const [timeframe, setTimeframe] = useState('30days');

  return (
    <div>
      <div className="md:flex md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="mt-1 text-sm text-gray-500">
            Analytics overview and site performance
          </p>
        </div>
        <div className="mt-4 md:mt-0 flex gap-2">
          <div>
            <select
              value={timeframe}
              onChange={(e) => setTimeframe(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="7days">Last 7 days</option>
              <option value="30days">Last 30 days</option>
              <option value="3months">Last 3 months</option>
              <option value="12months">Last 12 months</option>
            </select>
          </div>
          <button className="btn btn-white flex items-center">
            <Download className="h-4 w-4 mr-1" />
            Export
          </button>
        </div>
      </div>
      
      {/* Stats cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-gray-500">Total Visitors</h3>
            <div className="bg-primary-100 text-primary-600 p-2 rounded-lg">
              <Users className="h-5 w-5" />
            </div>
          </div>
          <div className="flex items-baseline">
            <p className="text-2xl font-bold text-gray-900">{websiteStats.totalVisitors.toLocaleString()}</p>
            <span className={`ml-2 text-sm font-medium ${websiteStats.visitorChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {websiteStats.visitorChange >= 0 ? <ArrowUp className="inline h-3 w-3 mr-0.5" /> : <ArrowDown className="inline h-3 w-3 mr-0.5" />}
              {Math.abs(websiteStats.visitorChange)}%
            </span>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-gray-500">Page Views</h3>
            <div className="bg-primary-100 text-primary-600 p-2 rounded-lg">
              <FileText className="h-5 w-5" />
            </div>
          </div>
          <div className="flex items-baseline">
            <p className="text-2xl font-bold text-gray-900">{websiteStats.pageViews.toLocaleString()}</p>
            <span className={`ml-2 text-sm font-medium ${websiteStats.pageViewChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {websiteStats.pageViewChange >= 0 ? <ArrowUp className="inline h-3 w-3 mr-0.5" /> : <ArrowDown className="inline h-3 w-3 mr-0.5" />}
              {Math.abs(websiteStats.pageViewChange)}%
            </span>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-gray-500">Avg. Time on Site</h3>
            <div className="bg-primary-100 text-primary-600 p-2 rounded-lg">
              <Calendar className="h-5 w-5" />
            </div>
          </div>
          <div className="flex items-baseline">
            <p className="text-2xl font-bold text-gray-900">{websiteStats.avgTimeOnSite}</p>
            <span className={`ml-2 text-sm font-medium ${websiteStats.timeOnSiteChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {websiteStats.timeOnSiteChange >= 0 ? <ArrowUp className="inline h-3 w-3 mr-0.5" /> : <ArrowDown className="inline h-3 w-3 mr-0.5" />}
              {Math.abs(websiteStats.timeOnSiteChange)}%
            </span>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-gray-500">Bounce Rate</h3>
            <div className="bg-primary-100 text-primary-600 p-2 rounded-lg">
              <Globe className="h-5 w-5" />
            </div>
          </div>
          <div className="flex items-baseline">
            <p className="text-2xl font-bold text-gray-900">{websiteStats.bounceRate}</p>
            <span className={`ml-2 text-sm font-medium ${websiteStats.bounceRateChange <= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {websiteStats.bounceRateChange <= 0 ? <ArrowDown className="inline h-3 w-3 mr-0.5" /> : <ArrowUp className="inline h-3 w-3 mr-0.5" />}
              {Math.abs(websiteStats.bounceRateChange)}%
            </span>
          </div>
        </div>
      </div>
      
      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-medium text-gray-900">Traffic Overview</h2>
            <div className="flex items-center text-sm text-gray-500">
              <div className="w-3 h-3 rounded-full bg-primary-500 mr-1.5"></div>
              Visitors
            </div>
          </div>
          
          {/* Line chart placeholder */}
          <div className="h-80 bg-gray-50 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <LineChart className="h-12 w-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-500">Traffic chart visualization would appear here</p>
              <p className="text-sm text-gray-400">Integrated with your analytics platform</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-medium text-gray-900">Leads by Source</h2>
            <button className="text-sm text-gray-500 flex items-center">
              <Filter className="h-4 w-4 mr-1" />
              Filter
            </button>
          </div>
          
          {/* Pie chart placeholder */}
          <div className="h-80 bg-gray-50 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <PieChart className="h-12 w-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-500">Lead source distribution would appear here</p>
              <p className="text-sm text-gray-400">Connected to your lead management system</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Popular pages */}
      <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100 mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-medium text-gray-900">Most Visited Pages</h2>
          <button className="text-sm text-gray-500 flex items-center">
            <Download className="h-4 w-4 mr-1" />
            Export
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Page
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Visits
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Change
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {pageVisits.map((page, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{page.page}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {page.visits.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center text-sm font-medium ${page.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {page.change >= 0 ? <ArrowUp className="h-4 w-4 mr-1" /> : <ArrowDown className="h-4 w-4 mr-1" />}
                      {Math.abs(page.change)}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* User behavior */}
      <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-medium text-gray-900">User Behavior</h2>
          <button className="text-sm text-gray-500 flex items-center">
            <Filter className="h-4 w-4 mr-1" />
            Filter
          </button>
        </div>
        
        {/* Bar chart placeholder */}
        <div className="h-80 bg-gray-50 rounded-lg flex items-center justify-center">
          <div className="text-center">
            <BarChart className="h-12 w-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-500">User behavior analytics would appear here</p>
            <p className="text-sm text-gray-400">Tracks content engagement and user flow</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboardHome;
 