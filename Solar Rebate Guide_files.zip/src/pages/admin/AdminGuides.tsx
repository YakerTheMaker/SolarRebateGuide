import  { useState } from 'react';
import { Edit, Trash, FileText, Plus, ChevronDown, ChevronUp, Save } from 'lucide-react';

const AdminGuides = () => {
  const [expandedGuide, setExpandedGuide] = useState<string | null>(null);
  const [editMode, setEditMode] = useState<string | null>(null);
  
  const guides = [
    {
      id: '1',
      title: "How to Choose the Right Solar Panels",
      slug: "choose-solar-panels",
      description: "Learn about different types of solar panels, their efficiency, warranties, and how to select the best option for your home and budget.",
      sections: 3,
      faqs: 2,
      lastUpdated: "May 15, 2023"
    },
    {
      id: '2',
      title: "How to Calculate Your Solar Needs",
      slug: "calculate-solar-needs",
      description: "Learn how to determine the right system size for your home, understand your energy usage, and estimate how many solar panels you need.",
      sections: 4,
      faqs: 2,
      lastUpdated: "May 20, 2023"
    },
    {
      id: '3',
      title: "Understanding Solar Financing Options",
      slug: "solar-financing",
      description: "Compare different ways to pay for solar: cash purchase, solar loans, leases, and power purchase agreements (PPAs). Learn the pros and cons of each option.",
      sections: 4,
      faqs: 2,
      lastUpdated: "May 25, 2023"
    }
  ];

  const toggleGuide = (guideId: string) => {
    setExpandedGuide(expandedGuide === guideId ? null : guideId);
    setEditMode(null);
  };

  const handleEdit = (guideId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditMode(guideId);
    if (expandedGuide !== guideId) {
      setExpandedGuide(guideId);
    }
  };

  const handleSave = (guideId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    // In a real app, this would save the edited data to your backend
    setEditMode(null);
  };

  return (
    <div>
      <div className="md:flex md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Buying Guides</h1>
          <p className="mt-1 text-sm text-gray-500">
            Manage solar buying guides and educational content
          </p>
        </div>
        <div className="mt-4 md:mt-0">
          <button className="btn btn-primary inline-flex items-center">
            <Plus className="h-4 w-4 mr-1" />
            Create New Guide
          </button>
        </div>
      </div>
      
      <div className="bg-white shadow-sm rounded-lg border border-gray-100 overflow-hidden">
        <ul className="divide-y divide-gray-200">
          {guides.map((guide) => (
            <li key={guide.id}>
              <button
                onClick={() => toggleGuide(guide.id)}
                className="w-full flex justify-between items-center px-6 py-4 hover:bg-gray-50 text-left"
              >
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <FileText className="h-6 w-6 text-gray-400" />
                  </div>
                  <div className="ml-4">
                    <h3 className="font-medium text-gray-900">{guide.title}</h3>
                    <p className="text-sm text-gray-500 mt-1 truncate max-w-md">
                      {guide.description}
                    </p>
                  </div>
                </div>
                <div className="flex items-center">
                  <span className="text-sm text-gray-500 mr-4">Updated: {guide.lastUpdated}</span>
                  <button
                    onClick={(e) => handleEdit(guide.id, e)}
                    className="text-gray-400 hover:text-primary-600 mr-2"
                  >
                    <Edit className="h-5 w-5" />
                  </button>
                  {expandedGuide === guide.id ? (
                    <ChevronUp className="h-5 w-5 text-gray-400" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-gray-400" />
                  )}
                </div>
              </button>
              
              {expandedGuide === guide.id && (
                <div className="px-6 py-4 bg-gray-50 border-t border-gray-100">
                  {editMode === guide.id ? (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Guide Title
                        </label>
                        <input
                          type="text"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                          defaultValue={guide.title}
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Slug (URL)
                        </label>
                        <input
                          type="text"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                          defaultValue={guide.slug}
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Description
                        </label>
                        <textarea
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                          rows={3}
                          defaultValue={guide.description}
                        />
                      </div>
                      
                      <div className="border-t border-gray-200 pt-4">
                        <h3 className="text-lg font-medium text-gray-900 mb-2">Sections</h3>
                        
                        <div className="space-y-4">
                          <div className="border border-gray-200 rounded-lg p-4">
                            <div className="flex justify-between mb-2">
                              <h4 className="font-medium">Types of Solar Panels</h4>
                              <button className="text-red-600 hover:text-red-800">
                                <Trash className="h-4 w-4" />
                              </button>
                            </div>
                            
                            <div>
                              <label className="block text-xs font-medium text-gray-700">
                                Content
                              </label>
                              <textarea
                                className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-primary-500 focus:border-primary-500"
                                rows={6}
                                defaultValue="There are three main types of solar panels for residential use:

- **Monocrystalline**: Highest efficiency (15-22%), longest lifespan, and most expensive
- **Polycrystalline**: Medium efficiency (13-16%), good value, distinctive blue color
- **Thin-Film**: Lowest efficiency (10-13%), least expensive, flexible and lightweight"
                              />
                            </div>
                          </div>
                          
                          <button className="w-full border border-dashed border-gray-300 rounded-lg p-2 text-sm text-gray-600 hover:text-primary-600 hover:border-primary-300">
                            + Add Another Section
                          </button>
                        </div>
                      </div>
                      
                      <div className="border-t border-gray-200 pt-4">
                        <h3 className="text-lg font-medium text-gray-900 mb-2">FAQs</h3>
                        
                        <div className="space-y-4">
                          <div className="border border-gray-200 rounded-lg p-4">
                            <div className="flex justify-between mb-2">
                              <h4 className="font-medium">What's more important: efficiency or cost?</h4>
                              <button className="text-red-600 hover:text-red-800">
                                <Trash className="h-4 w-4" />
                              </button>
                            </div>
                            
                            <div>
                              <label className="block text-xs font-medium text-gray-700">
                                Answer
                              </label>
                              <textarea
                                className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-primary-500 focus:border-primary-500"
                                rows={4}
                                defaultValue="If you have limited roof space, higher efficiency panels may be worth the extra cost. If space isn't a constraint, lower-efficiency panels often provide better value. The best approach is to compare the total cost per watt and projected energy production over the system's lifetime."
                              />
                            </div>
                          </div>
                          
                          <button className="w-full border border-dashed border-gray-300 rounded-lg p-2 text-sm text-gray-600 hover:text-primary-600 hover:border-primary-300">
                            + Add Another FAQ
                          </button>
                        </div>
                      </div>
                      
                      <div className="flex justify-end space-x-3">
                        <button 
                          onClick={() => setEditMode(null)} 
                          className="btn btn-white"
                        >
                          Cancel
                        </button>
                        <button 
                          onClick={(e) => handleSave(guide.id, e)} 
                          className="btn btn-primary inline-flex items-center"
                        >
                          <Save className="h-4 w-4 mr-1" />
                          Save Changes
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-lg font-medium text-gray-900 mb-2">Guide Details</h3>
                        <p className="text-gray-600">
                          {guide.description}
                        </p>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <h4 className="font-medium text-gray-900 mb-1">URL Slug</h4>
                          <p className="text-gray-600">
                            {guide.slug}
                          </p>
                        </div>
                        
                        <div>
                          <h4 className="font-medium text-gray-900 mb-1">Sections</h4>
                          <p className="text-gray-600">
                            {guide.sections} content sections
                          </p>
                        </div>
                        
                        <div>
                          <h4 className="font-medium text-gray-900 mb-1">FAQs</h4>
                          <p className="text-gray-600">
                            {guide.faqs} frequently asked questions
                          </p>
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="text-lg font-medium text-gray-900 mb-2">Section Overview</h3>
                        <ul className="space-y-2">
                          {guide.id === '1' && (
                            <>
                              <li className="flex items-start">
                                <span className="text-primary-600 mr-2">•</span>
                                <p className="font-medium">Types of Solar Panels</p>
                              </li>
                              <li className="flex items-start">
                                <span className="text-primary-600 mr-2">•</span>
                                <p className="font-medium">Key Factors to Consider</p>
                              </li>
                              <li className="flex items-start">
                                <span className="text-primary-600 mr-2">•</span>
                                <p className="font-medium">Top Solar Panel Manufacturers</p>
                              </li>
                            </>
                          )}
                          
                          {guide.id === '2' && (
                            <>
                              <li className="flex items-start">
                                <span className="text-primary-600 mr-2">•</span>
                                <p className="font-medium">Analyze Your Energy Usage</p>
                              </li>
                              <li className="flex items-start">
                                <span className="text-primary-600 mr-2">•</span>
                                <p className="font-medium">Assess Your Solar Potential</p>
                              </li>
                              <li className="flex items-start">
                                <span className="text-primary-600 mr-2">•</span>
                                <p className="font-medium">Calculate System Size</p>
                              </li>
                              <li className="flex items-start">
                                <span className="text-primary-600 mr-2">•</span>
                                <p className="font-medium">Determine Number of Panels</p>
                              </li>
                            </>
                          )}
                          
                          {guide.id === '3' && (
                            <>
                              <li className="flex items-start">
                                <span className="text-primary-600 mr-2">•</span>
                                <p className="font-medium">Cash Purchase</p>
                              </li>
                              <li className="flex items-start">
                                <span className="text-primary-600 mr-2">•</span>
                                <p className="font-medium">Solar Loans</p>
                              </li>
                              <li className="flex items-start">
                                <span className="text-primary-600 mr-2">•</span>
                                <p className="font-medium">Solar Lease</p>
                              </li>
                              <li className="flex items-start">
                                <span className="text-primary-600 mr-2">•</span>
                                <p className="font-medium">Power Purchase Agreement (PPA)</p>
                              </li>
                            </>
                          )}
                        </ul>
                      </div>
                      
                      <div className="flex justify-end space-x-3">
                        <a 
                          href={`/buying-guides#${guide.slug}`} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="btn btn-white"
                        >
                          View Live Guide
                        </a>
                        <button 
                          onClick={(e) => handleEdit(guide.id, e)} 
                          className="btn btn-primary inline-flex items-center"
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Edit Guide
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default AdminGuides;
 