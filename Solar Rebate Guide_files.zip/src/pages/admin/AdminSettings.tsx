import  { useState } from 'react';
import { Save, User, Lock, Mail, Globe } from 'lucide-react';

const AdminSettings = () => {
  const [activeTab, setActiveTab] = useState('account');

  return (
    <div>
      <div className="md:flex md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
          <p className="mt-1 text-sm text-gray-500">
            Manage your account and website settings
          </p>
        </div>
      </div>
      
      <div className="bg-white shadow-sm rounded-lg border border-gray-100 overflow-hidden">
        <div className="flex border-b border-gray-200">
          <button
            className={`px-6 py-3 text-sm font-medium flex items-center ${
              activeTab === 'account'
                ? 'text-primary-600 border-b-2 border-primary-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('account')}
          >
            <User className="h-4 w-4 mr-2" />
            Account
          </button>
          
          <button
            className={`px-6 py-3 text-sm font-medium flex items-center ${
              activeTab === 'security'
                ? 'text-primary-600 border-b-2 border-primary-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('security')}
          >
            <Lock className="h-4 w-4 mr-2" />
            Security
          </button>
          
          <button
            className={`px-6 py-3 text-sm font-medium flex items-center ${
              activeTab === 'notifications'
                ? 'text-primary-600 border-b-2 border-primary-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('notifications')}
          >
            <Mail className="h-4 w-4 mr-2" />
            Notifications
          </button>
          
          <button
            className={`px-6 py-3 text-sm font-medium flex items-center ${
              activeTab === 'site'
                ? 'text-primary-600 border-b-2 border-primary-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('site')}
          >
            <Globe className="h-4 w-4 mr-2" />
            Site Settings
          </button>
        </div>
        
        <div className="p-6">
          {activeTab === 'account' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Profile Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="first-name" className="block text-sm font-medium text-gray-700 mb-1">
                      First Name
                    </label>
                    <input
                      type="text"
                      id="first-name"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                      defaultValue="Admin"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="last-name" className="block text-sm font-medium text-gray-700 mb-1">
                      Last Name
                    </label>
                    <input
                      type="text"
                      id="last-name"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                      defaultValue="User"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="email"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                      defaultValue="admin@solarrebateguide.com"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="role" className="block text-sm font-medium text-gray-700 mb-1">
                      Role
                    </label>
                    <input
                      type="text"
                      id="role"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
                      defaultValue="Administrator"
                      disabled
                    />
                  </div>
                </div>
              </div>
              
              <div className="border-t border-gray-200 pt-6">
                <div className="flex justify-end">
                  <button className="btn btn-primary inline-flex items-center">
                    <Save className="h-4 w-4 mr-1" />
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'security' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Change Password</h3>
                
                <div className="space-y-4">
                  <div>
                    <label htmlFor="current-password" className="block text-sm font-medium text-gray-700 mb-1">
                      Current Password
                    </label>
                    <input
                      type="password"
                      id="current-password"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="new-password" className="block text-sm font-medium text-gray-700 mb-1">
                      New Password
                    </label>
                    <input
                      type="password"
                      id="new-password"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="confirm-password" className="block text-sm font-medium text-gray-700 mb-1">
                      Confirm New Password
                    </label>
                    <input
                      type="password"
                      id="confirm-password"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                    />
                  </div>
                </div>
              </div>
              
              <div className="border-t border-gray-200 pt-6">
                <div className="flex justify-end">
                  <button className="btn btn-primary inline-flex items-center">
                    <Save className="h-4 w-4 mr-1" />
                    Update Password
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'notifications' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Email Notifications</h3>
                
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <input
                        id="new-leads"
                        type="checkbox"
                        className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                        defaultChecked
                      />
                    </div>
                    <div className="ml-3">
                      <label htmlFor="new-leads" className="font-medium text-gray-700">
                        New Lead Notifications
                      </label>
                      <p className="text-gray-500 text-sm">
                        Receive an email when a new lead is submitted through the website
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <input
                        id="content-updates"
                        type="checkbox"
                        className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                        defaultChecked
                      />
                    </div>
                    <div className="ml-3">
                      <label htmlFor="content-updates" className="font-medium text-gray-700">
                        Content Update Notifications
                      </label>
                      <p className="text-gray-500 text-sm">
                        Receive an email when content on the website is updated by other administrators
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <input
                        id="security-alerts"
                        type="checkbox"
                        className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                        defaultChecked
                      />
                    </div>
                    <div className="ml-3">
                      <label htmlFor="security-alerts" className="font-medium text-gray-700">
                        Security Alerts
                      </label>
                      <p className="text-gray-500 text-sm">
                        Receive email notifications about important security events
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-gray-200 pt-6">
                <div className="flex justify-end">
                  <button className="btn btn-primary inline-flex items-center">
                    <Save className="h-4 w-4 mr-1" />
                    Save Preferences
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'site' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">General Settings</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="site-name" className="block text-sm font-medium text-gray-700 mb-1">
                      Website Name
                    </label>
                    <input
                      type="text"
                      id="site-name"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                      defaultValue="Solar Rebate Guide"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="site-url" className="block text-sm font-medium text-gray-700 mb-1">
                      Website URL
                    </label>
                    <input
                      type="url"
                      id="site-url"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                      defaultValue="https://solarrebateguide.com"
                    />
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">SEO Settings</h3>
                
                <div className="space-y-4">
                  <div>
                    <label htmlFor="meta-title" className="block text-sm font-medium text-gray-700 mb-1">
                      Default Meta Title
                    </label>
                    <input
                      type="text"
                      id="meta-title"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                      defaultValue="Solar Rebate Guide - Find Solar Incentives & Rebates in Your State"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="meta-description" className="block text-sm font-medium text-gray-700 mb-1">
                      Default Meta Description
                    </label>
                    <textarea
                      id="meta-description"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                      rows={3}
                      defaultValue="Find and understand solar incentives, rebates, and programs across the United States with our comprehensive state-by-state guides."
                    />
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Lead Settings</h3>
                
                <div className="space-y-4">
                  <div>
                    <label htmlFor="lead-email" className="block text-sm font-medium text-gray-700 mb-1">
                      Lead Notification Email
                    </label>
                    <input
                      type="email"
                      id="lead-email"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                      defaultValue="leads@solarrebateguide.com"
                    />
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <input
                        id="lead-notify"
                        type="checkbox"
                        className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                        defaultChecked
                      />
                    </div>
                    <div className="ml-3">
                      <label htmlFor="lead-notify" className="font-medium text-gray-700">
                        Send Lead Notifications
                      </label>
                      <p className="text-gray-500 text-sm">
                        Email notifications will be sent when new leads are submitted
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-gray-200 pt-6">
                <div className="flex justify-end">
                  <button className="btn btn-primary inline-flex items-center">
                    <Save className="h-4 w-4 mr-1" />
                    Save Settings
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;
 