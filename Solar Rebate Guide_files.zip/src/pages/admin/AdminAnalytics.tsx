import  { useState } from 'react';
import { Save, Plus, Copy, Trash, Info } from 'lucide-react';

const AdminAnalytics = () => {
  const [analyticsCode, setAnalyticsCode] = useState('');
  const [pixelCode, setPixelCode] = useState('');
  const [customHeadTags, setCustomHeadTags] = useState(['']);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleAddHeadTag = () => {
    setCustomHeadTags([...customHeadTags, '']);
  };

  const handleRemoveHeadTag = (index) => {
    const updatedTags = [...customHeadTags];
    updatedTags.splice(index, 1);
    setCustomHeadTags(updatedTags);
  };

  const handleHeadTagChange = (index, value) => {
    const updatedTags = [...customHeadTags];
    updatedTags[index] = value;
    setCustomHeadTags(updatedTags);
  };

  const handleSave = () => {
    // Here you would typically save these settings to your backend
    console.log('Saving analytics settings:', {
      analyticsCode,
      pixelCode,
      customHeadTags: customHeadTags.filter(tag => tag.trim() !== '')
    });
    
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <div>
      <div className="md:flex md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analytics & Tracking</h1>
          <p className="mt-1 text-sm text-gray-500">
            Manage analytics tracking codes and custom head tags
          </p>
        </div>
        <div className="mt-4 md:mt-0">
          <button
            onClick={handleSave}
            className="btn btn-primary inline-flex items-center"
          >
            <Save className="mr-2 h-4 w-4" />
            Save Changes
          </button>
        </div>
      </div>
      
      {saveSuccess && (
        <div className="mb-6 bg-green-50 text-green-800 p-4 rounded-lg flex items-start">
          <Info className="h-5 w-5 mr-2 mt-0.5" />
          <div>
            <p className="font-medium">Settings saved successfully</p>
            <p className="text-sm">Your tracking codes and custom tags have been updated.</p>
          </div>
        </div>
      )}
      
      <div className="bg-white shadow-sm rounded-lg border border-gray-100 overflow-hidden mb-8">
        <div className="px-6 py-5 border-b border-gray-100">
          <h2 className="text-lg font-medium text-gray-900">Google Analytics</h2>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            <p className="text-gray-600 text-sm">
              Add your Google Analytics tracking code to track website traffic and user behavior.
            </p>
            
            <div>
              <label htmlFor="analytics-code" className="block text-sm font-medium text-gray-700 mb-1">
                Google Analytics Tracking ID or Measurement ID
              </label>
              <input
                type="text"
                id="analytics-code"
                placeholder="G-XXXXXXXXXX or UA-XXXXXXXX-X"
                value={analyticsCode}
                onChange={(e) => setAnalyticsCode(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
              />
              <p className="mt-1 text-xs text-gray-500">
                Enter your tracking ID (starts with UA-) or measurement ID (starts with G-).
              </p>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg text-sm text-gray-600">
              <p className="font-medium mb-2">How to find your Google Analytics tracking code:</p>
              <ol className="list-decimal list-inside space-y-1">
                <li>Sign in to your Google Analytics account</li>
                <li>Go to Admin &gt; Property Settings</li>
                <li>Look for "Tracking ID" or "Measurement ID"</li>
                <li>Copy the ID and paste it above</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-white shadow-sm rounded-lg border border-gray-100 overflow-hidden mb-8">
        <div className="px-6 py-5 border-b border-gray-100">
          <h2 className="text-lg font-medium text-gray-900">Facebook Pixel</h2>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            <p className="text-gray-600 text-sm">
              Add your Facebook Pixel code to track conversions from Facebook ads and optimize ad targeting.
            </p>
            
            <div>
              <label htmlFor="pixel-code" className="block text-sm font-medium text-gray-700 mb-1">
                Facebook Pixel ID
              </label>
              <input
                type="text"
                id="pixel-code"
                placeholder="XXXXXXXXXXXXXXXXXX"
                value={pixelCode}
                onChange={(e) => setPixelCode(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
              />
              <p className="mt-1 text-xs text-gray-500">
                Enter your Facebook Pixel ID (usually a 15-16 digit number).
              </p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-white shadow-sm rounded-lg border border-gray-100 overflow-hidden">
        <div className="px-6 py-5 border-b border-gray-100">
          <h2 className="text-lg font-medium text-gray-900">Custom Head Tags</h2>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            <p className="text-gray-600 text-sm mb-4">
              Add custom HTML tags to be inserted in the &lt;head&gt; section of your site. This can include additional tracking scripts, meta tags, or other code.
            </p>
            
            {customHeadTags.map((tag, index) => (
              <div key={index} className="flex items-start space-x-2">
                <textarea
                  value={tag}
                  onChange={(e) => handleHeadTagChange(index, e.target.value)}
                  placeholder="<script>...</script> or <meta ... />"
                  rows={3}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500 font-mono text-sm"
                />
                <button
                  type="button"
                  onClick={() => handleRemoveHeadTag(index)}
                  className="p-2 text-red-600 hover:text-red-800"
                  title="Remove tag"
                >
                  <Trash className="h-4 w-4" />
                </button>
              </div>
            ))}
            
            <button
              type="button"
              onClick={handleAddHeadTag}
              className="flex items-center text-primary-600 hover:text-primary-700 text-sm font-medium"
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Another Tag
            </button>
            
            <div className="bg-gray-50 p-4 rounded-lg text-sm text-gray-600 mt-4">
              <p className="font-medium mb-2">Guidelines for custom head tags:</p>
              <ul className="list-disc list-inside space-y-1">
                <li>Only add valid HTML tags that belong in the &lt;head&gt; section</li>
                <li>Scripts should be enclosed in proper &lt;script&gt; tags</li>
                <li>Each field should contain one complete tag</li>
                <li>Be careful when adding third-party scripts as they may affect site performance</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminAnalytics;
 