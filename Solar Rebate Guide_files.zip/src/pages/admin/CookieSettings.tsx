import  { useState } from 'react';
import { Check, X, Info, Save, RefreshCw } from 'lucide-react';

const CookieSettings = () => {
  const [cookieSettings, setCookieSettings] = useState({
    showBanner: true,
    consentRequired: true,
    bannerPosition: 'bottom',
    essentialCookies: true,
    analyticsCookies: true,
    marketingCookies: true,
    functionalCookies: true,
    cookieExpirationDays: 365,
    privacyPolicyLink: '/privacy-policy',
    customizeOptionsEnabled: true,
    bannerText: "This website uses cookies to enhance your browsing experience, analyze site traffic, and deliver personalized content. We also share information with solar providers to help you obtain quotes. By clicking \"Accept All\", you consent to our use of cookies and data sharing practices as described in our Privacy Policy.",
    saveButtonText: 'Accept All',
    essentialOnlyButtonText: 'Essential Only',
    customizeButtonText: 'Customize',
  });

  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const target = e.target as HTMLInputElement;
      setCookieSettings({
        ...cookieSettings,
        [name]: target.checked,
      });
    } else {
      setCookieSettings({
        ...cookieSettings,
        [name]: value,
      });
    }
  };

  const handleSave = () => {
    // In a real app, this would save to a database or API
    localStorage.setItem('adminCookieSettings', JSON.stringify(cookieSettings));
    setShowSuccessMessage(true);
    setTimeout(() => setShowSuccessMessage(false), 3000);
  };

  const resetConsents = () => {
    if (confirm('This will reset all user cookie consents. Users will see the cookie banner again on their next visit. Are you sure?')) {
      // In a real app, this might trigger a backend process
      console.log('All cookie consents reset');
      alert('All cookie consents have been reset.');
    }
  };

  return (
    <div>
      <div className="md:flex md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Cookie Consent Settings</h1>
          <p className="mt-1 text-sm text-gray-500">
            Configure cookie consent banner and privacy settings
          </p>
        </div>
        <div className="mt-4 md:mt-0 flex gap-2">
          <button
            onClick={() => setShowPreview(!showPreview)}
            className="btn btn-white"
          >
            {showPreview ? 'Hide Preview' : 'Show Preview'}
          </button>
          <button
            onClick={handleSave}
            className="btn btn-primary flex items-center"
          >
            <Save className="mr-2 h-4 w-4" />
            Save Settings
          </button>
        </div>
      </div>
      
      {showSuccessMessage && (
        <div className="mb-6 bg-green-50 text-green-800 p-4 rounded-lg flex items-center">
          <Check className="h-5 w-5 mr-2" />
          <p>Cookie settings saved successfully</p>
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white shadow-sm rounded-lg border border-gray-100 overflow-hidden">
            <div className="px-6 py-5 border-b border-gray-100">
              <h2 className="text-lg font-medium text-gray-900">General Settings</h2>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex items-start">
                  <div className="flex items-center h-5">
                    <input
                      id="showBanner"
                      name="showBanner"
                      type="checkbox"
                      className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                      checked={cookieSettings.showBanner}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="ml-3">
                    <label htmlFor="showBanner" className="font-medium text-gray-700">
                      Show Cookie Consent Banner
                    </label>
                    <p className="text-gray-500 text-sm">
                      Enable or disable the cookie consent banner site-wide
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex items-center h-5">
                    <input
                      id="consentRequired"
                      name="consentRequired"
                      type="checkbox"
                      className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                      checked={cookieSettings.consentRequired}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="ml-3">
                    <label htmlFor="consentRequired" className="font-medium text-gray-700">
                      Require Explicit Consent
                    </label>
                    <p className="text-gray-500 text-sm">
                      User must explicitly consent before non-essential cookies are used
                    </p>
                  </div>
                </div>
                
                <div>
                  <label htmlFor="bannerPosition" className="block text-sm font-medium text-gray-700 mb-1">
                    Banner Position
                  </label>
                  <select
                    id="bannerPosition"
                    name="bannerPosition"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                    value={cookieSettings.bannerPosition}
                    onChange={handleInputChange}
                  >
                    <option value="bottom">Bottom of page</option>
                    <option value="top">Top of page</option>
                    <option value="floating">Floating (bottom-right)</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="cookieExpirationDays" className="block text-sm font-medium text-gray-700 mb-1">
                    Cookie Consent Expiration
                  </label>
                  <div className="mt-1 flex rounded-md shadow-sm">
                    <input
                      type="number"
                      name="cookieExpirationDays"
                      id="cookieExpirationDays"
                      className="flex-1 min-w-0 block w-full px-3 py-2 rounded-none rounded-l-lg border border-gray-300 focus:ring-primary-500 focus:border-primary-500"
                      placeholder="365"
                      value={cookieSettings.cookieExpirationDays}
                      onChange={handleInputChange}
                    />
                    <span className="inline-flex items-center px-3 rounded-r-lg border border-l-0 border-gray-300 bg-gray-50 text-gray-500 text-sm">
                      days
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white shadow-sm rounded-lg border border-gray-100 overflow-hidden mt-8">
            <div className="px-6 py-5 border-b border-gray-100">
              <h2 className="text-lg font-medium text-gray-900">Cookie Categories</h2>
            </div>
            <div className="p-6">
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="flex items-center h-5">
                    <input
                      id="essentialCookies"
                      name="essentialCookies"
                      type="checkbox"
                      className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                      checked={cookieSettings.essentialCookies}
                      onChange={handleInputChange}
                      disabled
                    />
                  </div>
                  <div className="ml-3">
                    <label htmlFor="essentialCookies" className="font-medium text-gray-700">
                      Essential Cookies
                    </label>
                    <p className="text-gray-500 text-sm">
                      Necessary for the website to function (always enabled)
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex items-center h-5">
                    <input
                      id="analyticsCookies"
                      name="analyticsCookies"
                      type="checkbox"
                      className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                      checked={cookieSettings.analyticsCookies}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="ml-3">
                    <label htmlFor="analyticsCookies" className="font-medium text-gray-700">
                      Analytics Cookies
                    </label>
                    <p className="text-gray-500 text-sm">
                      Help understand how visitors interact with the website
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex items-center h-5">
                    <input
                      id="marketingCookies"
                      name="marketingCookies"
                      type="checkbox"
                      className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                      checked={cookieSettings.marketingCookies}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="ml-3">
                    <label htmlFor="marketingCookies" className="font-medium text-gray-700">
                      Marketing Cookies
                    </label>
                    <p className="text-gray-500 text-sm">
                      Used to display personalized advertisements across the Internet
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex items-center h-5">
                    <input
                      id="functionalCookies"
                      name="functionalCookies"
                      type="checkbox"
                      className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                      checked={cookieSettings.functionalCookies}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="ml-3">
                    <label htmlFor="functionalCookies" className="font-medium text-gray-700">
                      Functional Cookies
                    </label>
                    <p className="text-gray-500 text-sm">
                      Enable enhanced functionality and personalization
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white shadow-sm rounded-lg border border-gray-100 overflow-hidden mt-8">
            <div className="px-6 py-5 border-b border-gray-100">
              <h2 className="text-lg font-medium text-gray-900">Banner Content</h2>
            </div>
            <div className="p-6">
              <div className="space-y-6">
                <div>
                  <label htmlFor="bannerText" className="block text-sm font-medium text-gray-700 mb-1">
                    Banner Text
                  </label>
                  <textarea
                    id="bannerText"
                    name="bannerText"
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                    value={cookieSettings.bannerText}
                    onChange={handleInputChange}
                  />
                </div>
                
                <div>
                  <label htmlFor="privacyPolicyLink" className="block text-sm font-medium text-gray-700 mb-1">
                    Privacy Policy URL
                  </label>
                  <input
                    type="text"
                    id="privacyPolicyLink"
                    name="privacyPolicyLink"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                    value={cookieSettings.privacyPolicyLink}
                    onChange={handleInputChange}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label htmlFor="saveButtonText" className="block text-sm font-medium text-gray-700 mb-1">
                      Accept Button Text
                    </label>
                    <input
                      type="text"
                      id="saveButtonText"
                      name="saveButtonText"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                      value={cookieSettings.saveButtonText}
                      onChange={handleInputChange}
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="essentialOnlyButtonText" className="block text-sm font-medium text-gray-700 mb-1">
                      Essential Only Button Text
                    </label>
                    <input
                      type="text"
                      id="essentialOnlyButtonText"
                      name="essentialOnlyButtonText"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                      value={cookieSettings.essentialOnlyButtonText}
                      onChange={handleInputChange}
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="customizeButtonText" className="block text-sm font-medium text-gray-700 mb-1">
                      Customize Button Text
                    </label>
                    <input
                      type="text"
                      id="customizeButtonText"
                      name="customizeButtonText"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                      value={cookieSettings.customizeButtonText}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-1">
          <div className="bg-white shadow-sm rounded-lg border border-gray-100 overflow-hidden sticky top-24">
            <div className="px-6 py-5 border-b border-gray-100">
              <h2 className="text-lg font-medium text-gray-900">Tools</h2>
            </div>
            <div className="p-6">
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Reset Cookie Consents</h3>
                  <p className="text-gray-500 text-sm mb-3">
                    Reset all users' cookie consent preferences. This will prompt all users to see the cookie banner again.
                  </p>
                  <button
                    onClick={resetConsents}
                    className="btn btn-white inline-flex items-center text-sm"
                  >
                    <RefreshCw className="mr-1.5 h-4 w-4" />
                    Reset All Consents
                  </button>
                </div>
                
                <div className="border-t border-gray-100 pt-6">
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Cookie Compliance Info</h3>
                  <div className="bg-blue-50 p-4 rounded-lg text-sm text-blue-800">
                    <div className="flex">
                      <Info className="h-5 w-5 text-blue-500 mr-2 flex-shrink-0" />
                      <div>
                        <p className="font-medium mb-1">GDPR, CCPA, and ePrivacy Compliance</p>
                        <p className="text-blue-700 text-sm mb-2">
                          This cookie consent system is designed to help comply with international privacy regulations including:
                        </p>
                        <ul className="list-disc pl-4 space-y-1 text-blue-700 text-sm">
                          <li>EU General Data Protection Regulation (GDPR)</li>
                          <li>California Consumer Privacy Act (CCPA)</li>
                          <li>ePrivacy Directive ("Cookie Law")</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {showPreview && (
        <div className="fixed bottom-0 left-0 right-0 bg-white shadow-lg border-t border-gray-200 z-50">
          <div className="container-custom py-4 px-4 md:px-6">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
              <div className="flex-grow pr-4">
                <p className="text-sm text-gray-700">
                  {cookieSettings.bannerText}
                </p>
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <button
                  className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50"
                >
                  {cookieSettings.essentialOnlyButtonText}
                </button>
                <button
                  className="px-4 py-2 bg-primary-600 text-white rounded-lg text-sm font-medium hover:bg-primary-700"
                >
                  {cookieSettings.saveButtonText}
                </button>
              </div>
              <button
                className="absolute top-3 right-3 md:hidden p-1 text-gray-500 hover:text-gray-700"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CookieSettings;
 