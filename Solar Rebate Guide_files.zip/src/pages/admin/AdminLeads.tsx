import  { useState } from 'react';
import { ChevronDown, ChevronUp, Download, Search, Filter } from 'lucide-react';

const AdminLeads = () => {
  const [expandedLead, setExpandedLead] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  
  const toggleLead = (id) => {
    setExpandedLead(expandedLead === id ? null : id);
  };
  
  const leads = [
    {
      id: '1',
      name: 'John Smith',
      email: 'john.smith@example.com',
      phone: '(555) 123-4567',
      zipCode: '94123',
      electricBill: '$201-300',
      date: '2023-06-15T14:23:00',
      state: 'California',
      status: 'New'
    },
    {
      id: '2',
      name: 'Sarah Johnson',
      email: 'sarah.j@example.com',
      phone: '(555) 987-6543',
      zipCode: '10001',
      electricBill: '$101-200',
      date: '2023-06-14T10:15:00',
      state: 'New York',
      status: 'Contacted'
    },
    {
      id: '3',
      name: 'Michael Williams',
      email: 'mwilliams@example.com',
      phone: '(555) 456-7890',
      zipCode: '75001',
      electricBill: '$301-400',
      date: '2023-06-14T09:30:00',
      state: 'Texas',
      status: 'New'
    },
    {
      id: '4',
      name: 'Emily Davis',
      email: 'emily.davis@example.com',
      phone: '(555) 234-5678',
      zipCode: '33101',
      electricBill: '$0-100',
      date: '2023-06-13T16:45:00',
      state: 'Florida',
      status: 'Qualified'
    },
    {
      id: '5',
      name: 'Robert Johnson',
      email: 'robert.j@example.com',
      phone: '(555) 876-5432',
      zipCode: '85001',
      electricBill: '$201-300',
      date: '2023-06-13T11:30:00',
      state: 'Arizona',
      status: 'Contacted'
    },
    {
      id: '6',
      name: 'Jennifer Miller',
      email: 'jennifer.m@example.com',
      phone: '(555) 345-6789',
      zipCode: '80202',
      electricBill: '$301-400',
      date: '2023-06-12T09:15:00',
      state: 'Colorado',
      status: 'Qualified'
    },
    {
      id: '7',
      name: 'David Wilson',
      email: 'david.w@example.com',
      phone: '(555) 567-8901',
      zipCode: '98101',
      electricBill: '$401+',
      date: '2023-06-11T14:20:00',
      state: 'Washington',
      status: 'Disqualified'
    },
    {
      id: '8',
      name: 'Lisa Martinez',
      email: 'lisa.m@example.com',
      phone: '(555) 678-9012',
      zipCode: '60601',
      electricBill: '$101-200',
      date: '2023-06-11T10:45:00',
      state: 'Illinois',
      status: 'New'
    }
  ];
  
  const filteredLeads = leads.filter(lead => {
    const matchesSearch = 
      lead.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      lead.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.state.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.zipCode.includes(searchTerm);
    
    const matchesStatus = statusFilter === 'all' || lead.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  return (
    <div>
      <div className="md:flex md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Lead Management</h1>
          <p className="mt-1 text-sm text-gray-500">
            Manage and track leads from your solar quote forms
          </p>
        </div>
        <div className="mt-4 md:mt-0">
          <button className="btn btn-primary flex items-center">
            <Download className="mr-2 h-4 w-4" />
            Export Leads
          </button>
        </div>
      </div>
      
      <div className="bg-white shadow-sm rounded-lg border border-gray-100 overflow-hidden mb-8">
        <div className="p-4 border-b border-gray-200">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search leads..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
              />
            </div>
            
            <div className="w-full md:w-auto">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Filter className="h-4 w-4 text-gray-400" />
                </div>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full md:w-auto pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500 appearance-none"
                >
                  <option value="all">All Status</option>
                  <option value="New">New</option>
                  <option value="Contacted">Contacted</option>
                  <option value="Qualified">Qualified</option>
                  <option value="Disqualified">Disqualified</option>
                </select>
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <ChevronDown className="h-4 w-4 text-gray-400" />
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Name
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Location
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredLeads.map((lead) => (
                <>
                  <tr key={lead.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div>
                          <div className="text-sm font-medium text-gray-900">{lead.name}</div>
                          <div className="text-sm text-gray-500">{lead.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{lead.state}</div>
                      <div className="text-sm text-gray-500">{lead.zipCode}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {new Date(lead.date).toLocaleDateString()}
                      </div>
                      <div className="text-sm text-gray-500">
                        {new Date(lead.date).toLocaleTimeString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        lead.status === 'New' 
                          ? 'bg-green-100 text-green-800' 
                          : lead.status === 'Contacted'
                          ? 'bg-blue-100 text-blue-800'
                          : lead.status === 'Qualified' 
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {lead.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <button 
                        onClick={() => toggleLead(lead.id)}
                        className="text-primary-600 hover:text-primary-900"
                      >
                        {expandedLead === lead.id ? (
                          <ChevronUp className="h-5 w-5" />
                        ) : (
                          <ChevronDown className="h-5 w-5" />
                        )}
                      </button>
                    </td>
                  </tr>
                  
                  {expandedLead === lead.id && (
                    <tr>
                      <td colSpan={5} className="px-6 py-4 bg-gray-50">
                        <div className="text-sm text-gray-900 grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <h4 className="font-medium">Contact Details</h4>
                            <p>Phone: {lead.phone}</p>
                            <p>Email: {lead.email}</p>
                          </div>
                          <div>
                            <h4 className="font-medium">Additional Information</h4>
                            <p>Electric Bill: {lead.electricBill}</p>
                            <p>Source: Website - {lead.state} Page</p>
                          </div>
                          <div className="md:col-span-2 mt-2 flex space-x-2">
                            {lead.status === 'New' && (
                              <button className="btn btn-primary text-sm px-3 py-2">
                                Mark as Contacted
                              </button>
                            )}
                            {(lead.status === 'New' || lead.status === 'Contacted') && (
                              <>
                                <button className="btn btn-white text-sm px-3 py-2 bg-green-50 text-green-700 border-green-200">
                                  Mark as Qualified
                                </button>
                                <button className="btn btn-white text-sm px-3 py-2 bg-red-50 text-red-700 border-red-200">
                                  Mark as Disqualified
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </>
              ))}

              {filteredLeads.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                    No leads match your search criteria
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        <div className="px-6 py-4 border-t border-gray-200 bg-gray-50">
          <div className="flex justify-between items-center">
            <p className="text-sm text-gray-500">
              Showing {filteredLeads.length} of {leads.length} leads
            </p>
            <div className="flex space-x-2">
              <button className="px-3 py-1 border border-gray-300 rounded bg-white text-sm text-gray-700">
                Previous
              </button>
              <button className="px-3 py-1 border border-gray-300 rounded bg-white text-sm text-gray-700">
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-white shadow-sm rounded-lg border border-gray-100 p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Lead Management Tips</h2>
        <ul className="space-y-2 text-sm text-gray-600">
          <li className="flex items-start">
            <div className="flex-shrink-0 h-5 w-5 text-primary-600">•</div>
            <p className="ml-2"><span className="font-medium">New leads</span> should be contacted within 24 hours for best conversion rates.</p>
          </li>
          <li className="flex items-start">
            <div className="flex-shrink-0 h-5 w-5 text-primary-600">•</div>
            <p className="ml-2"><span className="font-medium">Contacted leads</span> should be followed up with after 3-5 days if no response.</p>
          </li>
          <li className="flex items-start">
            <div className="flex-shrink-0 h-5 w-5 text-primary-600">•</div>
            <p className="ml-2"><span className="font-medium">Qualified leads</span> are ready to be connected with solar installers in their area.</p>
          </li>
          <li className="flex items-start">
            <div className="flex-shrink-0 h-5 w-5 text-primary-600">•</div>
            <p className="ml-2">Use the export function to download leads for use in your CRM system.</p>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default AdminLeads;
 