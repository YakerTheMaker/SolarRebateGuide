import  { useState } from 'react';
import { Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import { Menu, X, BarChart, Users, FileText, Map, Settings, Globe, LogOut, Home, Sun, MapPin } from 'lucide-react';
 
import AdminStates from './AdminStates';
import AdminCities from './AdminCities';
import AdminNational from './AdminNational';
import AdminGuides from './AdminGuides';
import AdminLeads from './AdminLeads';
import AdminAnalytics from './AdminAnalytics';
import AdminSettings from './AdminSettings';
import CookieSettings from './CookieSettings';
import AdminDashboardHome from './AdminDashboardHome';
import NotFound from '../NotFound';
 

const AdminDashboard = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  
  const navigation = [
    { name: 'Dashboard', href: '/admin/dashboard', icon: BarChart, current: location.pathname === '/admin/dashboard' },
    { name: 'States', href: '/admin/dashboard/states', icon: Map, current: location.pathname === '/admin/dashboard/states' },
    { name: 'Cities', href: '/admin/dashboard/cities', icon: MapPin, current: location.pathname === '/admin/dashboard/cities' },
    { name: 'National Programs', href: '/admin/dashboard/national', icon: Globe, current: location.pathname === '/admin/dashboard/national' },
    { name: 'Buying Guides', href: '/admin/dashboard/guides', icon: FileText, current: location.pathname === '/admin/dashboard/guides' },
    { name: 'Leads', href: '/admin/dashboard/leads', icon: Users, current: location.pathname === '/admin/dashboard/leads' },
    { name: 'Analytics', href: '/admin/dashboard/analytics', icon: BarChart, current: location.pathname === '/admin/dashboard/analytics' },
    { name: 'Settings', href: '/admin/dashboard/settings', icon: Settings, current: location.pathname === '/admin/dashboard/settings' },
    { name: 'Cookie Settings', href: '/admin/dashboard/cookie-settings', icon: Settings, current: location.pathname === '/admin/dashboard/cookie-settings' },
  ];
  
  const handleLogout = () => {
    // Clear any authentication state/tokens
    // Redirect to login
    navigate('/admin');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile sidebar */}
      <div className="lg:hidden">
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75 z-40" 
             style={{ display: sidebarOpen ? 'block' : 'none' }}
             onClick={() => setSidebarOpen(false)}></div>
        
        <div className={`fixed inset-y-0 left-0 flex flex-col w-64 bg-primary-700 text-white transition-transform duration-300 ease-in-out z-50 transform ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}>
          <div className="flex items-center justify-between h-16 px-4 border-b border-primary-600">
            <div className="flex items-center">
              <Sun className="h-8 w-8 text-white" />
              <span className="ml-2 text-lg font-bold">Solar Rebate Guide</span>
            </div>
            <button onClick={() => setSidebarOpen(false)}>
              <X className="h-6 w-6" />
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto py-4 px-2">
            <nav className="space-y-1">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`${
                    item.current 
                      ? 'bg-primary-800 text-white' 
                      : 'text-white/90 hover:bg-primary-600'
                  } group flex items-center px-3 py-2 text-sm font-medium rounded-md`}
                  onClick={() => setSidebarOpen(false)}
                >
                  <item.icon className="mr-3 h-5 w-5 flex-shrink-0" aria-hidden="true" />
                  {item.name}
                </Link>
              ))}
            </nav>
          </div>
          
          <div className="border-t border-primary-600 p-4">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="h-8 w-8 rounded-full bg-primary-800 flex items-center justify-center text-sm font-medium">
                  A
                </div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-white">Admin User</p>
                <button 
                  onClick={handleLogout}
                  className="text-xs text-white/80 flex items-center mt-1 hover:text-white"
                >
                  <LogOut className="mr-1 h-3 w-3" />
                  Sign out
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Desktop sidebar */}
      <div className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 lg:bg-primary-700 lg:text-white">
        <div className="flex items-center h-16 px-4 border-b border-primary-600">
          <Sun className="h-8 w-8 text-white" />
          <span className="ml-2 text-lg font-bold">Solar Rebate Guide</span>
        </div>
        
        <div className="flex-1 overflow-y-auto py-4 px-2">
          <nav className="space-y-1">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={`${
                  item.current 
                    ? 'bg-primary-800 text-white' 
                    : 'text-white/90 hover:bg-primary-600'
                } group flex items-center px-3 py-2 text-sm font-medium rounded-md`}
              >
                <item.icon className="mr-3 h-5 w-5 flex-shrink-0" aria-hidden="true" />
                {item.name}
              </Link>
            ))}
          </nav>
        </div>
        
        <div className="border-t border-primary-600 p-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="h-8 w-8 rounded-full bg-primary-800 flex items-center justify-center text-sm font-medium">
                A
              </div>
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-white">Admin User</p>
              <button 
                onClick={handleLogout}
                className="text-xs text-white/80 flex items-center mt-1 hover:text-white"
              >
                <LogOut className="mr-1 h-3 w-3" />
                Sign out
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main content */}
      <div className="lg:pl-64">
        <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200 bg-white">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="lg:hidden text-gray-500 hover:text-gray-600"
          >
            <Menu className="h-6 w-6" />
          </button>
          
          <div className="ml-auto flex items-center space-x-4">
            <Link to="/" className="text-gray-500 hover:text-gray-700 flex items-center text-sm">
              <Home className="mr-1 h-4 w-4" />
              View Site
            </Link>
          </div>
        </div>
        
        <main className="p-6">
          <Routes>
            <Route index element={<AdminDashboardHome />} />
            <Route path="states" element={<AdminStates />} />
            <Route path="cities" element={<AdminCities />} />
            <Route path="national" element={<AdminNational />} />
            <Route path="guides" element={<AdminGuides />} />
            <Route path="leads" element={<AdminLeads />} />
            <Route path="analytics" element={<AdminAnalytics />} />
            <Route path="settings" element={<AdminSettings />} />
            <Route path="cookie-settings" element={<CookieSettings />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
      </div>
    </div>
  );
};

export default AdminDashboard;
 