import  { useState } from 'react';
import { Edit, ExternalLink, Plus, Trash, X, Check, Save } from 'lucide-react';
import { cities } from '../../data/cities';

const AdminCities = () => {
  const [editMode, setEditMode] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [stateFilter, setStateFilter] = useState('all');

  const filteredCities = cities.filter(city => {
    const matchesSearch = city.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesState = stateFilter === 'all' || city.stateId === stateFilter;
    return matchesSearch && matchesState;
  });

  const uniqueStates = Array.from(new Set(cities.map(city => city.stateId)));

  return (
    <div>
      <div className="md:flex md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Cities</h1>
          <p className="mt-1 text-sm text-gray-500">
            Manage city-specific solar incentive information
          </p>
        </div>
        <div className="mt-4 md:mt-0">
          <button className="btn btn-primary inline-flex items-center">
            <Plus className="mr-2 h-4 w-4" />
            Add New City
          </button>
        </div>
      </div>

      <div className="bg-white shadow-sm rounded-lg border border-gray-100 overflow-hidden mb-8">
        <div className="p-4 border-b border-gray-200">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <input
                type="text"
                placeholder="Search cities..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
              />
            </div>

            <div>
              <select
                value={stateFilter}
                onChange={(e) => setStateFilter(e.target.value)}
                className="w-full md:w-auto px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
              >
                <option value="all">All States</option>
                {uniqueStates.map((stateId) => (
                  <option key={stateId} value={stateId}>
                    {cities.find(c => c.stateId === stateId)?.stateName || stateId}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  City
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  State
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Neighborhoods
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Local Incentives
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredCities.map((city) => (
                <tr key={city.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{city.name}</div>
                    <div className="text-sm text-gray-500">{city.id}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{city.stateName}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{city.neighborhoods.length} neighborhoods</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{city.localIncentives.length} incentives</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 space-x-2">
                    <button
                      onClick={() => setEditMode(city.id)}
                      className="text-primary-600 hover:text-primary-900"
                    >
                      <Edit className="h-5 w-5" />
                    </button>
                    <a
                      href={`/city/${city.id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-600 hover:text-gray-900"
                    >
                      <ExternalLink className="h-5 w-5" />
                    </a>
                    <button className="text-red-600 hover:text-red-900">
                      <Trash className="h-5 w-5" />
                    </button>
                  </td>
                </tr>
              ))}

              {filteredCities.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                    No cities match your search criteria
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {editMode && (
        <div className="fixed inset-0 bg-black bg-opacity-30 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900">
                Edit City: {cities.find(c => c.id === editMode)?.name}
              </h2>
              <button
                onClick={() => setEditMode(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    City Name
                  </label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                    defaultValue={cities.find(c => c.id === editMode)?.name}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    State
                  </label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                    defaultValue={cities.find(c => c.id === editMode)?.stateId}
                  >
                    {uniqueStates.map((stateId) => (
                      <option key={stateId} value={stateId}>
                        {cities.find(c => c.stateId === stateId)?.stateName || stateId}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Overview
                </label>
                <textarea
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                  rows={3}
                  defaultValue={cities.find(c => c.id === editMode)?.overview}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Image URL
                </label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                  defaultValue={cities.find(c => c.id === editMode)?.imageUrl || ''}
                />
              </div>
              
              <div className="border-t border-gray-200 pt-6">
                <h3 className="text-lg font-medium text-gray-900 mb-3">Neighborhoods</h3>
                
                <div className="space-y-4">
                  {cities.find(c => c.id === editMode)?.neighborhoods.map((neighborhood, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-3">
                        <label className="block text-sm font-medium text-gray-700">
                          Neighborhood {index + 1}
                        </label>
                        <button className="text-red-600 hover:text-red-800">
                          <Trash className="h-4 w-4" />
                        </button>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <input
                            type="text"
                            placeholder="Neighborhood name"
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                            defaultValue={neighborhood.name}
                          />
                        </div>
                        <div>
                          <textarea
                            placeholder="Description"
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                            rows={2}
                            defaultValue={neighborhood.description}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  <button className="w-full border border-dashed border-gray-300 rounded-lg p-3 text-gray-500 hover:text-gray-700 hover:border-gray-400">
                    + Add New Neighborhood
                  </button>
                </div>
              </div>
              
              <div className="border-t border-gray-200 pt-6">
                <h3 className="text-lg font-medium text-gray-900 mb-3">Local Incentives</h3>
                
                <div className="space-y-4">
                  {cities.find(c => c.id === editMode)?.localIncentives.map((incentive, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-3">
                        <label className="block text-sm font-medium text-gray-700">
                          Incentive {index + 1}
                        </label>
                        <button className="text-red-600 hover:text-red-800">
                          <Trash className="h-4 w-4" />
                        </button>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <input
                            type="text"
                            placeholder="Incentive name"
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                            defaultValue={incentive.name}
                          />
                        </div>
                        <div>
                          <textarea
                            placeholder="Description"
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                            rows={2}
                            defaultValue={incentive.description}
                          />
                        </div>
                        <div>
                          <input
                            type="text"
                            placeholder="Eligibility"
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                            defaultValue={incentive.eligibility || ''}
                          />
                        </div>
                        <div>
                          <input
                            type="text"
                            placeholder="Link to more information"
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                            defaultValue={incentive.link || ''}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  <button className="w-full border border-dashed border-gray-300 rounded-lg p-3 text-gray-500 hover:text-gray-700 hover:border-gray-400">
                    + Add New Incentive
                  </button>
                </div>
              </div>
              
              <div className="border-t border-gray-200 pt-6">
                <h3 className="text-lg font-medium text-gray-900 mb-3">FAQs</h3>
                
                <div className="space-y-4">
                  {cities.find(c => c.id === editMode)?.faqs.map((faq, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-3">
                        <label className="block text-sm font-medium text-gray-700">
                          FAQ {index + 1}
                        </label>
                        <button className="text-red-600 hover:text-red-800">
                          <Trash className="h-4 w-4" />
                        </button>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <input
                            type="text"
                            placeholder="Question"
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                            defaultValue={faq.question}
                          />
                        </div>
                        <div>
                          <textarea
                            placeholder="Answer"
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                            rows={4}
                            defaultValue={faq.answer}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  <button className="w-full border border-dashed border-gray-300 rounded-lg p-3 text-gray-500 hover:text-gray-700 hover:border-gray-400">
                    + Add New FAQ
                  </button>
                </div>
              </div>
            </div>
            
            <div className="p-6 border-t border-gray-200 flex justify-end space-x-3">
              <button
                onClick={() => setEditMode(null)}
                className="btn btn-white"
              >
                Cancel
              </button>
              <button className="btn btn-primary inline-flex items-center">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminCities;
 