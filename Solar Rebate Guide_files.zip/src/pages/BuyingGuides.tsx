import  { Link, useOutletContext } from 'react-router-dom';
import { ChevronDown, ChevronRight, ChevronUp, Sun, HelpCircle, Info, Zap } from 'lucide-react';
import { useState } from 'react';

interface AccordionItemProps {
  title: string;
  children: React.ReactNode;
  isOpen: boolean;
  onClick: () => void;
}

const AccordionItem = ({ title, children, isOpen, onClick }: AccordionItemProps) => {
  return (
    <div className="border-b border-gray-200 last:border-b-0">
      <button
        className="w-full flex items-center justify-between py-4 text-left focus:outline-none"
        onClick={onClick}
      >
        <span className="font-semibold text-lg">{title}</span>
        {isOpen ? (
          <ChevronUp className="h-5 w-5 text-gray-500" />
        ) : (
          <ChevronDown className="h-5 w-5 text-gray-500" />
        )}
      </button>
      {isOpen && <div className="pb-4">{children}</div>}
    </div>
  );
};

const BuyingGuides = () => {
  const { openLeadPopup } = useOutletContext<{ openLeadPopup: () => void }>();
  const [openAccordion, setOpenAccordion] = useState<number | null>(0);
  
  const handleAccordionClick = (index: number) => {
    setOpenAccordion(openAccordion === index ? null : index);
  };

  const guides = [
    {
      title: "How to Choose the Right Solar Panels",
      slug: "choose-solar-panels",
      image: "https://images.unsplash.com/photo-1612153018787-4899c6e056d7?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxzb2xhciUyMHBhbmVscyUyMG9uJTIwaG91c2UlMjByb29mJTIwZ3JlZW4lMjBlbmVyZ3l8ZW58MHx8fHwxNzQ3NjMxNjYyfDA&ixlib=rb-4.1.0&fit=fillmax&h=800&w=1200",
      description: "Learn about different types of solar panels, their efficiency, warranties, and how to select the best option for your home and budget.",
      sections: [
        {
          title: "Types of Solar Panels",
          content: "There are three main types of solar panels for residential use:\n\n- **Monocrystalline**: Highest efficiency (15-22%), longest lifespan, and most expensive\n- **Polycrystalline**: Medium efficiency (13-16%), good value, distinctive blue color\n- **Thin-Film**: Lowest efficiency (10-13%), least expensive, flexible and lightweight"
        },
        {
          title: "Key Factors to Consider",
          content: "When choosing solar panels, evaluate these important factors:\n\n- **Efficiency**: Higher efficiency panels generate more power in limited space\n- **Warranty**: Look for 25+ year performance warranties and 10+ year product warranties\n- **Degradation Rate**: Lower annual degradation rates (0.3-0.5%) mean better long-term performance\n- **Temperature Coefficient**: Lower coefficient means better performance in hot climates\n- **Manufacturer Reputation**: Choose established manufacturers with proven track records"
        },
        {
          title: "Top Solar Panel Manufacturers",
          content: "Some of the most reputable solar panel manufacturers include:\n\n- SunPower (high-efficiency premium panels)\n- LG Solar (high-quality with strong warranties)\n- REC Solar (excellent performance and reliability)\n- Panasonic (high-efficiency panels with low degradation)\n- Canadian Solar (good value mid-range panels)\n- Qcells (reliable performance at competitive prices)"
        }
      ],
      faqs: [
        {
          question: "What's more important: efficiency or cost?",
          answer: "If you have limited roof space, higher efficiency panels may be worth the extra cost. If space isn't a constraint, lower-efficiency panels often provide better value. The best approach is to compare the total cost per watt and projected energy production over the system's lifetime."
        },
        {
          question: "Should I wait for newer technology before going solar?",
          answer: "Solar technology does improve gradually, but waiting typically costs you more in continued electricity bills than you'd save with slightly better technology later. Current solar panels are highly efficient and reliable. The best time to go solar is usually as soon as it makes financial sense for your situation."
        }
      ]
    },
    {
      title: "How to Calculate Your Solar Needs",
      slug: "calculate-solar-needs",
      image: "https://images.unsplash.com/photo-1555465910-31f7f20a184d?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwzfHxzb2xhciUyMHBhbmVscyUyMG9uJTIwaG91c2UlMjByb29mJTIwZ3JlZW4lMjBlbmVyZ3l8ZW58MHx8fHwxNzQ3NjMxNjYyfDA&ixlib=rb-4.1.0&fit=fillmax&h=800&w=1200",
      description: "Learn how to determine the right system size for your home, understand your energy usage, and estimate how many solar panels you need.",
      sections: [
        {
          title: "Analyze Your Energy Usage",
          content: "The first step is understanding your current electricity consumption:\n\n- Review 12 months of electricity bills to find your average monthly kilowatt-hour (kWh) usage\n- Note seasonal variations in your energy use\n- Calculate your daily average consumption by dividing your annual usage by 365"
        },
        {
          title: "Assess Your Solar Potential",
          content: "Several factors affect how much solar energy you can produce:\n\n- **Roof orientation**: South-facing is ideal in the Northern Hemisphere\n- **Roof angle**: Typically, an angle equal to your latitude is optimal\n- **Shading**: Trees, buildings, or other obstructions can reduce production\n- **Local climate**: Average sunlight hours in your location\n- **Available roof space**: Measure usable area for panel installation"
        },
        {
          title: "Calculate System Size",
          content: "To determine your system size needs:\n\n1. Divide your daily kWh usage by the average peak sun hours in your area\n2. Divide that number by 0.8 to account for system losses\n3. The result is the estimated system size in kilowatts (kW)\n\nExample: If you use 30 kWh per day and have 5 peak sun hours:\n30 kWh ÷ 5 hours = 6 kW\n6 kW ÷ 0.8 = 7.5 kW system"
        },
        {
          title: "Determine Number of Panels",
          content: "To calculate how many panels you need:\n\n1. Multiply your required system size (in watts) by 1,000\n2. Divide by the wattage of the solar panels you're considering\n\nExample: For a 7.5 kW system using 350W panels:\n7,500 watts ÷ 350 watts = 21-22 panels"
        }
      ],
      faqs: [
        {
          question: "Should I size my system to cover 100% of my electricity needs?",
          answer: "Not necessarily. Some utilities have tiered rate structures or net metering limitations that make it more cost-effective to cover 70-80% of your usage. Consider your utility's specific policies and rate structures when determining the optimal system size."
        },
        {
          question: "Will I need to upgrade my electrical panel for solar?",
          answer: "It depends on your current panel's capacity and age. Older homes with 100-amp service panels may need an upgrade to accommodate solar, while newer homes with 200-amp service typically don't. A solar installer can evaluate your electrical panel during the site assessment."
        }
      ]
    },
    {
      title: "Understanding Solar Financing Options",
      slug: "solar-financing",
      image: "https://images.unsplash.com/photo-1577451581377-523b0a03bb6b?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxzb2xhciUyMHBhbmVscyUyMG9uJTIwaG91c2UlMjByb29mJTIwZ3JlZW4lMjBlbmVyZ3l8ZW58MHx8fHwxNzQ3NjMxNjYyfDA&ixlib=rb-4.1.0&fit=fillmax&h=800&w=1200",
      description: "Compare different ways to pay for solar: cash purchase, solar loans, leases, and power purchase agreements (PPAs). Learn the pros and cons of each option.",
      sections: [
        {
          title: "Cash Purchase",
          content: "**Pros:**\n- Highest long-term savings\n- Own the system and claim all incentives directly\n- No monthly payments or interest\n- Increases home value\n\n**Cons:**\n- Highest upfront cost\n- Responsible for maintenance (though most have long warranties)\n\n**Best for:** Homeowners with available capital who want maximum long-term return on investment"
        },
        {
          title: "Solar Loans",
          content: "**Pros:**\n- Low or no upfront cost\n- Own the system and claim all incentives\n- Fixed monthly payments often less than current electric bill\n- Increases home value\n\n**Cons:**\n- Pay interest over loan term\n- Total cost higher than cash purchase\n- Requires good credit score\n\n**Best for:** Homeowners who want ownership benefits without large upfront payment\n\n**Types:**\n- Solar-specific loans\n- Home equity loans/HELOCs\n- Unsecured personal loans\n- FHA or PACE financing (where available)"
        },
        {
          title: "Solar Lease",
          content: "**Pros:**\n- No upfront cost\n- Predictable monthly payments\n- Maintenance handled by leasing company\n- Option to purchase at end of lease\n\n**Cons:**\n- Don't own the system or claim tax incentives\n- Lower long-term savings\n- May complicate home sale\n- Early termination can be costly\n\n**Best for:** Homeowners who prioritize no upfront cost and maintenance-free operation over maximum savings"
        },
        {
          title: "Power Purchase Agreement (PPA)",
          content: "**Pros:**\n- No upfront cost\n- Pay only for power produced, often at lower rate than utility\n- Provider handles all maintenance\n- May include escalator clause (fixed annual price increase)\n\n**Cons:**\n- Don't own the system or claim incentives\n- Lower lifetime savings than ownership\n- May complicate home sale\n- Typically 20-25 year contracts\n\n**Best for:** Homeowners who want immediate utility savings with zero upfront cost"
        }
      ],
      faqs: [
        {
          question: "Which financing option provides the best return on investment?",
          answer: "Cash purchase typically provides the highest return on investment, followed by solar loans. Leases and PPAs provide lower financial returns but require no upfront investment and minimal responsibility. The best option depends on your financial situation, tax liability, and priorities."
        },
        {
          question: "How do financing options affect available incentives?",
          answer: "With cash purchases and loans, you own the system and can claim the federal tax credit and other incentives directly. With leases and PPAs, the company that owns the system claims these incentives and typically passes some savings to you through lower monthly payments."
        }
      ]
    }
  ];

  const solarShoppingTips = [
    "Get multiple quotes from different installers",
    "Check installer certifications (NABCEP is the gold standard)",
    "Read customer reviews and ask for references",
    "Verify manufacturer warranties and installer workmanship guarantees",
    "Ask about monitoring systems to track performance",
    "Ensure proper permitting and utility interconnection assistance",
    "Understand maintenance requirements and support",
    "Compare price per watt across quotes, not just total price",
    "Verify system production estimates and guarantees",
    "Understand escalator clauses in leases and PPAs"
  ];

  return (
    <>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-600 to-primary-700 text-white py-16">
        <div className="container-custom">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            Solar Buying Guides
          </h1>
          <p className="text-lg md:text-xl mb-8 text-primary-50 max-w-3xl">
            Everything you need to know about going solar. From selecting the right equipment to calculating your needs and understanding financing options.
          </p>
          <button 
            onClick={openLeadPopup}
            className="btn btn-secondary"
          >
            Get Expert Solar Advice
          </button>
        </div>
      </section>

      {/* Guides Overview */}
      <section className="py-16">
        <div className="container-custom">
          <div className="grid md:grid-cols-3 gap-8">
            {guides.map((guide, index) => (
              <div key={index} className="card group overflow-hidden">
                <div className="relative h-48">
                  <img
                    src={guide.image}
                    alt={guide.title}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                    <h3 className="text-white text-xl font-bold p-6">{guide.title}</h3>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-gray-600 mb-4">
                    {guide.description}
                  </p>
                  <button 
                    onClick={() => handleAccordionClick(index)}
                    className="text-primary-600 font-medium hover:text-primary-700 inline-flex items-center"
                  >
                    Read guide <ChevronRight className="ml-1 h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Detailed Guides */}
      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <div className="grid md:grid-cols-3 gap-12">
            <div className="md:col-span-2">
              {guides.map((guide, index) => (
                <div 
                  key={index} 
                  id={guide.slug}
                  className={`bg-white rounded-xl shadow-sm border border-gray-100 p-8 mb-12 ${openAccordion === index ? '' : 'hidden'}`}
                >
                  <h2 className="text-3xl font-bold mb-6">{guide.title}</h2>
                  <p className="text-gray-600 mb-8">
                    {guide.description}
                  </p>
                  
                  {guide.sections.map((section, sectionIndex) => (
                    <div key={sectionIndex} className="mb-8">
                      <h3 className="text-xl font-bold mb-4">{section.title}</h3>
                      <div className="prose text-gray-600">
                        {section.content.split('\n\n').map((paragraph, i) => (
                          <p key={i} className="mb-4">
                            {paragraph.includes('**') ? (
                              paragraph.split(/\*\*([^*]+)\*\*/).map((part, j) => (
                                j % 2 === 0 ? part : <strong key={j}>{part}</strong>
                              ))
                            ) : paragraph}
                          </p>
                        ))}
                      </div>
                    </div>
                  ))}
                  
                  <div className="bg-primary-50 rounded-lg p-6 border border-primary-100 mb-8">
                    <h3 className="text-xl font-bold mb-4">Frequently Asked Questions</h3>
                    <div className="space-y-4">
                      {guide.faqs.map((faq, faqIndex) => (
                        <div key={faqIndex}>
                          <h4 className="font-semibold text-lg mb-2">{faq.question}</h4>
                          <p className="text-gray-600">{faq.answer}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center border-t border-gray-200 pt-6">
                    <button 
                      onClick={() => handleAccordionClick(index === 0 ? guides.length - 1 : index - 1)}
                      className="text-primary-600 font-medium hover:text-primary-700 inline-flex items-center"
                    >
                      <ChevronRight className="mr-1 h-4 w-4 rotate-180" /> Previous Guide
                    </button>
                    <button 
                      onClick={() => handleAccordionClick((index + 1) % guides.length)}
                      className="text-primary-600 font-medium hover:text-primary-700 inline-flex items-center"
                    >
                      Next Guide <ChevronRight className="ml-1 h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
              
              {openAccordion === null && (
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
                  <div className="text-center py-12">
                    <Sun className="h-16 w-16 text-primary-600 mx-auto mb-4" />
                    <h2 className="text-2xl font-bold mb-4">Select a Guide to Begin</h2>
                    <p className="text-gray-600 max-w-md mx-auto">
                      Choose one of the guides above to learn more about going solar, including panel selection, system sizing, and financing options.
                    </p>
                  </div>
                </div>
              )}
            </div>
            
            <div className="md:col-span-1">
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-8 sticky top-24">
                <h3 className="text-xl font-bold mb-4">Get Personalized Advice</h3>
                <p className="text-gray-600 mb-6">
                  Want personalized recommendations for your home? Connect with our solar experts for a free consultation.
                </p>
                <button 
                  onClick={openLeadPopup}
                  className="btn btn-primary w-full"
                >
                  Talk to a Solar Expert
                </button>
              </div>
              
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-8">
                <h3 className="text-xl font-bold mb-4">Solar Shopping Tips</h3>
                <ul className="space-y-3">
                  {solarShoppingTips.map((tip, index) => (
                    <li key={index} className="flex items-start">
                      <HelpCircle className="h-5 w-5 text-primary-600 mr-2 mt-0.5" />
                      <span className="text-gray-600">{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 className="text-xl font-bold mb-4">Quick Links</h3>
                <ul className="space-y-2">
                  {guides.map((guide, index) => (
                    <li key={index}>
                      <button
                        onClick={() => handleAccordionClick(index)}
                        className="text-primary-600 hover:text-primary-700 inline-flex items-center"
                      >
                        {guide.title} <ChevronRight className="ml-1 h-4 w-4" />
                      </button>
                    </li>
                  ))}
                  <li className="pt-2 mt-2 border-t border-gray-100">
                    <Link
                      to="/national-programs"
                      className="text-primary-600 hover:text-primary-700 inline-flex items-center"
                    >
                      National Solar Programs <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/state/california"
                      className="text-primary-600 hover:text-primary-700 inline-flex items-center"
                    >
                      State Rebates <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary-600 text-white">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-4">
                Ready to Start Your Solar Journey?
              </h2>
              <p className="text-lg text-primary-50 mb-6">
                Our network of trusted solar installers can provide personalized recommendations and quotes for your home. Get started with a free consultation.
              </p>
              <button 
                onClick={openLeadPopup}
                className="btn btn-secondary"
              >
                Get a Free Solar Consultation
              </button>
            </div>
            <div className="hidden md:block">
              <img
                src="https://images.unsplash.com/photo-1612153018787-4899c6e056d7?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxzb2xhciUyMHBhbmVscyUyMG9uJTIwaG91c2UlMjByb29mJTIwZ3JlZW4lMjBlbmVyZ3l8ZW58MHx8fHwxNzQ3NjMxNjYyfDA&ixlib=rb-4.1.0&fit=fillmax&h=800&w=1200"
                alt="Solar panels on a roof"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default BuyingGuides;
 