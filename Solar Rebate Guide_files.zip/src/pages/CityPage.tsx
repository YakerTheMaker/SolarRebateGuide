import  { useParams, useOutletContext, Link } from 'react-router-dom';
import { useState } from 'react';
import { ChevronDown, ChevronUp, Sun, MapPin, ArrowRight, Download, CheckCircle } from 'lucide-react';
import SolarCalculator from '../components/SolarCalculator';
import NotFound from './NotFound';

interface AccordionItemProps {
  title: string;
  children: React.ReactNode;
  isOpen: boolean;
  onClick: () => void;
}

const AccordionItem = ({ title, children, isOpen, onClick }: AccordionItemProps) => {
  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden mb-4">
      <button
        onClick={onClick}
        className="w-full flex justify-between items-center p-4 text-left bg-white hover:bg-gray-50 transition-colors"
      >
        <span className="font-semibold text-gray-900">{title}</span>
        {isOpen ? <ChevronUp className="h-5 w-5 text-gray-500" /> : <ChevronDown className="h-5 w-5 text-gray-500" />}
      </button>
      {isOpen && (
        <div className="p-4 pt-0 bg-white border-t border-gray-100">
          {children}
        </div>
      )}
    </div>
  );
};

interface ContextType {
  openLeadPopup: () => void;
}

const CityPage = () => {
  const { cityId } = useParams();
  const { openLeadPopup } = useOutletContext<ContextType>();
  const [openAccordion, setOpenAccordion] = useState<string | null>('incentives');
  
  if (!cityId) return <NotFound />;
  
  // Mock getCityData function - this would be imported from your data file
  const getCityData = (id) => {
    return {
      id: id,
      name: "Los Angeles",
      stateId: "california",
      stateName: "California",
      overview: "Los Angeles offers several solar incentives and rebates to help residents and businesses go solar. Combined with California state incentives and the federal tax credit, LA residents can significantly reduce the cost of solar installation.",
      imageUrl: "https://images.unsplash.com/photo-1452626212852-811d58933cae?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwzfHxzb2xhciUyMHBhbmVscyUyMG9uJTIwaG91c2UlMjByb29mfGVufDB8fHx8MTc0NzY3MTkxNXww&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800",
      imageAlt: "Solar panels in Los Angeles",
      solarFacts: [
        { title: "Sun Hours", value: "5.8 hrs/day", icon: "Sun" },
        { title: "Avg. System Size", value: "6.5 kW", icon: "Zap" },
        { title: "Avg. Savings", value: "$30,000", icon: "DollarSign" },
        { title: "Payback Time", value: "5-7 years", icon: "Clock" }
      ],
      localIncentives: [
        {
          name: "LADWP Solar Incentive Program",
          description: "The Los Angeles Department of Water and Power (LADWP) offers rebates for residential and commercial solar installations.",
          eligibility: "LADWP customers with suitable roof space",
          link: "#"
        },
        {
          name: "Property Tax Exclusion",
          description: "Solar system installations are exempt from property tax assessments in Los Angeles County.",
          eligibility: "All property owners in Los Angeles County",
          link: "#"
        }
      ],
      neighborhoods: [
        {
          name: "Sherman Oaks",
          description: "Popular area for solar with many installations due to high sun exposure and large roof sizes."
        },
        {
          name: "Silver Lake",
          description: "Growing solar adoption with environmentally conscious homeowners and good solar potential."
        },
        {
          name: "Pacific Palisades",
          description: "Higher than average solar adoption rate with larger residential systems."
        },
        {
          name: "Eagle Rock",
          description: "Strong solar community with growing numbers of installations and local support."
        }
      ],
      popularInstallers: [
        {
          name: "SunPower by LA Solar",
          specialty: "High-efficiency premium systems",
          rating: "4.9/5"
        },
        {
          name: "Tesla Solar",
          specialty: "Solar + Powerwall",
          rating: "4.7/5"
        },
        {
          name: "LA Solar Group",
          specialty: "Local installer with competitive pricing",
          rating: "4.8/5"
        }
      ],
      utilityInfo: "Los Angeles is primarily served by the Los Angeles Department of Water and Power (LADWP), which offers net metering for solar customers. Under net metering, excess electricity produced by your solar panels is fed back to the grid, and you receive credits on your utility bill.",
      citySpecificTips: "In Los Angeles, south-facing roofs with minimal shade are ideal for solar. Make sure to check with your homeowners association (if applicable) for any restrictions before installation. The coastal areas may experience morning fog, but this typically burns off by midday and doesn't significantly impact solar production.",
      faqs: [
        {
          question: "How much does solar cost in Los Angeles?",
          answer: "The average cost of a 6kW solar system in Los Angeles is approximately $16,000-$19,000 before incentives. After applying the federal tax credit and local incentives, the net cost typically ranges from $11,000-$13,500."
        },
        {
          question: "Is solar worth it in Los Angeles?",
          answer: "Yes, solar is generally considered an excellent investment in Los Angeles due to high electricity rates, abundant sunshine, and strong incentives. Most homeowners see a payback period of 5-7 years and significant long-term savings."
        },
        {
          question: "How does LADWP net metering work?",
          answer: "LADWP offers one-to-one net metering, meaning you receive full retail value credits for excess electricity your system produces. These credits can offset future electricity bills when your system isn't producing, such as at night."
        }
      ]
    };
  };
  
  const cityData = getCityData(cityId);
  if (!cityData) return <NotFound />;
  
  const toggleAccordion = (accordionId) => {
    setOpenAccordion(openAccordion === accordionId ? null : accordionId);
  };

  return (
    <div>
      {/* Hero section */}
      <div className="bg-gradient-to-r from-primary-600 to-primary-700 text-white pt-16 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-opacity-30 mix-blend-multiply">
          <div className="absolute inset-0 bg-grid-white/[0.1] bg-[length:16px_16px]"></div>
        </div>
        <div className="container-custom relative z-10">
          <div className="max-w-3xl">
            <div className="flex items-center mb-4">
              <Sun className="h-6 w-6 mr-2" />
              <div className="text-sm md:text-base">
                <Link to="/" className="text-white/70 hover:text-white">Home</Link>
                <span className="mx-2">/</span>
                <Link to={`/state/${cityData.stateId}`} className="text-white/70 hover:text-white">{cityData.stateName}</Link>
                <span className="mx-2">/</span>
                <span className="text-white/90">{cityData.name}</span>
              </div>
            </div>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">{cityData.name} Solar Incentives & Rebates</h1>
            <p className="text-lg md:text-xl opacity-90 mb-8">{cityData.overview}</p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button onClick={openLeadPopup} className="btn btn-secondary">
                Get Solar Quotes
              </button>
              <Link to="#calculator" className="btn bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm">
                Calculate Your Savings
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="container-custom py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main column */}
          <div className="lg:col-span-2">
            {/* City image */}
            {cityData.imageUrl && (
              <div className="mb-8 rounded-xl overflow-hidden">
                <img
                  src={cityData.imageUrl}
                  alt={cityData.imageAlt || `Solar panels in ${cityData.name}`}
                  className="w-full h-auto object-cover"
                />
              </div>
            )}
            
            {/* Solar facts */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {cityData.solarFacts.map((fact, index) => (
                <div key={index} className="bg-white p-4 rounded-lg border border-gray-100 text-center">
                  <div className="text-primary-600 mb-2 flex justify-center">
                    {fact.icon === 'Sun' && <Sun className="h-6 w-6" />}
                    {fact.icon === 'Zap' && <Sun className="h-6 w-6" />}
                    {fact.icon === 'DollarSign' && <Download className="h-6 w-6" />}
                    {fact.icon === 'Clock' && <CheckCircle className="h-6 w-6" />}
                  </div>
                  <p className="text-sm text-gray-500">{fact.title}</p>
                  <p className="text-lg font-semibold">{fact.value}</p>
                </div>
              ))}
            </div>
            
            {/* Accordion content */}
            <div className="mb-8">
              <AccordionItem
                title={`Solar Incentives in ${cityData.name}`}
                isOpen={openAccordion === 'incentives'}
                onClick={() => toggleAccordion('incentives')}
              >
                <div className="prose max-w-none">
                  <p className="text-gray-600">
                    {cityData.name} residents can take advantage of several solar incentives and rebates, including both local and state programs:
                  </p>
                  
                  <div className="space-y-6 mt-4">
                    {cityData.localIncentives.map((incentive, index) => (
                      <div key={index} className="bg-gray-50 p-4 rounded-lg border border-gray-100">
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">{incentive.name}</h3>
                        <p className="text-gray-600 mb-3">{incentive.description}</p>
                        {incentive.eligibility && (
                          <div className="text-sm text-gray-500 mb-2">
                            <span className="font-medium text-gray-700">Eligibility:</span> {incentive.eligibility}
                          </div>
                        )}
                        {incentive.link && (
                          <a 
                            href={incentive.link} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-primary-600 hover:text-primary-700 inline-flex items-center text-sm"
                          >
                            Learn more <ArrowRight className="ml-1 h-3 w-3" />
                          </a>
                        )}
                      </div>
                    ))}
                  </div>
                  
                  <div className="bg-primary-50 p-4 rounded-lg mt-6 border border-primary-100">
                    <h4 className="text-primary-800 font-medium mb-2">Also Available: State and Federal Incentives</h4>
                    <p className="text-primary-700 text-sm">
                      In addition to local incentives, {cityData.name} residents can also access {cityData.stateName} state incentives and the federal solar tax credit.
                    </p>
                    <div className="mt-3">
                      <Link 
                        to={`/state/${cityData.stateId}`}
                        className="text-primary-600 hover:text-primary-700 inline-flex items-center text-sm font-medium"
                      >
                        View all {cityData.stateName} solar incentives <ArrowRight className="ml-1 h-3 w-3" />
                      </Link>
                    </div>
                  </div>
                </div>
              </AccordionItem>
              
              <AccordionItem
                title={`${cityData.name} Solar FAQs`}
                isOpen={openAccordion === 'faqs'}
                onClick={() => toggleAccordion('faqs')}
              >
                <div className="space-y-6">
                  {cityData.faqs.map((faq, index) => (
                    <div key={index}>
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">{faq.question}</h3>
                      <p className="text-gray-600">{faq.answer}</p>
                    </div>
                  ))}
                </div>
              </AccordionItem>
              
              <AccordionItem
                title={`${cityData.name} Neighborhoods`}
                isOpen={openAccordion === 'neighborhoods'}
                onClick={() => toggleAccordion('neighborhoods')}
              >
                <div>
                  <p className="text-gray-600 mb-4">
                    Solar adoption varies across {cityData.name} neighborhoods. Here are some areas with notable solar installations:
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {cityData.neighborhoods.map((neighborhood, index) => (
                      <div key={index} className="bg-white border border-gray-100 rounded-lg p-4 shadow-sm">
                        <div className="flex items-start mb-2">
                          <MapPin className="h-5 w-5 text-primary-600 mr-2 flex-shrink-0 mt-0.5" />
                          <h3 className="font-semibold text-gray-900">{neighborhood.name}</h3>
                        </div>
                        <p className="text-gray-600 text-sm">{neighborhood.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </AccordionItem>
              
              <AccordionItem
                title="Popular Solar Installers"
                isOpen={openAccordion === 'installers'}
                onClick={() => toggleAccordion('installers')}
              >
                <div>
                  <p className="text-gray-600 mb-4">
                    These installers are known for quality work in the {cityData.name} area:
                  </p>
                  
                  <div className="space-y-4">
                    {cityData.popularInstallers.map((installer, index) => (
                      <div key={index} className="flex items-start border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                        <div className="bg-primary-100 rounded-full p-2 mr-3 text-primary-600">
                          <CheckCircle className="h-5 w-5" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{installer.name}</h3>
                          <p className="text-gray-600 text-sm">{installer.specialty}</p>
                          {installer.rating && (
                            <div className="text-amber-500 text-sm mt-1">Rating: {installer.rating}</div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-6 bg-gray-50 p-4 rounded-lg text-center">
                    <p className="text-gray-600 mb-3">
                      Get quotes from top-rated solar installers in {cityData.name}
                    </p>
                    <button 
                      onClick={openLeadPopup}
                      className="btn btn-primary"
                    >
                      Compare Solar Quotes
                    </button>
                  </div>
                </div>
              </AccordionItem>
              
              <AccordionItem
                title={`${cityData.name} Utility Information`}
                isOpen={openAccordion === 'utility'}
                onClick={() => toggleAccordion('utility')}
              >
                <div className="prose max-w-none">
                  <p className="text-gray-600">{cityData.utilityInfo}</p>
                  
                  <div className="mt-4 bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Solar Installation Tips for {cityData.name}</h3>
                    <p className="text-gray-600">{cityData.citySpecificTips}</p>
                  </div>
                </div>
              </AccordionItem>
            </div>
            
            {/* Calculator section */}
            <div id="calculator" className="scroll-mt-20">
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Calculate Your Solar Savings in {cityData.name}</h2>
                <SolarCalculator state={cityData.stateName} openLeadPopup={openLeadPopup} />
              </div>
            </div>
            
            {/* Disclaimer */}
            <div className="bg-gray-50 rounded-lg p-4 text-sm text-gray-500 mb-8">
              <p className="font-medium mb-2">Disclaimer:</p>
              <p>The information provided on this page about solar incentives in {cityData.name}, {cityData.stateName} is for general informational purposes only. Incentive programs, rebates, and policies may change over time. We recommend verifying all information with official sources before making decisions. Please <Link to="/report-inaccuracy" className="text-primary-600 hover:underline">report any inaccuracies</Link> you find on our site.</p>
            </div>
          </div>
          
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sticky top-24">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Ready to Go Solar in {cityData.name}?</h2>
              
              <div className="space-y-4 mb-6">
                <div className="flex items-start">
                  <div className="bg-primary-100 rounded-full p-1.5 mr-3 text-primary-600">
                    <CheckCircle className="h-4 w-4" />
                  </div>
                  <p className="text-gray-600 text-sm">Get multiple quotes from pre-screened installers</p>
                </div>
                <div className="flex items-start">
                  <div className="bg-primary-100 rounded-full p-1.5 mr-3 text-primary-600">
                    <CheckCircle className="h-4 w-4" />
                  </div>
                  <p className="text-gray-600 text-sm">Learn about all available incentives</p>
                </div>
                <div className="flex items-start">
                  <div className="bg-primary-100 rounded-full p-1.5 mr-3 text-primary-600">
                    <CheckCircle className="h-4 w-4" />
                  </div>
                  <p className="text-gray-600 text-sm">Estimate your potential solar savings</p>
                </div>
                <div className="flex items-start">
                  <div className="bg-primary-100 rounded-full p-1.5 mr-3 text-primary-600">
                    <CheckCircle className="h-4 w-4" />
                  </div>
                  <p className="text-gray-600 text-sm">Maximize your return on investment</p>
                </div>
              </div>
              
              <button 
                onClick={openLeadPopup}
                className="btn btn-primary w-full mb-4"
              >
                Get Free Solar Quotes
              </button>
              
              <p className="text-xs text-gray-500 text-center">No obligation quotes from top providers</p>
              
              <div className="mt-8 pt-6 border-t border-gray-100">
                <h3 className="font-semibold text-gray-900 mb-3">Related Resources</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <Link to={`/state/${cityData.stateId}`} className="text-primary-600 hover:text-primary-700">
                      {cityData.stateName} Solar Incentives
                    </Link>
                  </li>
                  <li>
                    <Link to="/national-programs" className="text-primary-600 hover:text-primary-700">
                      Federal Solar Incentives
                    </Link>
                  </li>
                  <li>
                    <Link to="/buying-guides" className="text-primary-600 hover:text-primary-700">
                      Solar Buying Guides
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CityPage;
 