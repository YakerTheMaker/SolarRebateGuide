import  { useOutletContext } from 'react-router-dom';
import { DollarSign, Calendar, Info, ChevronDown, ChevronUp, File, Link, HelpCircle } from 'lucide-react';
import { useState } from 'react';

interface AccordionItemProps {
  title: string;
  children: React.ReactNode;
  isOpen: boolean;
  onClick: () => void;
}

const AccordionItem = ({ title, children, isOpen, onClick }: AccordionItemProps) => {
  return (
    <div className="border border-gray-200 rounded-lg mb-4 overflow-hidden">
      <button
        className="w-full flex items-center justify-between py-4 px-6 text-left focus:outline-none bg-white"
        onClick={onClick}
      >
        <span className="font-semibold text-lg">{title}</span>
        {isOpen ? (
          <ChevronUp className="h-5 w-5 text-gray-500" />
        ) : (
          <ChevronDown className="h-5 w-5 text-gray-500" />
        )}
      </button>
      {isOpen && <div className="px-6 pb-6 bg-white">{children}</div>}
    </div>
  );
};

// Custom icon components
const Home = (props: any) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
    <polyline points="9 22 9 12 15 12 15 22"></polyline>
  </svg>
);

const Building = (props: any) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <rect x="4" y="2" width="16" height="20" rx="2" ry="2"></rect>
    <path d="M9 22v-4h6v4"></path>
    <path d="M8 6h.01"></path>
    <path d="M16 6h.01"></path>
    <path d="M12 6h.01"></path>
    <path d="M12 10h.01"></path>
    <path d="M12 14h.01"></path>
    <path d="M16 10h.01"></path>
    <path d="M16 14h.01"></path>
    <path d="M8 10h.01"></path>
    <path d="M8 14h.01"></path>
  </svg>
);

const Leaf = (props: any) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"></path>
    <path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"></path>
  </svg>
);

const NationalPrograms = () => {
  const { openLeadPopup } = useOutletContext<{ openLeadPopup: () => void }>();
  const [openAccordion, setOpenAccordion] = useState<number | null>(0);
  
  const handleAccordionClick = (index: number) => {
    setOpenAccordion(openAccordion === index ? null : index);
  };

  const nationalPrograms = [
    {
      title: "Federal Solar Investment Tax Credit (ITC)",
      description: "The federal solar investment tax credit (ITC) is a tax credit you can claim on your federal income taxes for a percentage of the cost of your solar energy system.",
      details: [
        "30% tax credit for systems installed between 2022-2032",
        "26% tax credit for systems installed in 2033",
        "22% tax credit for systems installed in 2034",
        "No maximum limit on the credit amount",
        "Applies to both residential and commercial systems",
        "Can be claimed against federal income tax liability"
      ],
      eligibility: "You must own the solar system (not lease) and have it installed on your primary or secondary residence in the United States. The system must be new or being used for the first time, and it must be installed by December 31, 2034.",
      expiryDate: "December 31, 2034",
      link: "https://www.energy.gov/eere/solar/homeowners-guide-federal-tax-credit-solar-photovoltaics",
      icon: <File className="h-14 w-14 text-primary-600" />
    },
    {
      title: "Energy Efficient Home Improvement Credit",
      description: "Formerly known as the Nonbusiness Energy Property Credit, this tax credit covers energy efficiency improvements to your home.",
      details: [
        "Up to $1,200 annual credit for energy efficiency improvements",
        "Up to $2,000 credit for heat pumps, biomass stoves, and boilers",
        "Includes improvements like insulation, windows, doors, and energy audits",
        "30% of costs covered for most improvements"
      ],
      eligibility: "You must make qualifying energy-efficient improvements to your existing home, which must be your primary residence located in the United States.",
      expiryDate: "December 31, 2032",
      link: "https://www.energystar.gov/about/federal_tax_credits/non_business_energy_property_tax_credits",
      icon: <Home className="h-14 w-14 text-primary-600" />
    },
    {
      title: "Energy Efficient Commercial Buildings Deduction (Section 179D)",
      description: "A tax deduction for energy-efficient commercial buildings, including those with solar energy systems.",
      details: [
        "Up to $5.00 per square foot for qualifying improvements",
        "Covers improvements to building envelope, HVAC, and lighting systems",
        "Increased deduction amounts starting in 2023",
        "Can be claimed by building owners or designers of government buildings"
      ],
      eligibility: "Commercial building owners or tenants making energy-efficient improvements to buildings located in the United States. For government-owned buildings, the deduction can be allocated to the designer.",
      expiryDate: "Permanent (no expiration)",
      link: "https://www.energystar.gov/buildings/tax_incentives/179d",
      icon: <Building className="h-14 w-14 text-primary-600" />
    },
    {
      title: "Modified Accelerated Cost Recovery System (MACRS)",
      description: "A federal incentive that allows businesses to recover investments in solar energy systems through depreciation deductions.",
      details: [
        "5-year depreciation schedule for solar energy equipment",
        "Bonus depreciation available in certain years",
        "Can be combined with the ITC for enhanced financial benefits",
        "Applies to both solar PV and solar thermal systems"
      ],
      eligibility: "Businesses that own solar energy systems. The system must be used for business or income-producing purposes.",
      expiryDate: "Permanent (no expiration)",
      link: "https://www.energy.gov/eere/solar/depreciation-solar-energy-property-macrs",
      icon: <DollarSign className="h-14 w-14 text-primary-600" />
    },
    {
      title: "Rural Energy for America Program (REAP)",
      description: "Provides guaranteed loan financing and grant funding to agricultural producers and rural small businesses for renewable energy systems or energy efficiency improvements.",
      details: [
        "Grants for up to 50% of total eligible project costs",
        "Loan guarantees for up to 75% of total eligible project costs",
        "Combined grant and loan guarantee funding up to 75% of total costs",
        "Grant amounts: $1,500 minimum, $500,000 maximum",
        "Loan amounts: $5,000 minimum, $25 million maximum"
      ],
      eligibility: "Agricultural producers with at least 50% of gross income coming from agricultural operations and small businesses in eligible rural areas.",
      expiryDate: "Subject to annual funding by Congress",
      link: "https://www.rd.usda.gov/programs-services/energy-programs/rural-energy-america-program-renewable-energy-systems-energy-efficiency-improvement-guaranteed-loans",
      icon: <Leaf className="h-14 w-14 text-primary-600" />
    }
  ];

  const faqs = [
    {
      question: "How do I claim the Federal Solar Investment Tax Credit?",
      answer: "To claim the federal solar ITC, you'll need to complete IRS Form 5695 as part of your federal tax return. This form calculates the credit amount based on your qualified solar expenses. The resulting credit amount is then entered on your 1040 form. If you cannot use the full amount of the credit in one year, you can carry the remainder forward to future tax years. Consult with a tax professional for guidance specific to your situation."
    },
    {
      question: "Can I combine federal and state incentives?",
      answer: "Yes, in most cases you can combine federal incentives with state, local, and utility incentives. For example, you can claim the federal ITC and also take advantage of state tax credits, rebates, and performance-based incentives. However, some state incentives may affect the cost basis used to calculate your federal tax credit. Consult with a tax professional to ensure you're maximizing your benefits while remaining compliant with all requirements."
    },
    {
      question: "Do I qualify for solar incentives if I lease my system?",
      answer: "If you lease a solar system or enter into a power purchase agreement (PPA), you do not directly qualify for the federal ITC or most ownership-based incentives. Instead, the company that owns the system receives these benefits and typically passes some savings to you through reduced lease payments or PPA rates. However, you may still qualify for certain production-based incentives or utility rebates, depending on your location and program rules."
    },
    {
      question: "What happens to my solar incentives if I sell my home?",
      answer: "If you sell your home with a solar system that you owned and received incentives for, you generally don't have to repay federal tax credits. However, if you sell within the first five years, there may be recapture of accelerated depreciation benefits for systems used for business purposes. For state and local incentives, rules vary by program. Performance-based incentives often transfer to the new homeowner, but policies differ by location and program."
    },
    {
      question: "Are battery storage systems eligible for the same incentives?",
      answer: "Energy storage systems like batteries are eligible for the federal ITC when installed with a new solar energy system. As of 2023, standalone battery installations are also eligible for the ITC. For other incentives, eligibility varies by program. Many states and utilities now offer specific incentives for energy storage. Check your local programs for detailed information on battery storage incentives in your area."
    }
  ];

  return (
    <>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-600 to-primary-700 text-white py-16">
        <div className="container-custom">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            National Solar Incentives and Programs
          </h1>
          <p className="text-lg md:text-xl mb-8 text-primary-50 max-w-3xl">
            Discover federal tax credits, grants, and other nationwide incentives that can help you save thousands on your solar installation.
          </p>
          <button 
            onClick={openLeadPopup}
            className="btn btn-secondary"
          >
            Find Out How Much You Can Save
          </button>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <div className="grid md:grid-cols-3 gap-12">
            <div className="md:col-span-2">
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 mb-12">
                <h2 className="text-3xl font-bold mb-6">Federal Solar Incentives</h2>
                <p className="text-gray-600 mb-8">
                  The federal government offers several incentives to promote solar energy adoption across the United States. 
                  These programs can significantly reduce the upfront cost of going solar and improve your return on investment.
                </p>
                
                <div className="grid md:grid-cols-2 gap-6 mb-8">
                  {nationalPrograms.slice(0, 2).map((program, index) => (
                    <div key={index} className="bg-gray-50 rounded-lg p-6 border border-gray-100">
                      <div className="flex items-center mb-4">
                        {program.icon}
                        <h3 className="text-xl font-bold ml-4">{program.title}</h3>
                      </div>
                      <p className="text-gray-600 mb-4">{program.description}</p>
                      <div className="mt-auto pt-4">
                        <a
                          href={program.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary-600 hover:text-primary-700 inline-flex items-center"
                        >
                          Learn more <Link className="ml-1 h-4 w-4" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="space-y-4 mb-8">
                  {nationalPrograms.map((program, index) => (
                    <AccordionItem
                      key={index}
                      title={program.title}
                      isOpen={openAccordion === index}
                      onClick={() => handleAccordionClick(index)}
                    >
                      <div className="space-y-4">
                        <p className="text-gray-600">{program.description}</p>
                        
                        <div className="bg-gray-50 rounded-lg p-4">
                          <h5 className="font-semibold mb-2">Key Details</h5>
                          <ul className="list-disc list-inside space-y-1 text-gray-600">
                            {program.details.map((detail, i) => (
                              <li key={i}>{detail}</li>
                            ))}
                          </ul>
                        </div>
                        
                        <div>
                          <h5 className="font-semibold mb-2">Eligibility</h5>
                          <p className="text-gray-600">{program.eligibility}</p>
                        </div>
                        
                        <div className="flex items-center">
                          <Calendar className="h-5 w-5 text-primary-600 mr-2" />
                          <span className="text-gray-600">
                            Expires: {program.expiryDate}
                          </span>
                        </div>
                        
                        <a
                          href={program.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary-600 hover:text-primary-700 inline-flex items-center"
                        >
                          Official program details <Link className="ml-1 h-4 w-4" />
                        </a>
                      </div>
                    </AccordionItem>
                  ))}
                </div>
              </div>
              
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
                <h2 className="text-3xl font-bold mb-6">Frequently Asked Questions</h2>
                
                <div className="space-y-4">
                  {faqs.map((faq, index) => (
                    <AccordionItem
                      key={index}
                      title={faq.question}
                      isOpen={openAccordion === index + 100}
                      onClick={() => handleAccordionClick(index + 100)}
                    >
                      <p className="text-gray-600">{faq.answer}</p>
                    </AccordionItem>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="md:col-span-1">
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-8 sticky top-24">
                <h3 className="text-xl font-bold mb-4">Ready to Go Solar?</h3>
                <p className="text-gray-600 mb-6">
                  Find out how much you can save with solar by combining federal, state, and local incentives. Get a free quote from pre-screened solar installers in your area.
                </p>
                <button 
                  onClick={openLeadPopup}
                  className="btn btn-primary w-full"
                >
                  Get Your Free Quote
                </button>
              </div>
              
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-8">
                <h3 className="text-xl font-bold mb-4">Need Help Understanding Incentives?</h3>
                <p className="text-gray-600 mb-4">
                  Solar incentives can be complicated. Our solar experts can help you understand which incentives you qualify for and how to claim them.
                </p>
                <div className="bg-primary-50 border border-primary-100 rounded-lg p-4">
                  <div className="flex items-start">
                    <HelpCircle className="h-5 w-5 text-primary-600 mr-2 mt-0.5" />
                    <p className="text-sm text-primary-800">
                      Our partner installers handle the paperwork for most incentives, making the process simple for you.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 className="text-xl font-bold mb-4">Additional Resources</h3>
                <ul className="space-y-3">
                  <li>
                    <a
                      href="https://www.energy.gov/eere/solar/homeowners-guide-going-solar"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary-600 hover:text-primary-700 inline-flex items-center"
                    >
                      Department of Energy Solar Guide <Link className="ml-1 h-4 w-4" />
                    </a>
                    <p className="text-sm text-gray-600">Comprehensive guide for homeowners considering solar</p>
                  </li>
                  <li>
                    <a
                      href="https://www.dsireusa.org/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary-600 hover:text-primary-700 inline-flex items-center"
                    >
                      DSIRE Incentive Database <Link className="ml-1 h-4 w-4" />
                    </a>
                    <p className="text-sm text-gray-600">Database of state incentives for renewables & efficiency</p>
                  </li>
                  <li>
                    <a
                      href="https://www.irs.gov/forms-pubs/about-form-5695"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary-600 hover:text-primary-700 inline-flex items-center"
                    >
                      IRS Form 5695 Information <Link className="ml-1 h-4 w-4" />
                    </a>
                    <p className="text-sm text-gray-600">Tax form used to claim residential energy credits</p>
                  </li>
                  <li>
                    <a
                      href="https://www.energystar.gov/about/federal_tax_credits"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary-600 hover:text-primary-700 inline-flex items-center"
                    >
                      ENERGY STAR Tax Credits <Link className="ml-1 h-4 w-4" />
                    </a>
                    <p className="text-sm text-gray-600">Information on federal tax credits for energy efficiency</p>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-primary-600 text-white">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-4">
                Combine Federal and State Incentives
              </h2>
              <p className="text-lg text-primary-50 mb-6">
                Stack federal tax credits with your state and local incentives to maximize your savings. Our solar experts can help you navigate all available programs.
              </p>
              <button 
                onClick={openLeadPopup}
                className="btn btn-secondary"
              >
                Get Your Personalized Savings Estimate
              </button>
            </div>
            <div className="hidden md:block">
              <img
                src="https://images.unsplash.com/photo-1577451581377-523b0a03bb6b?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxzb2xhciUyMHBhbmVscyUyMG9uJTIwaG91c2UlMjByb29mJTIwZ3JlZW4lMjBlbmVyZ3l8ZW58MHx8fHwxNzQ3NjMxNjYyfDA&ixlib=rb-4.1.0&fit=fillmax&h=800&w=1200"
                alt="Solar panels on house roof"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default NationalPrograms;
 