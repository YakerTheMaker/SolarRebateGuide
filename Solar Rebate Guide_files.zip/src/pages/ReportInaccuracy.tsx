import  { useState } from 'react';
import { AlertTriangle, Check } from 'lucide-react';

const ReportInaccuracy = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    pageUrl: '',
    description: '',
    correction: '',
    source: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    
    // Clear error when field is updated
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: '',
      });
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    if (!formData.pageUrl.trim()) {
      newErrors.pageUrl = 'Page URL is required';
    }
    
    if (!formData.description.trim()) {
      newErrors.description = 'Description of the inaccuracy is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      // In a real app, this would send the data to a server
      console.log('Report submitted:', formData);
      setSubmitted(true);
    }
  };

  return (
    <div className="container-custom py-16">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 mb-8">
          <div className="flex items-center mb-8">
            <AlertTriangle className="h-8 w-8 text-primary-600 mr-3" />
            <h1 className="text-3xl font-bold">Report an Inaccuracy</h1>
          </div>
          
          {!submitted ? (
            <>
              <p className="text-lg text-gray-600 mb-8">
                We strive to provide accurate information about solar incentives and rebates. If you've found an error or outdated information on our site, please let us know using the form below.
              </p>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                      Your Name<span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className={`w-full px-4 py-2 border rounded-lg focus:ring-primary-500 focus:border-primary-500 ${
                        errors.name ? 'border-red-500' : 'border-gray-300'
                      }`}
                    />
                    {errors.name && (
                      <p className="mt-1 text-sm text-red-500">{errors.name}</p>
                    )}
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Your Email<span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className={`w-full px-4 py-2 border rounded-lg focus:ring-primary-500 focus:border-primary-500 ${
                        errors.email ? 'border-red-500' : 'border-gray-300'
                      }`}
                    />
                    {errors.email && (
                      <p className="mt-1 text-sm text-red-500">{errors.email}</p>
                    )}
                  </div>
                </div>
                
                <div>
                  <label htmlFor="pageUrl" className="block text-sm font-medium text-gray-700 mb-1">
                    Page URL with Inaccuracy<span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="pageUrl"
                    name="pageUrl"
                    value={formData.pageUrl}
                    onChange={handleChange}
                    placeholder="https://solarrebateguide.com/state/..."
                    className={`w-full px-4 py-2 border rounded-lg focus:ring-primary-500 focus:border-primary-500 ${
                      errors.pageUrl ? 'border-red-500' : 'border-gray-300'
                    }`}
                  />
                  {errors.pageUrl && (
                    <p className="mt-1 text-sm text-red-500">{errors.pageUrl}</p>
                  )}
                </div>
                
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                    Description of the Inaccuracy<span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    rows={4}
                    className={`w-full px-4 py-2 border rounded-lg focus:ring-primary-500 focus:border-primary-500 ${
                      errors.description ? 'border-red-500' : 'border-gray-300'
                    }`}
                    placeholder="Please describe what information is incorrect or outdated."
                  ></textarea>
                  {errors.description && (
                    <p className="mt-1 text-sm text-red-500">{errors.description}</p>
                  )}
                </div>
                
                <div>
                  <label htmlFor="correction" className="block text-sm font-medium text-gray-700 mb-1">
                    Suggested Correction
                  </label>
                  <textarea
                    id="correction"
                    name="correction"
                    value={formData.correction}
                    onChange={handleChange}
                    rows={3}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                    placeholder="If you know the correct information, please provide it here."
                  ></textarea>
                </div>
                
                <div>
                  <label htmlFor="source" className="block text-sm font-medium text-gray-700 mb-1">
                    Source (Optional)
                  </label>
                  <input
                    type="text"
                    id="source"
                    name="source"
                    value={formData.source}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                    placeholder="URL, document, or other source for the correct information."
                  />
                </div>
                
                <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-100">
                  <p className="text-sm text-yellow-800">
                    <strong>Disclaimer:</strong> Solar incentives and rebates frequently change. We appreciate your help in keeping our information accurate and up-to-date.
                  </p>
                </div>
                
                <div>
                  <button type="submit" className="btn btn-primary">
                    Submit Report
                  </button>
                </div>
              </form>
            </>
          ) : (
            <div className="text-center py-8">
              <div className="bg-green-100 text-green-700 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Check className="h-8 w-8" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Thank You for Your Report</h2>
              <p className="text-lg text-gray-600 mb-6">
                We appreciate you taking the time to help us improve our site. Our team will review the information you've provided and make any necessary corrections.
              </p>
              <div className="inline-flex justify-center">
                <a href="/" className="btn btn-primary">
                  Return to Home
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReportInaccuracy;
 