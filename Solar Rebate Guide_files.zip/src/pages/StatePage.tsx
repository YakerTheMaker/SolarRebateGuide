import  { useParams, useOutletContext, Link } from 'react-router-dom';
import { useState } from 'react';
import { ChevronDown, ChevronUp, ExternalLink, Sun, AlertTriangle, Info, CheckCircle, ArrowRight } from 'lucide-react';
import SolarCalculator from '../components/SolarCalculator';
import CitiesSection from '../components/CitiesSection';
import NotFound from './NotFound';

interface AccordionItemProps {
  title: string;
  children: React.ReactNode;
  isOpen: boolean;
  onClick: () => void;
}

const AccordionItem = ({ title, children, isOpen, onClick }: AccordionItemProps) => {
  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden mb-4">
      <button
        onClick={onClick}
        className="w-full flex justify-between items-center p-4 text-left bg-white hover:bg-gray-50 transition-colors"
      >
        <span className="font-semibold text-gray-900">{title}</span>
        {isOpen ? <ChevronUp className="h-5 w-5 text-gray-500" /> : <ChevronDown className="h-5 w-5 text-gray-500" />}
      </button>
      {isOpen && (
        <div className="p-4 pt-0 bg-white border-t border-gray-100">
          {children}
        </div>
      )}
    </div>
  );
};

interface ContextType {
  openLeadPopup: () => void;
}

const StatePage = () => {
  const { stateId } = useParams();
  const { openLeadPopup } = useOutletContext<ContextType>();
  const [openAccordion, setOpenAccordion] = useState<string | null>('incentives');
  
  if (!stateId) return <NotFound />;
  
  // Mock getStateData function - this would be imported from your data file
  const getStateData = (id) => {
    if (id === 'california') {
      return {
        id: 'california',
        name: 'California',
        overview: 'California offers some of the best solar incentives in the nation. The state has been a leader in renewable energy adoption, with ambitious goals for clean energy and carbon reduction.',
        solarPotential: 'Excellent - 5-7 peak sun hours per day',
        averageSavings: '$30,000 - $50,000 over 25 years',
        keyIncentives: [
          { name: 'Net Energy Metering', type: 'credit' },
          { name: 'SGIP Rebate', type: 'rebate' },
          { name: 'Property Tax Exclusion', type: 'tax' }
        ],
        incentives: [
          {
            name: 'Net Energy Metering (NEM 2.0)',
            description: 'California\'s net metering program allows solar customers to receive credit for excess electricity exported to the grid.',
            details: [
              'Credit at retail rate for excess energy',
              'Credits can be used to offset future electricity bills',
              'Annual true-up period',
              'Small interconnection fee'
            ],
            eligibility: 'All utility customers of PG&E, SCE, and SDG&E',
            link: 'https://www.cpuc.ca.gov/nemrevisit/'
          },
          {
            name: 'Self-Generation Incentive Program (SGIP)',
            description: 'SGIP provides rebates for installing energy storage systems alongside solar installations.',
            details: [
              'Rebates based on battery capacity',
              'Higher incentives available for low-income households',
              'Step-based incentive structure',
              'Additional equity resiliency incentives available'
            ],
            eligibility: 'Customers of PG&E, SCE, SoCalGas, and SDG&E',
            link: 'https://www.selfgenca.com/'
          },
          {
            name: 'Property Tax Exclusion for Solar Energy Systems',
            description: 'Solar energy systems are excluded from property tax assessments until 2025.',
            details: [
              'Solar installations won\'t increase property taxes',
              'Applies to systems installed before January 1, 2025',
              'Covers solar PV and solar thermal systems'
            ],
            eligibility: 'All property owners in California',
            expiryDate: 'January 1, 2025',
            link: 'https://www.boe.ca.gov/proptaxes/newconstruction.htm'
          }
        ],
        faqs: [
          {
            question: 'How much can I save with solar in California?',
            answer: 'The average California homeowner can save between $30,000 and $50,000 over the 25-year life of their solar system, depending on system size, electricity usage, and utility rates. Most systems pay for themselves within 5-7 years.'
          },
          {
            question: 'Is California ending net metering?',
            answer: 'California has updated its net metering policy with NEM 3.0, which reduces the value of exported electricity compared to previous versions. However, customers who install solar before the implementation date can be grandfathered into NEM 2.0 for 20 years.'
          },
          {
            question: 'Do solar panels increase home value in California?',
            answer: 'Yes, studies show that solar installations increase California home values by approximately 3-4% on average. A Lawrence Berkeley National Laboratory study found that each kilowatt of solar capacity adds about $5,900 to the home\'s resale value in California.'
          }
        ],
        utilityCompanies: [
          {
            name: 'Pacific Gas & Electric (PG&E)',
            program: 'Net Energy Metering with time-of-use rates'
          },
          {
            name: 'Southern California Edison (SCE)',
            program: 'Net Energy Metering with time-of-use rates'
          },
          {
            name: 'San Diego Gas & Electric (SDG&E)',
            program: 'Net Energy Metering with time-of-use rates'
          },
          {
            name: 'Los Angeles Department of Water & Power (LADWP)',
            program: 'Net Energy Metering and Solar Incentive Program'
          }
        ],
        resources: [
          {
            name: 'California Solar & Storage Association',
            description: 'Industry association providing resources and advocacy for solar and storage in California',
            url: 'https://calssa.org/'
          },
          {
            name: 'Go Solar California',
            description: 'Official state website with information about solar programs and incentives',
            url: 'https://www.gosolarcalifornia.ca.gov/'
          },
          {
            name: 'California Public Utilities Commission (CPUC)',
            description: 'Regulatory information about solar policies and grid interconnection',
            url: 'https://www.cpuc.ca.gov/industries-and-topics/electrical-energy/demand-side-management/customer-generation/solar-photovoltaic-pv'
          }
        ]
      };
    } else if (id === 'texas') {
      return {
        id: 'texas',
        name: 'Texas',
        overview: 'Texas is a leading state for solar energy production with abundant sunshine and a growing number of incentives. While the state does not have a statewide solar rebate program, many utilities offer local incentives.',
        solarPotential: 'Excellent - 5-6 peak sun hours per day',
        averageSavings: '$25,000 - $40,000 over 25 years',
        keyIncentives: [
          { name: 'Local Utility Rebates', type: 'rebate' },
          { name: 'Property Tax Exemption', type: 'tax' },
          { name: 'Net Metering (select utilities)', type: 'credit' }
        ],
        incentives: [
          {
            name: 'Property Tax Exemption',
            description: 'Texas offers a 100% property tax exemption for the added home value from a solar PV system.',
            details: [
              'Exemption for 100% of the added value from solar',
              'No application needed in many counties',
              'Permanent exemption with no expiration date'
            ],
            eligibility: 'All Texas property owners',
            link: 'https://comptroller.texas.gov/taxes/property-tax/exemptions/'
          }
        ],
        faqs: [
          {
            question: 'Does Texas have a state tax credit for solar?',
            answer: 'No, Texas does not offer a state tax credit for solar installations. However, residents can still claim the 30% federal tax credit, and many local utilities offer rebate programs.'
          }
        ],
        utilityCompanies: [
          {
            name: 'Austin Energy',
            program: 'Residential Solar Rebate Program and Value of Solar Tariff'
          },
          {
            name: 'CPS Energy (San Antonio)',
            program: 'Solar PV Rebate Program'
          }
        ],
        resources: [
          {
            name: 'Solar Energy Industries Association - Texas',
            description: 'Information about the Texas solar market and policies',
            url: 'https://www.seia.org/state-solar-policy/texas-solar'
          }
        ]
      };
    } else {
      return null;
    }
  };
  
  const stateData = getStateData(stateId);
  if (!stateData) return <NotFound />;
  
  const toggleAccordion = (accordionId) => {
    setOpenAccordion(openAccordion === accordionId ? null : accordionId);
  };

  return (
    <div>
      {/* Hero section */}
      <div className="bg-gradient-to-r from-primary-600 to-primary-700 text-white pt-16 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-opacity-30 mix-blend-multiply">
          <div className="absolute inset-0 bg-grid-white/[0.1] bg-[length:16px_16px]"></div>
        </div>
        <div className="container-custom relative z-10">
          <div className="max-w-3xl">
            <div className="flex items-center mb-4">
              <Sun className="h-6 w-6 mr-2" />
              <div className="text-sm md:text-base">
                <Link to="/" className="text-white/70 hover:text-white">Home</Link>
                <span className="mx-2">/</span>
                <span className="text-white/90">{stateData.name}</span>
              </div>
            </div>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">{stateData.name} Solar Incentives & Rebates</h1>
            <p className="text-lg md:text-xl opacity-90 mb-8">{stateData.overview}</p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button onClick={openLeadPopup} className="btn btn-secondary">
                Schedule a Consultation
              </button>
              <Link to="#calculator" className="btn bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm">
                Calculate Your Savings
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="container-custom py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main column */}
          <div className="lg:col-span-2">
            {/* State overview */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Solar Potential in {stateData.name}</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg border border-gray-100">
                  <h3 className="text-sm font-medium text-gray-500 mb-1">Solar Potential</h3>
                  <p className="text-lg font-semibold text-gray-900">{stateData.solarPotential}</p>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg border border-gray-100">
                  <h3 className="text-sm font-medium text-gray-500 mb-1">Average Savings</h3>
                  <p className="text-lg font-semibold text-gray-900">{stateData.averageSavings}</p>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg border border-gray-100">
                  <h3 className="text-sm font-medium text-gray-500 mb-1">Key Utilities</h3>
                  <p className="text-lg font-semibold text-gray-900">{stateData.utilityCompanies.length} Major Providers</p>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-3 mb-6">
                {stateData.keyIncentives.map((incentive, index) => (
                  <span 
                    key={index}
                    className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                      incentive.type === 'rebate' 
                        ? 'bg-green-100 text-green-800' 
                        : incentive.type === 'tax'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {incentive.name}
                  </span>
                ))}
              </div>
              
              <div className="prose max-w-none">
                <p>{stateData.overview}</p>
              </div>
            </div>
            
            {/* Cities section */}
            <CitiesSection stateId={stateId} stateName={stateData.name} />
            
            {/* Accordion content */}
            <div className="mb-8">
              <AccordionItem
                title={`${stateData.name} Solar Incentives`}
                isOpen={openAccordion === 'incentives'}
                onClick={() => toggleAccordion('incentives')}
              >
                <div className="prose max-w-none">
                  <p className="text-gray-600">
                    {stateData.name} offers several solar incentives, rebates, and tax benefits to help residents go solar:
                  </p>
                  
                  <div className="space-y-6 mt-4">
                    {stateData.incentives.map((incentive, index) => (
                      <div key={index} className="bg-gray-50 p-4 rounded-lg border border-gray-100">
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">{incentive.name}</h3>
                        <p className="text-gray-600 mb-3">{incentive.description}</p>
                        
                        {incentive.details && incentive.details.length > 0 && (
                          <div className="mb-3">
                            <h4 className="text-sm font-medium text-gray-700 mb-2">Program Details:</h4>
                            <ul className="list-disc pl-5 space-y-1 text-gray-600 text-sm">
                              {incentive.details.map((detail, detailIndex) => (
                                <li key={detailIndex}>{detail}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                        
                        {incentive.eligibility && (
                          <div className="text-sm text-gray-500 mb-2">
                            <span className="font-medium text-gray-700">Eligibility:</span> {incentive.eligibility}
                          </div>
                        )}
                        
                        {incentive.expiryDate && (
                          <div className="text-sm text-gray-500 mb-2">
                            <span className="font-medium text-gray-700">Expires:</span> {incentive.expiryDate}
                          </div>
                        )}
                        
                        {incentive.link && (
                          <a 
                            href={incentive.link} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-primary-600 hover:text-primary-700 inline-flex items-center text-sm"
                          >
                            Official program website <ExternalLink className="ml-1 h-3 w-3" />
                          </a>
                        )}
                      </div>
                    ))}
                  </div>
                  
                  <div className="bg-primary-50 p-4 rounded-lg mt-6 border border-primary-100">
                    <h4 className="text-primary-800 font-medium mb-2">Also Available: Federal Solar Tax Credit</h4>
                    <p className="text-primary-700 text-sm">
                      In addition to {stateData.name} incentives, don't forget about the 30% federal tax credit for solar installations.
                    </p>
                    <div className="mt-3">
                      <Link 
                        to="/national-programs"
                        className="text-primary-600 hover:text-primary-700 inline-flex items-center text-sm font-medium"
                      >
                        View all federal incentives <ArrowRight className="ml-1 h-3 w-3" />
                      </Link>
                    </div>
                  </div>
                </div>
              </AccordionItem>
              
              <AccordionItem
                title={`${stateData.name} Solar FAQs`}
                isOpen={openAccordion === 'faqs'}
                onClick={() => toggleAccordion('faqs')}
              >
                <div className="space-y-6">
                  {stateData.faqs.map((faq, index) => (
                    <div key={index}>
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">{faq.question}</h3>
                      <p className="text-gray-600">{faq.answer}</p>
                    </div>
                  ))}
                  
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                    <div className="flex">
                      <Info className="h-5 w-5 text-blue-500 mr-3 flex-shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-blue-800 font-medium mb-1">Have a question not answered here?</h4>
                        <p className="text-blue-700 text-sm">
                          Contact us for personalized information about going solar in {stateData.name}.
                        </p>
                        <div className="mt-3">
                          <button 
                            onClick={openLeadPopup}
                            className="text-blue-600 hover:text-blue-700 inline-flex items-center text-sm font-medium"
                          >
                            Get expert advice <ArrowRight className="ml-1 h-3 w-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </AccordionItem>
              
              <AccordionItem
                title={`${stateData.name} Utility Companies`}
                isOpen={openAccordion === 'utilities'}
                onClick={() => toggleAccordion('utilities')}
              >
                <div>
                  <p className="text-gray-600 mb-4">
                    The following utility companies in {stateData.name} offer net metering or other solar programs:
                  </p>
                  
                  <div className="space-y-4">
                    {stateData.utilityCompanies.map((utility, index) => (
                      <div key={index} className="flex border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                        <div className="bg-primary-100 rounded-full p-2 mr-3 text-primary-600">
                          <CheckCircle className="h-5 w-5" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{utility.name}</h3>
                          <p className="text-gray-600 text-sm">{utility.program}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </AccordionItem>
              
              <AccordionItem
                title="Additional Resources"
                isOpen={openAccordion === 'resources'}
                onClick={() => toggleAccordion('resources')}
              >
                <div>
                  <p className="text-gray-600 mb-4">
                    Learn more about solar in {stateData.name} from these trusted resources:
                  </p>
                  
                  <div className="space-y-4">
                    {stateData.resources.map((resource, index) => (
                      <div key={index} className="border border-gray-100 rounded-lg p-4">
                        <h3 className="font-semibold text-gray-900 mb-1">{resource.name}</h3>
                        <p className="text-gray-600 text-sm mb-2">{resource.description}</p>
                        <a 
                          href={resource.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-primary-600 hover:text-primary-700 inline-flex items-center text-sm"
                        >
                          Visit website <ExternalLink className="ml-1 h-3 w-3" />
                        </a>
                      </div>
                    ))}
                  </div>
                </div>
              </AccordionItem>
            </div>
            
            {/* Calculator section */}
            <div id="calculator" className="scroll-mt-20">
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Calculate Your Solar Savings in {stateData.name}</h2>
                <SolarCalculator state={stateData.name} openLeadPopup={openLeadPopup} />
              </div>
            </div>
            
            {/* Disclaimer */}
            <div className="bg-gray-50 rounded-lg p-4 text-sm text-gray-500 mb-8">
              <div className="flex">
                <AlertTriangle className="h-5 w-5 text-amber-500 mr-3 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium mb-1">Disclaimer:</p>
                  <p>The information provided on this page about solar incentives in {stateData.name} is for general informational purposes only. Incentive programs, rebates, and policies may change over time. We recommend verifying all information with official sources before making decisions. Please <Link to="/report-inaccuracy" className="text-primary-600 hover:underline">report any inaccuracies</Link> you find on our site.</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sticky top-24">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Ready to Go Solar in {stateData.name}?</h2>
              
              <div className="space-y-4 mb-6">
                <div className="flex items-start">
                  <div className="bg-primary-100 rounded-full p-1.5 mr-3 text-primary-600">
                    <CheckCircle className="h-4 w-4" />
                  </div>
                  <p className="text-gray-600 text-sm">Get multiple quotes from pre-screened installers</p>
                </div>
                <div className="flex items-start">
                  <div className="bg-primary-100 rounded-full p-1.5 mr-3 text-primary-600">
                    <CheckCircle className="h-4 w-4" />
                  </div>
                  <p className="text-gray-600 text-sm">Learn about all available incentives</p>
                </div>
                <div className="flex items-start">
                  <div className="bg-primary-100 rounded-full p-1.5 mr-3 text-primary-600">
                    <CheckCircle className="h-4 w-4" />
                  </div>
                  <p className="text-gray-600 text-sm">Estimate your potential solar savings</p>
                </div>
                <div className="flex items-start">
                  <div className="bg-primary-100 rounded-full p-1.5 mr-3 text-primary-600">
                    <CheckCircle className="h-4 w-4" />
                  </div>
                  <p className="text-gray-600 text-sm">Maximize your return on investment</p>
                </div>
              </div>
              
              <button 
                onClick={openLeadPopup}
                className="btn btn-primary w-full mb-4"
              >
                Schedule a Free Consultation
              </button>
              
              <p className="text-xs text-gray-500 text-center">No obligation quotes from top providers</p>
              
              <div className="mt-8 pt-6 border-t border-gray-100">
                <h3 className="font-semibold text-gray-900 mb-3">Related Resources</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <Link to="/national-programs" className="text-primary-600 hover:text-primary-700">
                      Federal Solar Incentives
                    </Link>
                  </li>
                  <li>
                    <Link to="/buying-guides" className="text-primary-600 hover:text-primary-700">
                      Solar Buying Guides
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatePage;
 