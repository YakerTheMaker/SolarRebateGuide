import  { useOutletContext } from 'react-router-dom';
import { Sun, CheckCircle, ArrowRight } from 'lucide-react';
import SolarLeadForm from '../components/SolarLeadForm';

interface ContextType {
  openLeadPopup: () => void;
}

const SolarConsultation = () => {
  const { openLeadPopup } = useOutletContext<ContextType>();

  return (
    <div>
      {/* Hero section */}
      <div className="bg-gradient-to-r from-primary-600 to-primary-700 text-white pt-16 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-opacity-30 mix-blend-multiply">
          <div className="absolute inset-0 bg-grid-white/[0.1] bg-[length:16px_16px]"></div>
        </div>
        <div className="container-custom relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">Schedule Your Solar Consultation</h1>
            <p className="text-lg md:text-xl opacity-90 mb-8">
              Speak with local solar experts who can help you navigate incentives, design a system, and maximize your savings
            </p>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="container-custom py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main column */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-8">Get a Free Solar Consultation</h2>
              
              <SolarLeadForm />
            </div>
          </div>
          
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sticky top-24">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Why Schedule a Consultation?</h2>
              
              <div className="space-y-4 mb-6">
                <div className="flex items-start">
                  <div className="bg-primary-100 rounded-full p-1.5 mr-3 text-primary-600">
                    <CheckCircle className="h-4 w-4" />
                  </div>
                  <p className="text-gray-600 text-sm">Get personalized advice from solar experts</p>
                </div>
                <div className="flex items-start">
                  <div className="bg-primary-100 rounded-full p-1.5 mr-3 text-primary-600">
                    <CheckCircle className="h-4 w-4" />
                  </div>
                  <p className="text-gray-600 text-sm">Learn about all available incentives in your area</p>
                </div>
                <div className="flex items-start">
                  <div className="bg-primary-100 rounded-full p-1.5 mr-3 text-primary-600">
                    <CheckCircle className="h-4 w-4" />
                  </div>
                  <p className="text-gray-600 text-sm">Understand your solar potential and savings</p>
                </div>
                <div className="flex items-start">
                  <div className="bg-primary-100 rounded-full p-1.5 mr-3 text-primary-600">
                    <CheckCircle className="h-4 w-4" />
                  </div>
                  <p className="text-gray-600 text-sm">No obligation, free service</p>
                </div>
              </div>
              
              <div className="bg-primary-50 p-4 rounded-lg text-center">
                <div className="bg-primary-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Sun className="h-6 w-6 text-primary-600" />
                </div>
                <h3 className="font-semibold text-primary-800 mb-2">Prefer to talk now?</h3>
                <p className="text-primary-700 text-sm mb-4">
                  If you'd rather get immediate assistance, we can connect you with a solar expert right away.
                </p>
                <button 
                  onClick={openLeadPopup}
                  className="btn btn-primary text-sm w-full"
                >
                  Speak to an Expert Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SolarConsultation;
 