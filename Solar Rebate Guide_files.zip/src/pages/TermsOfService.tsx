import  { Sun } from 'lucide-react';

const TermsOfService = () => {
  return (
    <div className="container-custom py-16">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 mb-8">
        <div className="flex items-center mb-8">
          <Sun className="h-8 w-8 text-primary-600 mr-3" />
          <h1 className="text-3xl font-bold">Terms of Service</h1>
        </div>
        
        <div className="prose max-w-none">
          <p className="text-lg text-gray-600 mb-8">
            Last Updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">1. Agreement to Terms</h2>
          <p>
            These Terms of Service constitute a legally binding agreement made between you, whether personally or on behalf of an entity ("you") and Solar Rebate Guide ("we," "us" or "our"), concerning your access to and use of the solarrebateguide.com website as well as any other media form, media channel, mobile website or mobile application related, linked, or otherwise connected thereto (collectively, the "Site").
          </p>
          <p>
            You agree that by accessing the Site, you have read, understood, and agree to be bound by all of these Terms of Service. If you do not agree with all of these terms, you are prohibited from using the Site and must discontinue use immediately.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">2. Disclaimer of Information Accuracy</h2>
          <p>
            While we strive to provide accurate and up-to-date information about solar incentives, rebates, and programs, we cannot guarantee the accuracy, completeness, or reliability of any information presented on our Site. Solar incentives, tax credits, and rebate programs are subject to change without notice at the federal, state, and local levels.
          </p>
          <p className="font-semibold">
            You should always verify information with official sources before making decisions. Solar Rebate Guide is not responsible for any actions taken based on the information provided on this Site.
          </p>
          <p>
            We recommend consulting with:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>The Database of State Incentives for Renewables & Efficiency (DSIRE)</li>
            <li>Your state energy office</li>
            <li>Local utility companies</li>
            <li>A qualified tax professional for tax credit information</li>
            <li>Licensed solar installers familiar with local incentive programs</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">3. Reporting Inaccurate Information</h2>
          <p>
            We are committed to providing the most accurate information possible. If you believe that any information on our Site is inaccurate, outdated, or incomplete, please help us improve by reporting it through one of the following methods:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Email us at info@solarrebateguide.com</li>
            <li>Use the "Report Inaccuracy" button available on state and national program pages</li>
            <li>Contact us through our contact form</li>
          </ul>
          <p>
            Please include specific details about the information you believe is incorrect, and if possible, provide a source for the correct information. We appreciate your help in maintaining the accuracy of our Site.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">4. Intellectual Property Rights</h2>
          <p>
            Unless otherwise indicated, the Site is our proprietary property and all source code, databases, functionality, software, website designs, audio, video, text, photographs, and graphics on the Site (collectively, the "Content") and the trademarks, service marks, and logos contained therein (the "Marks") are owned or controlled by us or licensed to us, and are protected by copyright and trademark laws and various other intellectual property rights.
          </p>
          <p>
            The Content and Marks are provided on the Site "AS IS" for your information and personal use only. Except as expressly provided in these Terms of Service, no part of the Site and no Content or Marks may be copied, reproduced, aggregated, republished, uploaded, posted, publicly displayed, encoded, translated, transmitted, distributed, sold, licensed, or otherwise exploited for any commercial purpose whatsoever, without our express prior written permission.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">5. User Representations</h2>
          <p>
            By using the Site, you represent and warrant that:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>All registration information you submit will be true, accurate, current, and complete</li>
            <li>You will maintain the accuracy of such information and promptly update as necessary</li>
            <li>You have the legal capacity and agree to comply with these Terms of Service</li>
            <li>You are not a minor in the jurisdiction in which you reside</li>
            <li>You will not access the Site through automated or non-human means</li>
            <li>You will not use the Site for any illegal or unauthorized purpose</li>
            <li>Your use of the Site will not violate any applicable law or regulation</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">6. User Registration</h2>
          <p>
            You may be required to register to use certain features of the Site. You agree to keep your password confidential and will be responsible for all use of your account and password.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">7. Lead Generation and Third-Party Connections</h2>
          <p>
            Our Site offers lead generation forms that connect users with solar installers and service providers. By submitting your information through these forms, you explicitly agree to be contacted by these third parties. <strong>Any information you provide will be shared with solar providers for the purpose of obtaining a quote or scheduling a consultation.</strong> We do not control and are not responsible for the actions of these third-party service providers, including how they use, store, or process your information after it is shared with them.
          </p>
          <p className="mt-2">
            By using our consultation scheduling or quote request features, you are expressly consenting to:
          </p>
          <ul className="list-disc pl-6 mb-4 mt-2">
            <li>Have your contact information and project details shared with up to three (3) solar providers and/or installers</li>
            <li>Receive communications via phone, email, or text message from these solar providers</li>
            <li>Allow these providers to contact you about solar installation services and related products</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">8. Prohibited Activities</h2>
          <p>
            You may not access or use the Site for any purpose other than that for which we make the Site available. The Site may not be used in connection with any commercial endeavors except those that are specifically endorsed or approved by us.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">9. Submissions</h2>
          <p>
            You acknowledge and agree that any questions, comments, suggestions, ideas, feedback, or other information regarding the Site ("Submissions") provided by you to us are non-confidential and shall become our sole property. We shall own exclusive rights, including all intellectual property rights, and shall be entitled to the unrestricted use and dissemination of these Submissions for any lawful purpose, commercial or otherwise, without acknowledgment or compensation to you.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">10. Site Management</h2>
          <p>
            We reserve the right, but not the obligation, to:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Monitor the Site for violations of these Terms of Service</li>
            <li>Take appropriate legal action against anyone who violates these Terms of Service</li>
            <li>Refuse, restrict access to, limit the availability of, or disable any of your Contributions or any portion thereof</li>
            <li>Remove from the Site or otherwise disable all files and content that are excessive in size or are in any way burdensome to our systems</li>
            <li>Otherwise manage the Site in a manner designed to protect our rights and property and to facilitate the proper functioning of the Site</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">11. Disclaimer</h2>
          <p className="font-semibold">
            THE SITE IS PROVIDED ON AN "AS-IS" AND "AS AVAILABLE" BASIS. YOU AGREE THAT YOUR USE OF THE SITE AND OUR SERVICES WILL BE AT YOUR SOLE RISK. TO THE FULLEST EXTENT PERMITTED BY LAW, WE DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, IN CONNECTION WITH THE SITE AND YOUR USE THEREOF.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">12. Limitation of Liability</h2>
          <p className="font-semibold">
            IN NO EVENT WILL WE OR OUR DIRECTORS, EMPLOYEES, OR AGENTS BE LIABLE TO YOU OR ANY THIRD PARTY FOR ANY DIRECT, INDIRECT, CONSEQUENTIAL, EXEMPLARY, INCIDENTAL, SPECIAL, OR PUNITIVE DAMAGES, INCLUDING LOST PROFIT, LOST REVENUE, LOSS OF DATA, OR OTHER DAMAGES ARISING FROM YOUR USE OF THE SITE.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">13. Indemnification</h2>
          <p>
            You agree to defend, indemnify, and hold us harmless, including our subsidiaries, affiliates, and all of our respective officers, agents, partners, and employees, from and against any loss, damage, liability, claim, or demand, including reasonable attorneys' fees and expenses, made by any third party due to or arising out of your use of the Site.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">14. Term and Termination</h2>
          <p>
            These Terms of Service shall remain in full force and effect while you use the Site. We may terminate your access to the Site, without cause or notice, which may result in the forfeiture and destruction of all information associated with you. All provisions of these Terms of Service which by their nature should survive termination shall survive termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity, and limitations of liability.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">15. Governing Law</h2>
          <p>
            These Terms of Service and your use of the Site are governed by and construed in accordance with the laws of the State of California, without regard to its conflict of law principles.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">16. Changes to Terms</h2>
          <p>
            We reserve the right to modify these Terms of Service at any time. We will alert you about any changes by updating the "Last updated" date of these Terms of Service. It is your responsibility to periodically review these Terms of Service to stay informed of updates.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4">17. Contact Information</h2>
          <p>
            Questions about the Terms of Service should be sent to us at:
          </p>
          <p className="mb-4">
            <strong>Email:</strong> info@solarrebateguide.com<br />
            <strong>Postal Address:</strong><br />
            YCH LLC<br />
            934 N University Dr PMB 154<br />
            Coral Springs, FL 33071<br />
            United States
          </p>
        </div>
      </div>
    </div>
  );
};

export default TermsOfService;
 