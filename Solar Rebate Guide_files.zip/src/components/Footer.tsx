import  { Link } from 'react-router-dom';
import { Sun, Facebook, Twitter, Instagram, Mail, MapPin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 mb-12">
          <div className="lg:col-span-4">
            <div className="flex items-center mb-6">
              <div className="bg-primary-600 p-1.5 rounded-lg">
                <Sun className="h-7 w-7 text-white" />
              </div>
              <span className="ml-2 text-xl font-display font-bold">SolarRebateGuide</span>
            </div>
            <p className="text-gray-400 mb-6">
              Helping homeowners navigate solar incentives, rebates, and tax credits to maximize savings when going solar.
            </p>
            <div className="flex space-x-3">
              <a href="#" className="bg-gray-800 hover:bg-gray-700 h-10 w-10 rounded-full flex items-center justify-center text-gray-400 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="bg-gray-800 hover:bg-gray-700 h-10 w-10 rounded-full flex items-center justify-center text-gray-400 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="bg-gray-800 hover:bg-gray-700 h-10 w-10 rounded-full flex items-center justify-center text-gray-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="mailto:info@solarrebateguide.com" className="bg-gray-800 hover:bg-gray-700 h-10 w-10 rounded-full flex items-center justify-center text-gray-400 hover:text-white transition-colors">
                <Mail className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div className="lg:col-span-2">
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/national-programs" className="text-gray-400 hover:text-white transition-colors flex items-center">
                  <span className="mr-2">›</span> Federal Incentives
                </Link>
              </li>
              <li>
                <Link to="/buying-guides" className="text-gray-400 hover:text-white transition-colors flex items-center">
                  <span className="mr-2">›</span> Solar Buying Guides
                </Link>
              </li>
              <li>
                <Link to="/state/california" className="text-gray-400 hover:text-white transition-colors flex items-center">
                  <span className="mr-2">›</span> State Rebates
                </Link>
              </li>
              <li>
                <Link to="/city/los-angeles" className="text-gray-400 hover:text-white transition-colors flex items-center">
                  <span className="mr-2">›</span> City Programs
                </Link>
              </li>
              <li>
                <Link to="/report-inaccuracy" className="text-gray-400 hover:text-white transition-colors flex items-center">
                  <span className="mr-2">›</span> Report Inaccuracy
                </Link>
              </li>
            </ul>
          </div>
          
          <div className="lg:col-span-2">
            <h3 className="text-lg font-semibold mb-4">Popular States</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/state/california" className="text-gray-400 hover:text-white transition-colors flex items-center">
                  <span className="mr-2">›</span> California
                </Link>
              </li>
              <li>
                <Link to="/state/texas" className="text-gray-400 hover:text-white transition-colors flex items-center">
                  <span className="mr-2">›</span> Texas
                </Link>
              </li>
              <li>
                <Link to="/state/new-york" className="text-gray-400 hover:text-white transition-colors flex items-center">
                  <span className="mr-2">›</span> New York
                </Link>
              </li>
              <li>
                <Link to="/state/florida" className="text-gray-400 hover:text-white transition-colors flex items-center">
                  <span className="mr-2">›</span> Florida
                </Link>
              </li>
              <li>
                <Link to="/state/arizona" className="text-gray-400 hover:text-white transition-colors flex items-center">
                  <span className="mr-2">›</span> Arizona
                </Link>
              </li>
            </ul>
          </div>
          
          <div className="lg:col-span-2">
            <h3 className="text-lg font-semibold mb-4">Company</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/about" className="text-gray-400 hover:text-white transition-colors flex items-center">
                  <span className="mr-2">›</span> About Us
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-400 hover:text-white transition-colors flex items-center">
                  <span className="mr-2">›</span> Contact
                </Link>
              </li>
              <li>
                <Link to="/terms-of-service" className="text-gray-400 hover:text-white transition-colors flex items-center">
                  <span className="mr-2">›</span> Terms of Service
                </Link>
              </li>
              <li>
                <Link to="/privacy-policy" className="text-gray-400 hover:text-white transition-colors flex items-center">
                  <span className="mr-2">›</span> Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/admin" className="text-gray-400 hover:text-white transition-colors flex items-center">
                  <span className="mr-2">›</span> Admin Login
                </Link>
              </li>
            </ul>
          </div>
          
          <div className="lg:col-span-2">
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 text-primary-500 mr-3 flex-shrink-0 mt-0.5" />
                <span className="text-gray-400">
                  YCH LLC<br />
                  934 N University Dr PMB 154<br />
                  Coral Springs, FL 33071
                </span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 text-primary-500 mr-3 flex-shrink-0" />
                <a href="mailto:info@solarrebateguide.com" className="text-gray-400 hover:text-white transition-colors">
                  info@solarrebateguide.com
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 mt-8 text-center md:flex md:justify-between md:text-left">
          <p className="text-gray-400 text-sm">
            &copy; {currentYear} Solar Rebate Guide. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0">
            <p className="text-gray-500 text-xs">
              Information on this website may not be accurate. Always consult with official sources before making decisions.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
 