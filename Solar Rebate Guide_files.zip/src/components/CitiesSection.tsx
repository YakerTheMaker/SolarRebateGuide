import  { Link } from 'react-router-dom';
import { MapPin } from 'lucide-react';

interface CitiesSectionProps {
  stateId: string;
  stateName: string;
}

const CitiesSection = ({ stateId, stateName }: CitiesSectionProps) => {
  // Mock getCitiesByState function - this would be imported from your data file
  const getCitiesByState = (stateId) => {
    if (stateId === 'california') {
      return [
        { id: 'los-angeles', name: 'Los Angeles' },
        { id: 'san-francisco', name: 'San Francisco' },
        { id: 'san-diego', name: 'San Diego' },
        { id: 'sacramento', name: 'Sacramento' },
        { id: 'fresno', name: 'Fresno' }
      ];
    } else if (stateId === 'texas') {
      return [
        { id: 'austin', name: 'Austin' },
        { id: 'houston', name: 'Houston' },
        { id: 'dallas', name: 'Dallas' },
        { id: 'san-antonio', name: 'San Antonio' }
      ];
    } else {
      return [];
    }
  };
  
  const cities = getCitiesByState(stateId);
  
  if (cities.length === 0) {
    return null;
  }
  
  return (
    <div className="mb-12">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Major Cities in {stateName}</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {cities.map((city) => (
          <Link
            key={city.id}
            to={`/city/${city.id}`}
            className="group block bg-white rounded-lg border border-gray-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="p-5">
              <div className="flex items-center mb-2">
                <MapPin className="h-5 w-5 text-primary-600 mr-2" />
                <h3 className="font-semibold text-gray-900 group-hover:text-primary-600 transition-colors">
                  {city.name}
                </h3>
              </div>
              <p className="text-gray-600 text-sm line-clamp-2">
                Explore solar incentives, rebates, and savings specific to {city.name}.
              </p>
            </div>
          </Link>
        ))}
        
        {cities.length < 6 && (
          <div className="bg-gray-50 rounded-lg border border-dashed border-gray-300 p-5 flex items-center justify-center">
            <p className="text-gray-500 text-sm text-center">
              More city guides coming soon!
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CitiesSection;
 