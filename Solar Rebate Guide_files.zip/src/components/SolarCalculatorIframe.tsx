import  { useRef } from 'react';

const SolarCalculatorIframe = () => {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <iframe
        ref={iframeRef}
        title="Solar Calculator"
        srcDoc={`<!DOCTYPE html>
<html>
<head>
</head>
<body>
      
<div data-widgetdata='{"brand":"2ea855db-67f1-400a-93b3-e6dbd2b78634","borderColor":"#22c55e","primaryColor":"#22c55e","secondaryColor":"#22c55e","fontFamily":"-apple-system","accentColor":"#16a34a","gradStep1":"#e6e6e6","gradStep2":"#e6e6e6","textColor":"#3b3b3c","ctaBtnBgColor":"#22c55e","ctaBtnTextColor":"#ffffff","ctaBtn2BorderColor":"#424242","ctaBtn2TextColor":"#3b3b3c","highlightedColor":"#22c55e","redirectURL":"https://my.solarsmarterhome.com/d/cordless?wl=true&sr=SolarRebateGuide","focusElement":"#fname"}' class="p-1 pb-4 m-1 es-solar-calc-widget">
</div>
  
<script type="text/javascript" async="" src="https://calc.solarsmarterhome.com/v2/index.js"></script>

</body>
</html>`}
        className="w-full min-h-[600px] border-none"
      />
    </div>
  );
};

export default SolarCalculatorIframe;
 