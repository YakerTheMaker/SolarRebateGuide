import  { useState } from 'react';
import { ArrowRight, Sun, DollarSign, BarChart, ChevronRight } from 'lucide-react';

interface SolarCalculatorProps {
  state?: string;
  openLeadPopup: () => void;
}

const SolarCalculator = ({ state, openLeadPopup }: SolarCalculatorProps) => {
  const [step, setStep] = useState(1);
  const [electricBill, setElectricBill] = useState('');
  const [roofType, setRoofType] = useState('');
  const [roofShade, setRoofShade] = useState('');
  const [resultsShown, setResultsShown] = useState(false);
  
  const calculateSavings = () => {
    // In a real app, this would calculate based on actual inputs
    const monthlySavings = parseFloat(electricBill.replace('$', '').split('-')[0]) * 0.65;
    const yearlySavings = monthlySavings * 12;
    const lifetime25YearSavings = yearlySavings * 25;
    const estimatedSystemSize = parseFloat(electricBill.replace('$', '').split('-')[0]) / 150 * 1.1; // rough estimate
    
    return {
      monthlySavings: monthlySavings.toFixed(2),
      yearlySavings: yearlySavings.toFixed(2), 
      lifetime25YearSavings: lifetime25YearSavings.toFixed(2),
      estimatedSystemSize: estimatedSystemSize.toFixed(1),
      estimatedCost: (estimatedSystemSize * 2800).toFixed(2),
      estimatedCostAfterIncentives: (estimatedSystemSize * 1960).toFixed(2),
      paybackPeriod: (estimatedSystemSize * 1960 / yearlySavings).toFixed(1)
    };
  };

  const handleNextStep = () => {
    if (step < 3) {
      setStep(step + 1);
    } else {
      // Show results or trigger quote process
      setResultsShown(true);
    }
  };

  const isStepComplete = () => {
    switch (step) {
      case 1:
        return electricBill !== '';
      case 2:
        return roofType !== '';
      case 3:
        return roofShade !== '';
      default:
        return false;
    }
  };

  const results = calculateSavings();

  return (
    <div>
      {!resultsShown ? (
        <div>
          <div className="mb-6">
            <div className="flex mb-4">
              {[1, 2, 3].map((stepNumber) => (
                <div
                  key={stepNumber}
                  className={`flex-1 h-2 ${
                    stepNumber < step
                      ? 'bg-primary-500'
                      : stepNumber === step
                      ? 'bg-primary-300'
                      : 'bg-gray-200'
                  } ${stepNumber === 1 ? 'rounded-l-full' : ''} ${
                    stepNumber === 3 ? 'rounded-r-full' : ''
                  }`}
                ></div>
              ))}
            </div>
            <p className="text-sm text-gray-500 text-center">
              Step {step} of 3
            </p>
          </div>

          {step === 1 && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                What's your average monthly electric bill?
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
                {['$50-100', '$101-200', '$201-300', '$301-400', '$401-500', '$501+'].map(
                  (amount) => (
                    <button
                      key={amount}
                      className={`py-3 px-4 border rounded-xl ${
                        electricBill === amount
                          ? 'border-primary-500 bg-primary-50 text-primary-700 shadow-sm'
                          : 'border-gray-200 text-gray-700 hover:border-gray-300 hover:shadow-sm'
                      } transition-all`}
                      onClick={() => setElectricBill(amount)}
                    >
                      {amount}
                    </button>
                  )
                )}
              </div>
            </div>
          )}

          {step === 2 && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                What type of roof do you have?
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
                {['Asphalt Shingles', 'Metal', 'Tile', 'Flat', 'Other'].map(
                  (type) => (
                    <button
                      key={type}
                      className={`py-3 px-4 border rounded-xl ${
                        roofType === type
                          ? 'border-primary-500 bg-primary-50 text-primary-700 shadow-sm'
                          : 'border-gray-200 text-gray-700 hover:border-gray-300 hover:shadow-sm'
                      } transition-all`}
                      onClick={() => setRoofType(type)}
                    >
                      {type}
                    </button>
                  )
                )}
              </div>
            </div>
          )}

          {step === 3 && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                How much shade does your roof get?
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
                {['No Shade', 'Some Shade', 'Mostly Shaded'].map((shade) => (
                  <button
                    key={shade}
                    className={`py-3 px-4 border rounded-xl ${
                      roofShade === shade
                        ? 'border-primary-500 bg-primary-50 text-primary-700 shadow-sm'
                        : 'border-gray-200 text-gray-700 hover:border-gray-300 hover:shadow-sm'
                    } transition-all`}
                    onClick={() => setRoofShade(shade)}
                  >
                    {shade}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="mt-8">
            <button
              onClick={handleNextStep}
              disabled={!isStepComplete()}
              className={`btn ${
                isStepComplete()
                  ? 'btn-primary'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              } w-full rounded-xl`}
            >
              {step < 3 ? (
                <>Continue <ChevronRight className="ml-2 h-5 w-5" /></>
              ) : (
                'Calculate Savings'
              )}
            </button>
          </div>
        </div>
      ) : (
        <div>
          <div className="bg-gradient-to-br from-primary-50 to-white border border-primary-200 rounded-2xl p-6 mb-8">
            <h3 className="text-xl font-semibold text-primary-800 mb-4 flex items-center">
              <Sun className="h-6 w-6 mr-2 text-primary-600" />
              Your Estimated Solar Savings
              {state && <span className="ml-1">in {state}</span>}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <div className="bg-white p-4 rounded-xl border border-primary-100 text-center shadow-sm">
                <p className="text-sm text-gray-500 mb-1">Monthly Savings</p>
                <p className="text-2xl font-bold text-primary-700">
                  ${results.monthlySavings}
                </p>
              </div>
              <div className="bg-white p-4 rounded-xl border border-primary-100 text-center shadow-sm">
                <p className="text-sm text-gray-500 mb-1">Annual Savings</p>
                <p className="text-2xl font-bold text-primary-700">
                  ${results.yearlySavings}
                </p>
              </div>
              <div className="bg-white p-4 rounded-xl border border-primary-100 text-center shadow-sm">
                <p className="text-sm text-gray-500 mb-1">25-Year Savings</p>
                <p className="text-2xl font-bold text-primary-700">
                  ${results.lifetime25YearSavings}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center shadow-sm">
                <div className="mr-4 bg-primary-100 p-2 rounded-lg text-primary-700">
                  <BarChart className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Estimated System Size</p>
                  <p className="text-lg font-semibold">{results.estimatedSystemSize} kW</p>
                </div>
              </div>
              <div className="bg-white p-4 rounded-xl border border-gray-100 flex items-center shadow-sm">
                <div className="mr-4 bg-primary-100 p-2 rounded-lg text-primary-700">
                  <Sun className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Payback Period</p>
                  <p className="text-lg font-semibold">{results.paybackPeriod} years</p>
                </div>
              </div>
            </div>

            <div className="mt-6 bg-yellow-50 p-4 rounded-xl border border-yellow-100">
              <div className="flex">
                <DollarSign className="h-5 w-5 text-yellow-600 mr-2 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-yellow-800 mb-1">
                    Available Incentives
                  </p>
                  <p className="text-yellow-700 text-sm">
                    Your solar installation qualifies for the 30% federal tax
                    credit and potentially additional state incentives.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-primary-600 to-primary-700 rounded-2xl p-8 text-white text-center shadow-lg">
            <h3 className="text-xl font-bold mb-3">Ready for Exact Numbers?</h3>
            <p className="mb-6 opacity-90">
              Get personalized quotes from top-rated solar installers in your
              area.
            </p>
            <button
              onClick={openLeadPopup}
              className="btn bg-white text-primary-700 hover:bg-gray-100 rounded-full px-8 shadow-md hover:shadow-lg"
            >
              Get My Free Solar Quote
              <ArrowRight className="ml-2 h-4 w-4" />
            </button>
          </div>

          <p className="text-xs text-gray-500 mt-4 text-center">
            These calculations are estimates based on average solar production
            and utility rates in your area. Your actual savings may vary.
          </p>
        </div>
      )}
    </div>
  );
};

export default SolarCalculator;
 