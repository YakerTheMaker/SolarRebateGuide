import  { useRef } from 'react';

interface SolarLeadFormProps {
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
}

const SolarLeadForm = ({ firstName, lastName, email, phone }: SolarLeadFormProps) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Construct the URL with any params passed in
  const constructSrcUrl = () => {
    const baseUrl = 'https://my.solarsmarterhome.com/d/cordless';
    const params = new URLSearchParams();
    
    params.append('wl', 'true');
    params.append('sr', 'SolarRebateGuide');
    
    if (firstName) params.append('fn', firstName);
    if (lastName) params.append('ln', lastName);
    if (email) params.append('em', email);
    if (phone) params.append('ph', phone);
    
    return `${baseUrl}?${params.toString()}`;
  };

  return (
    <div className="bg-white rounded-xl shadow-sm">
      <iframe
        ref={iframeRef}
        title="Solar Lead Form"
        src={constructSrcUrl()}
        className="w-full min-h-[600px] border-none"
      />
    </div>
  );
};

export default SolarLeadForm;
 