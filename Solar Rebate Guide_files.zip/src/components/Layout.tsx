import  { Outlet } from 'react-router-dom';
import Navbar from './Navbar';
import Footer from './Footer';
import LeadCapturePopup from './LeadCapturePopup';
import CookieConsent from './CookieConsent';
import { useState } from 'react';

const Layout = () => {
  const [showLeadPopup, setShowLeadPopup] = useState(false);

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <Outlet context={{ openLeadPopup: () => setShowLeadPopup(true) }} />
      </main>
      <Footer />
      {showLeadPopup && <LeadCapturePopup onClose={() => setShowLeadPopup(false)} />}
      <CookieConsent privacyPolicyUrl="/privacy-policy" />
    </div>
  );
};

export default Layout;
 