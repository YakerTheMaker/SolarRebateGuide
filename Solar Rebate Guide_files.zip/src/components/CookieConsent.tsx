import  { useState, useEffect } from 'react';
import { X } from 'lucide-react';

interface CookieConsentProps {
  privacyPolicyUrl: string;
}

const CookieConsent = ({ privacyPolicyUrl }: CookieConsentProps) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Check if user has already consented
    const hasConsented = localStorage.getItem('cookieConsent');
    if (!hasConsented) {
      setVisible(true);
    }
  }, []);

  const acceptAll = () => {
    localStorage.setItem('cookieConsent', 'all');
    localStorage.setItem('cookieConsentTimestamp', new Date().toISOString());
    setVisible(false);
  };

  const acceptEssential = () => {
    localStorage.setItem('cookieConsent', 'essential');
    localStorage.setItem('cookieConsentTimestamp', new Date().toISOString());
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white shadow-lg border-t border-gray-200 z-50">
      <div className="container-custom py-4 px-4 md:px-6">
        <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
          <div className="flex-grow pr-4">
            <p className="text-sm text-gray-700">
              This website uses cookies to enhance your browsing experience, analyze site traffic, and deliver personalized content. 
              We also share information with solar providers to help you obtain quotes. By clicking "Accept All", you consent to our use of cookies and data sharing practices as described in our{' '}
              <a href={privacyPolicyUrl} className="text-primary-600 hover:underline font-medium">
                Privacy Policy
              </a>.
            </p>
          </div>
          <div className="flex gap-2 flex-shrink-0">
            <button
              onClick={acceptEssential}
              className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50"
            >
              Essential Only
            </button>
            <button
              onClick={acceptAll}
              className="px-4 py-2 bg-primary-600 text-white rounded-lg text-sm font-medium hover:bg-primary-700"
            >
              Accept All
            </button>
          </div>
          <button
            onClick={acceptEssential}
            className="absolute top-3 right-3 md:hidden p-1 text-gray-500 hover:text-gray-700"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieConsent;
 