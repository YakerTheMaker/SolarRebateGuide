import  { useState } from 'react';
import { X, ArrowRight, Check, Sun } from 'lucide-react';

interface LeadCapturePopupProps {
  onClose: () => void;
}

const LeadCapturePopup = ({ onClose }: LeadCapturePopupProps) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    zipCode: '',
    electricBill: '',
    homeowner: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    
    // Clear error when field is updated
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: '',
      });
    }
  };

  const validateStep = () => {
    const newErrors: Record<string, string> = {};
    
    if (step === 1) {
      if (!formData.zipCode) {
        newErrors.zipCode = 'ZIP code is required';
      } else if (!/^\d{5}(-\d{4})?$/.test(formData.zipCode)) {
        newErrors.zipCode = 'Please enter a valid ZIP code';
      }
      
      if (!formData.electricBill) {
        newErrors.electricBill = 'Please select your average monthly electric bill';
      }
      
      if (!formData.homeowner) {
        newErrors.homeowner = 'Please indicate if you\'re a homeowner';
      }
    } else if (step === 2) {
      if (!formData.name) {
        newErrors.name = 'Name is required';
      }
      
      if (!formData.email) {
        newErrors.email = 'Email is required';
      } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
        newErrors.email = 'Please enter a valid email address';
      }
      
      if (!formData.phone) {
        newErrors.phone = 'Phone number is required';
      } else if (!/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/.test(formData.phone)) {
        newErrors.phone = 'Please enter a valid phone number';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNextStep = () => {
    if (validateStep()) {
      if (step < 2) {
        setStep(step + 1);
      } else {
        handleSubmit();
      }
    }
  };

  const handleSubmit = () => {
    // In a real app, this would send the data to a server
    console.log('Form submitted:', formData);
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 bg-gray-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary-400 to-primary-600"></div>
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 bg-white/80 backdrop-blur-sm rounded-full p-1.5 z-10"
        >
          <X className="h-5 w-5" />
        </button>
        
        <div className="p-8">
          {!submitted ? (
            <>
              <div className="text-center mb-6">
                <div className="flex items-center justify-center mb-3">
                  <div className="bg-primary-100 text-primary-600 w-10 h-10 rounded-full flex items-center justify-center">
                    <Sun className="h-6 w-6" />
                  </div>
                </div>
                <h2 className="text-2xl font-bold text-gray-900">Schedule a Consultation</h2>
                <p className="text-gray-600 mt-1">
                  Get a local solar quote from top-rated installers
                </p>
              </div>
              
              <div className="mb-6">
                <div className="flex mb-2">
                  {[1, 2].map((stepNumber) => (
                    <div
                      key={stepNumber}
                      className={`flex-1 h-2 ${
                        stepNumber < step
                          ? 'bg-primary-500'
                          : stepNumber === step
                          ? 'bg-primary-300'
                          : 'bg-gray-200'
                      } ${stepNumber === 1 ? 'rounded-l-full' : ''} ${
                        stepNumber === 2 ? 'rounded-r-full' : ''
                      }`}
                    ></div>
                  ))}
                </div>
                <p className="text-xs text-gray-500 text-center">
                  Step {step} of 2
                </p>
              </div>
              
              {step === 1 && (
                <div className="space-y-5">
                  <div>
                    <label htmlFor="zipCode" className="block text-sm font-medium text-gray-700 mb-1">
                      ZIP Code<span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="zipCode"
                      name="zipCode"
                      value={formData.zipCode}
                      onChange={handleChange}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 ${
                        errors.zipCode ? 'border-red-500' : 'border-gray-300'
                      }`}
                      placeholder="Enter your ZIP code"
                    />
                    {errors.zipCode && (
                      <p className="mt-1 text-sm text-red-500">{errors.zipCode}</p>
                    )}
                  </div>
                  
                  <div>
                    <label htmlFor="electricBill" className="block text-sm font-medium text-gray-700 mb-1">
                      Average Monthly Electric Bill<span className="text-red-500">*</span>
                    </label>
                    <select
                      id="electricBill"
                      name="electricBill"
                      value={formData.electricBill}
                      onChange={handleChange}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 ${
                        errors.electricBill ? 'border-red-500' : 'border-gray-300'
                      }`}
                    >
                      <option value="">Select amount</option>
                      <option value="$0-100">$0-100</option>
                      <option value="$101-200">$101-200</option>
                      <option value="$201-300">$201-300</option>
                      <option value="$301-400">$301-400</option>
                      <option value="$401+">$401+</option>
                    </select>
                    {errors.electricBill && (
                      <p className="mt-1 text-sm text-red-500">{errors.electricBill}</p>
                    )}
                  </div>
                  
                  <div>
                    <label htmlFor="homeowner" className="block text-sm font-medium text-gray-700 mb-1">
                      Are you a homeowner?<span className="text-red-500">*</span>
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        className={`py-3 px-4 border rounded-xl ${
                          formData.homeowner === 'Yes'
                            ? 'border-primary-500 bg-primary-50 text-primary-700'
                            : 'border-gray-300 text-gray-700 hover:border-gray-400'
                        }`}
                        onClick={() => setFormData({ ...formData, homeowner: 'Yes' })}
                      >
                        Yes
                      </button>
                      <button
                        type="button"
                        className={`py-3 px-4 border rounded-xl ${
                          formData.homeowner === 'No'
                            ? 'border-primary-500 bg-primary-50 text-primary-700'
                            : 'border-gray-300 text-gray-700 hover:border-gray-400'
                        }`}
                        onClick={() => setFormData({ ...formData, homeowner: 'No' })}
                      >
                        No
                      </button>
                    </div>
                    {errors.homeowner && (
                      <p className="mt-1 text-sm text-red-500">{errors.homeowner}</p>
                    )}
                  </div>
                </div>
              )}
              
              {step === 2 && (
                <div className="space-y-5">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                      Full Name<span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 ${
                        errors.name ? 'border-red-500' : 'border-gray-300'
                      }`}
                      placeholder="Enter your full name"
                    />
                    {errors.name && (
                      <p className="mt-1 text-sm text-red-500">{errors.name}</p>
                    )}
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email<span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 ${
                        errors.email ? 'border-red-500' : 'border-gray-300'
                      }`}
                      placeholder="Enter your email"
                    />
                    {errors.email && (
                      <p className="mt-1 text-sm text-red-500">{errors.email}</p>
                    )}
                  </div>
                  
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number<span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 ${
                        errors.phone ? 'border-red-500' : 'border-gray-300'
                      }`}
                      placeholder="(123) 456-7890"
                    />
                    {errors.phone && (
                      <p className="mt-1 text-sm text-red-500">{errors.phone}</p>
                    )}
                  </div>
                </div>
              )}
              
              <button
                onClick={handleNextStep}
                className="btn btn-primary w-full mt-8 rounded-xl"
              >
                {step < 2 ? (
                  <>
                    Continue
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                ) : (
                  'Schedule My Consultation'
                )}
              </button>
              
              <p className="text-xs text-gray-500 mt-4 text-center">
                By submitting this form, you agree to our{' '}
                <a href="/terms-of-service" className="text-primary-600 hover:underline">
                  Terms of Service
                </a>{' '}
                and{' '}
                <a href="/privacy-policy" className="text-primary-600 hover:underline">
                  Privacy Policy
                </a>
                .
              </p>
            </>
          ) : (
            <div className="text-center py-6">
              <div className="bg-primary-100 text-primary-600 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                <Check className="h-10 w-10" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">Thank You!</h2>
              <p className="text-gray-600 mb-8">
                Your consultation request has been submitted. One of our solar specialists will contact you shortly to schedule your personalized consultation.
              </p>
              <button
                onClick={onClose}
                className="btn btn-primary rounded-xl"
              >
                Close
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LeadCapturePopup;
 