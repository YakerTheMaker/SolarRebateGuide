import  { Link } from 'react-router-dom';
import { MapPin } from 'lucide-react';

interface StateDropdownProps {
  onClose: () => void;
  mobile?: boolean;
}

const StateDropdown = ({ onClose, mobile = false }: StateDropdownProps) => {
  // Mock states data - this would be imported from your data file
  const states = [
    { id: 'california', name: 'California' },
    { id: 'texas', name: 'Texas' },
    { id: 'new-york', name: 'New York' },
    { id: 'florida', name: 'Florida' },
    { id: 'illinois', name: 'Illinois' }
  ];
  
  const regions = [
    {
      name: 'West',
      states: ['California', 'Oregon', 'Washington', 'Nevada', 'Arizona', 'Utah', 'Idaho', 'Montana', 'Wyoming', 'Colorado', 'New Mexico', 'Hawaii', 'Alaska']
    },
    {
      name: 'Midwest',
      states: ['Ohio', 'Michigan', 'Indiana', 'Illinois', 'Wisconsin', 'Minnesota', 'Iowa', 'Missouri', 'North Dakota', 'South Dakota', 'Nebraska', 'Kansas']
    },
    {
      name: 'Northeast',
      states: ['Maine', 'Vermont', 'New Hampshire', 'Massachusetts', 'Rhode Island', 'Connecticut', 'New York', 'New Jersey', 'Pennsylvania']
    },
    {
      name: 'South',
      states: ['Delaware', 'Maryland', 'Virginia', 'West Virginia', 'Kentucky', 'North Carolina', 'South Carolina', 'Tennessee', 'Georgia', 'Florida', 'Alabama', 'Mississippi', 'Arkansas', 'Louisiana', 'Oklahoma', 'Texas', 'District of Columbia']
    }
  ];

  const getStateUrl = (stateName) => {
    return `/state/${stateName.toLowerCase().replace(/\s+/g, '-')}`;
  };

  return (
    <div 
      className={`bg-white rounded-2xl shadow-xl z-40 ${
        mobile 
          ? 'w-full py-4' 
          : 'absolute top-full mt-2 w-screen max-w-6xl left-1/2 transform -translate-x-1/2'
      }`}
    >
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 p-6 max-h-[70vh] overflow-y-auto">
        {regions.map((region) => (
          <div key={region.name}>
            <h3 className="font-semibold text-gray-900 mb-3 border-b border-gray-100 pb-2">{region.name}</h3>
            <ul className="space-y-2">
              {region.states.map((stateName) => {
                const stateData = states.find(s => s.name === stateName);
                if (!stateData && stateName !== 'California' && stateName !== 'Texas' && stateName !== 'New York' && stateName !== 'Florida') return null;
                
                return (
                  <li key={stateName}>
                    <Link
                      to={getStateUrl(stateName)}
                      className="text-gray-600 hover:text-primary-600 hover:bg-gray-50 rounded-lg px-2 py-1 flex items-center transition-colors text-sm"
                      onClick={onClose}
                    >
                      <MapPin className="h-3 w-3 mr-2 flex-shrink-0" />
                      {stateName}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>
      
      <div className="border-t border-gray-100 p-4 bg-gray-50 rounded-b-2xl">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-500">
            Find solar incentives in your state
          </span>
          <Link
            to="/national-programs"
            className="text-primary-600 hover:text-primary-700 text-sm font-medium hover:underline flex items-center"
            onClick={onClose}
          >
            View National Programs
          </Link>
        </div>
      </div>
    </div>
  );
};

export default StateDropdown;
 