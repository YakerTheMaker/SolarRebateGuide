import  { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Sun, Menu, X, ChevronDown } from 'lucide-react';
import StateDropdown from './StateDropdown';

const Navbar = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [stateDropdownOpen, setStateDropdownOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  useEffect(() => {
    // Close mobile menu when route changes
    setMobileMenuOpen(false);
    setStateDropdownOpen(false);
  }, [location]);

  return (
    <header className={`sticky top-0 z-40 transition-all duration-300 ${
      scrolled ? 'bg-white shadow-md' : 'bg-white/80 backdrop-blur-md'
    }`}>
      <nav className="container-custom py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <div className="bg-primary-600 p-1.5 rounded-lg">
                <Sun className="h-7 w-7 text-white" />
              </div>
              <span className="ml-2 text-xl font-display font-bold text-gray-900">
                SolarRebateGuide
              </span>
            </Link>
          </div>

          {/* Desktop menu */}
          <div className="hidden lg:flex items-center space-x-1">
            <NavLink to="/" className={({isActive}) => 
              isActive 
                ? "px-3 py-2 rounded-lg text-primary-600 font-medium" 
                : "px-3 py-2 rounded-lg text-gray-600 hover:text-primary-600 hover:bg-gray-50"
            }>
              Home
            </NavLink>
            
            <div className="relative">
              <button 
                onClick={() => setStateDropdownOpen(!stateDropdownOpen)}
                className="flex items-center px-3 py-2 rounded-lg text-gray-600 hover:text-primary-600 hover:bg-gray-50"
              >
                State Rebates <ChevronDown className="ml-1 h-4 w-4" />
              </button>
              {stateDropdownOpen && <StateDropdown onClose={() => setStateDropdownOpen(false)} />}
            </div>
            
            <NavLink to="/national-programs" className={({isActive}) => 
              isActive 
                ? "px-3 py-2 rounded-lg text-primary-600 font-medium" 
                : "px-3 py-2 rounded-lg text-gray-600 hover:text-primary-600 hover:bg-gray-50"
            }>
              National Programs
            </NavLink>
            
            <NavLink to="/buying-guides" className={({isActive}) => 
              isActive 
                ? "px-3 py-2 rounded-lg text-primary-600 font-medium" 
                : "px-3 py-2 rounded-lg text-gray-600 hover:text-primary-600 hover:bg-gray-50"
            }>
              Buying Guides
            </NavLink>
            
            <NavLink to="/contact" className={({isActive}) => 
              isActive 
                ? "px-3 py-2 rounded-lg text-primary-600 font-medium" 
                : "px-3 py-2 rounded-lg text-gray-600 hover:text-primary-600 hover:bg-gray-50"
            }>
              Contact
            </NavLink>
          </div>

          <div className="hidden lg:block">
            <Link to="/state/california" className="btn btn-primary py-2">
              Find Solar Rebates
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="lg:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-gray-600 hover:text-primary-600 p-2"
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden mt-4 pb-4 border-t border-gray-100 pt-4">
            <div className="flex flex-col space-y-2">
              <Link 
                to="/" 
                className="px-3 py-2 rounded-lg text-gray-600 hover:text-primary-600 hover:bg-gray-50"
              >
                Home
              </Link>
              <button 
                onClick={() => setStateDropdownOpen(!stateDropdownOpen)}
                className="flex items-center justify-between px-3 py-2 rounded-lg text-gray-600 hover:text-primary-600 hover:bg-gray-50"
              >
                <span>State Rebates</span> <ChevronDown className="ml-1 h-4 w-4" />
              </button>
              {stateDropdownOpen && <StateDropdown onClose={() => setStateDropdownOpen(false)} mobile />}
              <Link 
                to="/national-programs" 
                className="px-3 py-2 rounded-lg text-gray-600 hover:text-primary-600 hover:bg-gray-50"
              >
                National Programs
              </Link>
              <Link 
                to="/buying-guides" 
                className="px-3 py-2 rounded-lg text-gray-600 hover:text-primary-600 hover:bg-gray-50"
              >
                Buying Guides
              </Link>
              <Link 
                to="/contact" 
                className="px-3 py-2 rounded-lg text-gray-600 hover:text-primary-600 hover:bg-gray-50"
              >
                Contact
              </Link>
              <Link 
                to="/state/california" 
                className="btn btn-primary mt-2 py-2"
              >
                Find Solar Rebates
              </Link>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Navbar;
 